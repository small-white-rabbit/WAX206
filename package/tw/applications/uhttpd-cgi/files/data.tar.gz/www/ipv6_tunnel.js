function setRemote() {
  var cf = document.forms[0];
  1 == cf.relay[0].checked
    ? ((cf.WIp1.disabled = !0),
      (cf.WIp2.disabled = !0),
      (cf.WIp3.disabled = !0),
      (cf.WIp4.disabled = !0))
    : 1 == cf.relay[1].checked &&
      ((cf.WIp1.disabled = !1),
      (cf.WIp2.disabled = !1),
      (cf.WIp3.disabled = !1),
      (cf.WIp4.disabled = !1));
}
function check_ipv6_6to4(cf) {
  if (
    0 == internet_basic_type &&
    (0 == internet_ppp_type ||
      1 == internet_ppp_type ||
      4 == internet_ppp_type) &&
    0 == confirm("$ipv6_6to4_warning")
  )
    return !1;
  if (1 == cf.relay[1].checked) {
    if (
      ((cf.ipv6_hidden_6to4_relay.value =
        cf.WIp1.value +
        "." +
        cf.WIp2.value +
        "." +
        cf.WIp3.value +
        "." +
        cf.WIp4.value),
      0 == checkipaddr(cf.ipv6_hidden_6to4_relay.value))
    )
      return alert("$invalid_ip"), !1;
    cf.ipv6_hidden_remote.value = "1";
  } else
    (cf.ipv6_hidden_6to4_relay.value = ipv6_6to4_relay_ip),
      (cf.ipv6_hidden_remote.value = "0");
  return (
    (1 != getTop(window).ipv6_dns_manual || 0 != checkIPv6DNS(cf)) &&
    0 != ipv6_save_common(cf) &&
    (1 !== getTop(window).support_ds_lite_flag ||
      1 != getTop(window).is_jp_version ||
      "1" != enable_ds ||
      0 !=
        confirm(
          "Dual-Stack Lite will be invalid, If you confirm to configure IPv6 to $ipv6_6to4_tunnel type!"
        ))
  );
}
