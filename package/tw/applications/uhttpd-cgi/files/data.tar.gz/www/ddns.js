function click_ddns(form) {
  var new_sysDNSHost = str_replace(old_sysDNSHost),
    new_sysDNSUser = str_replace(old_sysDNSUser),
    password_change = 0,
    sysDNSProviderlist_value = convert_value_to_original(
      form,
      "sysDNSProviderlist"
    );
  if (
    (form.sysDNSActive.checked
      ? (form.ddns_enabled.value = "1")
      : (form.ddns_enabled.value = "0"),
    1 == ddns_wildcards_flag &&
    "www/var/www.3322.org" == sysDNSProviderlist_value &&
    form.sysDNSWildCard.checked
      ? (form.wildcards_enabled.value = "1")
      : (form.wildcards_enabled.value = "0"),
    (form.hidden_sysDNSProviderlist.value = sysDNSProviderlist_value),
    (form.sysDNSHost.value = form.sysDNSHost.value.replace(/\s/gi, "")),
    (form.hidden_sysDNSHost.value = form.sysDNSHost.value),
    form.sysDNSActive.checked)
  ) {
    if (
      "" == form.sysDNSHost.value &&
      "www/var/www.oray.cn" != sysDNSProviderlist_value
    )
      return alert("$hostname_null"), !1;
    if ("" == form.sysDNSUser.value) return alert("$user_name_null"), !1;
    if ("" == form.sysDNSPassword.value) return alert("$password_null"), !1;
    if ("www/var/www.oray.cn" != sysDNSProviderlist_value)
      for (i = 0; i < form.sysDNSHost.value.length; i++)
        if (0 == isValidDdnsHost(form.sysDNSHost.value.charCodeAt(i)))
          return alert("$hostname_error"), !1;
    if ("www/var/www.oray.cn" == sysDNSProviderlist_value) {
      for (i = 0; i < form.sysDNSUser.value.length; i++)
        if (0 == isValidDdnsOrayUserName(form.sysDNSUser.value.charCodeAt(i)))
          return alert("$user_name_error"), !1;
    } else
      for (i = 0; i < form.sysDNSUser.value.length; i++)
        if (0 == isValidChar_space(form.sysDNSUser.value.charCodeAt(i)))
          return alert("$user_name_error"), !1;
    for (i = 0; i < form.sysDNSPassword.value.length; i++)
      if (0 == isValidChar_space(form.sysDNSPassword.value.charCodeAt(i)))
        return alert("$password_error"), !1;
    if (
      ((("www/var/www.DynDNS.org" == sysDNSProviderlist_value &&
        "1" == form.hidden_pwd_change_1.value) ||
        ("www/var/www.oray.cn" == sysDNSProviderlist_value &&
          "1" == form.hidden_pwd_change_2.value) ||
        ("www/var/www.3322.org" == sysDNSProviderlist_value &&
          "1" == form.hidden_pwd_change_3.value) ||
        ("www/var/dynupdate.no-ip.com" == sysDNSProviderlist_value &&
          "1" == form.hidden_pwd_change_4.value)) &&
        (password_change = 1),
      new_sysDNSHost == form.sysDNSHost.value &&
        new_sysDNSUser == form.sysDNSUser.value &&
        0 == password_change &&
        old_endis_wildcards == form.wildcards_enabled.value &&
        old_endis_ddns == form.ddns_enabled.value &&
        dns_list == sysDNSProviderlist_value)
    )
      return alert("$ddns_warning_message"), !1;
  }
  return (
    old_endis_ddns != form.ddns_enabled.value ||
    old_sysDNSHost != form.hidden_sysDNSHost.value ||
    old_sysDNSUser != form.sysDNSUser.value ||
    1 == password_change ||
    old_endis_wildcards != form.wildcards_enabled.value
      ? (form.change_wan_type.value = 0)
      : (form.change_wan_type.value = 1),
    (dns_list != sysDNSProviderlist_value ||
      (dns_list == sysDNSProviderlist_value &&
        old_sysDNSHost != form.sysDNSHost.value)) &&
    "1" == vpn_enable &&
    1 == form.sysDNSActive.checked
      ? (form.hid_vpn_detect_ddns_change.value = 1)
      : (form.hid_vpn_detect_ddns_change.value = 0),
    (parent.ddns_post_flag = 1),
    !0
  );
}
function str_replace(str) {
  return (str = str
    .replace(/&#92;/g, "\\")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#40;/g, "(")
    .replace(/&#41;/g, ")")
    .replace(/&#34;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#35;/g, "#")
    .replace(/&#38;/g, "&"));
}
function parse_xss_str() {
  (old_sysDNSHost_1 = str_replace(old_sysDNSHost_1)),
    (old_sysDNSUser_1 = str_replace(old_sysDNSUser_1)),
    (old_sysDNSHost_2 = str_replace(old_sysDNSHost_2)),
    (old_sysDNSUser_2 = str_replace(old_sysDNSUser_2)),
    (old_sysDNSHost_3 = str_replace(old_sysDNSHost_3)),
    (old_sysDNSUser_3 = str_replace(old_sysDNSUser_3)),
    (old_sysDNSHost_4 = str_replace(old_sysDNSHost_4)),
    (old_sysDNSUser_4 = str_replace(old_sysDNSUser_4));
}
function change_ddns_password(obj) {
  var cf = document.forms[0],
    sysDNSProviderlist_value = convert_value_to_original(
      cf,
      "sysDNSProviderlist"
    );
  (cf.hidden_sysDNSProviderlist.value = sysDNSProviderlist_value),
    "password" == obj.type &&
      ("Firefox" == get_browser()
        ? ((obj.value = ""), (obj.type = "text"))
        : ((obj.outerHTML =
            '<input type="text" name="sysDNSPassword" onfocus="this.select();change_ddns_password(this);" size="32" maxlength="64">'),
          cf.sysDNSPassword.select())),
    "www/var/www.DynDNS.org" == sysDNSProviderlist_value
      ? (cf.hidden_pwd_change_1.value = "1")
      : "www/var/www.oray.cn" == sysDNSProviderlist_value
      ? (cf.hidden_pwd_change_2.value = "1")
      : "www/var/www.3322.org" == sysDNSProviderlist_value
      ? (cf.hidden_pwd_change_3.value = "1")
      : "www/var/dynupdate.no-ip.com" == sysDNSProviderlist_value &&
        (cf.hidden_pwd_change_4.value = "1");
}
