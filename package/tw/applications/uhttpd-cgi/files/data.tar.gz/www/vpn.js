function handle_on_updating() {
  var cf = document.forms[0];
  "1" == on_updating
    ? (document.getElementById("for_windows") &&
        ((document.getElementById("for_windows").className = "window1_bt"),
        (document.getElementById("for_windows").disabled = !0)),
      document.getElementById("for_non_windows") &&
        ((document.getElementById("for_non_windows").className =
          "non_window1_bt"),
        (document.getElementById("for_non_windows").disabled = !0)),
      document.getElementById("for_smart_phone") &&
        ((document.getElementById("for_smart_phone").className =
          "non_window1_bt"),
        (document.getElementById("for_smart_phone").disabled = !0)),
      cf.Apply &&
        "admin" == master &&
        ((cf.Apply.className = "apply1_bt"), (cf.Apply.disabled = !0)),
      document.getElementById("updating_tip") &&
        (document.getElementById("updating_tip").style.display = ""))
    : (document.getElementById("for_windows") &&
        ((document.getElementById("for_windows").className = "window_bt"),
        (document.getElementById("for_windows").disabled = !1)),
      document.getElementById("for_non_windows") &&
        ((document.getElementById("for_non_windows").className =
          "non_window_bt"),
        (document.getElementById("for_non_windows").disabled = !1)),
      document.getElementById("for_smart_phone") &&
        ((document.getElementById("for_smart_phone").className =
          "non_window_bt"),
        (document.getElementById("for_smart_phone").disabled = !1)),
      cf.Apply &&
        "admin" == master &&
        ((cf.Apply.className = "apply_bt"), (cf.Apply.disabled = !1)),
      document.getElementById("updating_tip") &&
        (document.getElementById("updating_tip").style.display = "none"));
}
function checkvpn(cf) {
  var int_port = parseInt(cf.openvpn_service_port.value, 10);
  return 1 != cf.openvpnActive.checked ||
    "1" == old_endis_ddns ||
    ("0" != old_wan_assign && ("1" != old_wan_assign || "1" == select_basic)) ||
    ("1" == pppoe_get_wan_assign && "pppoe" == info_get_wanproto)
    ? int_port > 65534
      ? (alert("$serv_port_limit"), !1)
      : (1 == cf.openvpnActive.checked
          ? (cf.hidden_enable_vpn.value = 1)
          : (cf.hidden_enable_vpn.value = 0),
        1 == cf.openvpn_protocol[0].checked
          ? (cf.hidden_vpn_type.value = "udp")
          : 1 == cf.openvpn_protocol[1].checked &&
            (cf.hidden_vpn_type.value = "tcp"),
        (cf.hidden_vpn_port.value = cf.openvpn_service_port.value),
        1 == cf.openvpn_redirectGW[0].checked
          ? (cf.hidden_vpn_access.value = "auto")
          : 1 == cf.openvpn_redirectGW[1].checked
          ? (cf.hidden_vpn_access.value = "all")
          : 1 == cf.openvpn_redirectGW[2].checked &&
            (cf.hidden_vpn_access.value = "home"),
        1 == cf.openvpnActive.checked &&
        0 == check_all_port(int_port, cf.hidden_vpn_type.value)
          ? (alert("$invalid_port_used"), !1)
          : (1 == cf.openvpnActive.checked &&
              "" == backup_rsp &&
              (cf.hidden_backup_rspToPing.value = rspToPing_value),
            (cf.hidden_vpn_type.value == type &&
              cf.hidden_vpn_port.value == port &&
              cf.hidden_vpn_access.value == access_mode) ||
              1 != cf.hidden_enable_vpn.value ||
              alert("$warn_change_vpn_config"),
            (1 != cf.openvpnActive.checked ||
              "0" != select_basic ||
              !(
                ("0" == internet_ppp_type && "1" == wan_pppoe_demand) ||
                ("1" == internet_ppp_type && "1" == wan_pptp_demand) ||
                ("3" == internet_ppp_type && "1" == wan_mulpppoe_demand) ||
                ("4" == internet_ppp_type && "1" == wan_l2tp_demand)
              ) ||
              0 != confirm("$ppp_dial_on_demand_vpn_query")) &&
              (1 == cf.openvpnActive.checked &&
                "0" == select_basic &&
                (("0" == internet_ppp_type && "2" == wan_pppoe_demand) ||
                  ("1" == internet_ppp_type && "2" == wan_pptp_demand) ||
                  ("3" == internet_ppp_type && "2" == wan_mulpppoe_demand) ||
                  ("4" == internet_ppp_type && "2" == wan_l2tp_demand)) &&
                alert("$ppp_dial_on_demand_vpn_warning"),
              !0)))
    : (alert("$no_ddns"), !1);
}
function check_openvpn(cf) {
  var int_port = parseInt(cf.openvpn_service_port.value, 10),
    tun_int_port = parseInt(cf.openvpn_tun_service_port.value, 10);
  return 1 != cf.openvpnActive.checked ||
    "1" == old_endis_ddns ||
    ("0" != old_wan_assign && ("1" != old_wan_assign || "1" == select_basic)) ||
    ("1" == pppoe_get_wan_assign && "pppoe" == info_get_wanproto)
    ? int_port > 65534 || tun_int_port > 65534
      ? (alert("$serv_port_limit"), !1)
      : (1 == cf.openvpnActive.checked
          ? (cf.hidden_enable_vpn.value = 1)
          : (cf.hidden_enable_vpn.value = 0),
        1 == cf.openvpn_protocol[0].checked
          ? (cf.hidden_vpn_type.value = "udp")
          : 1 == cf.openvpn_protocol[1].checked &&
            (cf.hidden_vpn_type.value = "tcp"),
        1 == cf.openvpn_tun_protocol[0].checked
          ? (cf.hidden_tun_vpn_type.value = "udp")
          : 1 == cf.openvpn_tun_protocol[1].checked &&
            (cf.hidden_tun_vpn_type.value = "tcp"),
        cf.openvpn_service_port.value == cf.openvpn_tun_service_port.value
          ? (alert("Can't use the same port in TUN mode and TAP mode."), !1)
          : ((cf.hidden_vpn_port.value = cf.openvpn_service_port.value),
            (cf.hidden_tun_vpn_port.value = cf.openvpn_tun_service_port.value),
            1 == cf.openvpn_redirectGW[0].checked
              ? (cf.hidden_vpn_access.value = "auto")
              : 1 == cf.openvpn_redirectGW[1].checked
              ? (cf.hidden_vpn_access.value = "all")
              : 1 == cf.openvpn_redirectGW[2].checked &&
                (cf.hidden_vpn_access.value = "home"),
            1 != cf.openvpnActive.checked ||
            (0 != check_all_port(int_port, cf.hidden_vpn_type.value) &&
              0 != check_all_port(tun_int_port, cf.hidden_tun_vpn_type.value))
              ? (1 == cf.openvpnActive.checked &&
                  "" == backup_rsp &&
                  (cf.hidden_backup_rspToPing.value = rspToPing_value),
                (cf.hidden_vpn_type.value == type &&
                  cf.hidden_vpn_port.value == port &&
                  cf.hidden_vpn_access.value == access_mode &&
                  cf.hidden_tun_vpn_type.value == tun_type &&
                  cf.hidden_tun_vpn_port.value == tun_port) ||
                  1 != cf.hidden_enable_vpn.value ||
                  alert("$warn_change_vpn_config"),
                (1 != cf.openvpnActive.checked ||
                  "0" != select_basic ||
                  !(
                    ("0" == internet_ppp_type && "1" == wan_pppoe_demand) ||
                    ("1" == internet_ppp_type && "1" == wan_pptp_demand) ||
                    ("3" == internet_ppp_type && "1" == wan_mulpppoe_demand) ||
                    ("4" == internet_ppp_type && "1" == wan_l2tp_demand)
                  ) ||
                  0 != confirm("$ppp_dial_on_demand_vpn_query")) &&
                  (1 == cf.openvpnActive.checked &&
                    "0" == select_basic &&
                    (("0" == internet_ppp_type && "2" == wan_pppoe_demand) ||
                      ("1" == internet_ppp_type && "2" == wan_pptp_demand) ||
                      ("3" == internet_ppp_type &&
                        "2" == wan_mulpppoe_demand) ||
                      ("4" == internet_ppp_type && "2" == wan_l2tp_demand)) &&
                    alert("$ppp_dial_on_demand_vpn_warning"),
                  !0))
              : (alert("$invalid_port_used"), !1)))
    : (alert("$no_ddns"), !1);
}
function checkdownload(cf, num) {
  return "0" == vpn_enable
    ? (alert("$no_enable_vpn"), !1)
    : ("1" != old_endis_ddns && alert("$no_ddns_config_file"),
      1 == num
        ? (cf.download_button_type.value = "windows")
        : 2 == num
        ? (cf.download_button_type.value = "nonwindows")
        : 3 == num && (cf.download_button_type.value = "smartphone"),
      (cf.action = "/apply.cgi?/vpn_frame.htm timestamp=" + ts),
      (cf.submit_flag.value = "vpn_compress_conf"),
      (cf.anticsrf.value = vpn_compress_conf_token),
      cf.submit(),
      !0);
}
function check_all_port(int_used_port, type) {
  var ret = !0;
  return (
    0 ==
      check_vpn_port_range(
        "forwardingArray",
        forward_array_num,
        int_used_port,
        type
      ) && (ret = !1),
    0 ==
      check_vpn_port_range(
        "triggeringArray",
        trigger_array_num,
        int_used_port,
        type
      ) && (ret = !1),
    0 ==
      check_vpn_port_range("upnpArray", upnp_array_num, int_used_port, type) &&
      (ret = !1),
    1 == usb_router_flag &&
      "UDP" != type &&
      0 == check_readyshare_port(int_used_port, int_used_port, "ALL") &&
      (ret = !1),
    "1" == endis_remote &&
      "UDP" != type &&
      parseInt(remote_port) == int_used_port &&
      (ret = !1),
    123 == int_used_port && "1" == endis_ntp && "TCP" != type && (ret = !1),
    1900 == int_used_port && "1" == endis_upnp && "TCP" != type && (ret = !1),
    5050 == int_used_port &&
      "bigpond" == info_get_wanproto &&
      "TCP" != type &&
      (ret = !1),
    ret
  );
}
function check_vpn_port_range(name, length, port_using, type) {
  var i, str, each_info, sertype, startport, endport, serflag;
  for (i = 1; i <= length; i++) {
    switch (name) {
      case "forwardingArray":
        (str = eval(name + i)),
          (each_info = str.split(" ")),
          (sertype = each_info[1]),
          (startport = each_info[2]),
          (endport = each_info[3]);
        break;
      case "triggeringArray":
        (str = eval(name + i)),
          (each_info = str.split(" ")),
          (sertype = each_info[5]),
          (startport = each_info[6]),
          (endport = each_info[7]);
        break;
      case "upnpArray":
        (str = eval(name + i)),
          (each_info = str.split(";")),
          (sertype = each_info[1]),
          (startport = each_info[3]),
          (endport = each_info[3]);
    }
    if (
      (sertype == type || "TCP/UDP" == sertype) &&
      parseInt(startport) <= parseInt(port_using) &&
      parseInt(endport) >= parseInt(port_using)
    )
      return !1;
  }
  return !0;
}
