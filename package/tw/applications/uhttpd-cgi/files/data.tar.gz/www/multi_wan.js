var tabs = {
  wan1: { name: "WAN 1", link: "BAS_basic.htm" },
  wan2: { name: "WAN 2", link: "BAS_basicx.htm" },
  dual_wan: { name: "Dual WAN Policy", link: "Dual_wan.htm" },
};
function show_wan_tabs(cur_tab) {
  if (1 == getTop(window).have_multi_wan) {
    var tabs_html = '<tr id="labels"><td colspan=2>';
    for (var k in tabs) {
      tabs_html +=
        '<div class="label_unclick" id="' +
        k +
        '" onclick="click_tab(\'' +
        k +
        '\')">                        <div class="label_left"></div><div class="label_middle"><b><span>' +
        tabs[k].name +
        '</span></b></div>                        <div class="label_right"></div></div>';
    }
    (tabs_html += "</td></tr>"),
      document.write(tabs_html),
      (document.getElementById(cur_tab).className =
        "dual_wan" == cur_tab ? "label_click label_click-2" : "label_click");
  }
}
function click_tab(tab) {
  var tab_link = {};
  for (var k in tabs) tab_link[k] = tabs[k].link;
  var cur_tab = {};
  if (
    ((cur_tab[tab] = tab_link[tab]),
    delete tab_link[tab],
    document.getElementById(tab))
  ) {
    for (var k in ((document.getElementById(tab).className =
      "dual_wan" == tab ? "label_click label_click-2" : "label_click"),
    tab_link))
      document.getElementById(k) &&
        (document.getElementById(k).className = "label_unclick");
    location.href = cur_tab[tab];
  }
}
function check_dual_wan(cf) {
  if (
    (1 == cf.detect_method_rd[0].checked
      ? (cf.hidden_detect_method.value = "dns")
      : 1 == cf.detect_method_rd[1].checked &&
        (cf.hidden_detect_method.value = "ip"),
    (cf.hidden_detect_ip.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    1 == cf.detect_method_rd[0].checked && "" == cf.hostname_tx.value)
  )
    return alert("$hostname_null"), !1;
  if (1 == cf.detect_method_rd[1].checked) {
    if ("..." == cf.hidden_detect_ip.value) return alert("$invalid_myip"), !1;
    if (0 == checkipaddr(cf.hidden_detect_ip.value))
      return alert("$invalid_myip"), !1;
  }
  return cf.submit(), !0;
}
function goto_wanx_page() {
  "pptp" == old_wan_type
    ? (this.location.href = "BAS_pptpx.htm")
    : "l2tp" == old_wan_type
    ? (this.location.href = "BAS_l2tpx.htm")
    : (this.location.href = "BAS_pppoex.htm");
}
function change_servx(cf) {
  "PPTP" == cf.login_type.value
    ? (this.location.href = "BAS_pptpx.htm")
    : "L2TP" == cf.login_type.value
    ? (this.location.href = "BAS_l2tpx.htm")
    : (this.location.href = "BAS_pppoex.htm");
}
