/**
 * @typedef {{
 *    latency: number,
 *    download: number,
 *    upload: number,
 *    status: number | "End" | "Overtime" | "Error" | "NotRunning",
 *    timestamp: string
 *  }} SpeedTestResult
 */

/**
 * @type {SpeedTestResult[]}
 */
var speedTestHistorys = [];

var ookla_cancel_speedtest_anticsrf =
  '<% generateToken("ookla_cancel_speedtest") %>';

var updateSpeedTestInterval = 0;

$$(loadvalue);

function loadvalue() {
  $$("#historyTableTR").hide();
  $$("#historyBtn").on("click", showHistory);
  $$("#speedtest").on("click", ookla_speedtest);
  refreshHistory();
}

function ookla_speedtest_done(interval) {
  clearInterval(interval);
  refreshHistory();
}

function cancel_speedtest() {
  $$.post(
    "/func.cgi",
    {
      submit_flag: "ookla_cancel_speedtest",
      anticsrf: ookla_cancel_speedtest_anticsrf,
    },
    function () {
      $$("#latency").text("");
      $$("#download").text("");
      $$("#upload").text("");
      $$("#speedtest").val("$test_speed");
      $$("#speedtest").off("click");
      $$("#speedtest").on("click", ookla_speedtest);
      $$("#indicate").text("$speedtest_results_title");

      ookla_speedtest_done(updateSpeedTestInterval);
      changeImg("#ookla_status_img", "./images/SpeedTestLogo-55c469b.png");
    }
  );
}

/**
 * @param query {string}
 * @param src {string}
 */
function changeImg(query, src) {
  if ($$(query).attr("src") !== src) {
    $$(query).attr("src", src);
  }
}

function ookla_speedtest() {
  var form = document.forms[0];
  var param = $$(form).serialize();
  $$.post("/func.cgi", param, function (data) {
    if (data === "ok") {
      updateSpeedTestInterval = setInterval(function () {
        $$.getJSON(
          "/ookla_speedtest_result.json",
          /**
           * @param res {SpeedTestResult}
           */
          function (res) {
            var status = "none";
            $$("#latency").text(res.latency.toFixed(2));
            $$("#download").text(((res.download * 8) / 1000000).toFixed(2));
            $$("#upload").text(((res.upload * 8) / 1000000).toFixed(2));
            if (
              res.status === "End" ||
              res.status === "Error" ||
              res.status === "Overtime"
            ) {
              $$("#speedtest").val("$test_again");
              $$("#speedtest").off("click");
              $$("#speedtest").on("click", ookla_speedtest);
              $$("#indicate").text("$speedtest_results_title");

              ookla_speedtest_done(updateSpeedTestInterval);
            } else if (typeof res.status === "number") {
              if (res.status < 10) {
                status = "ping";
              } else if (res.status < 55) {
                status = "download";
              } else if (res.status < 100) {
                status = "upload";
              }
            } else {
              ookla_speedtest_done(updateSpeedTestInterval);
            }

            switch (status) {
              case "ping":
              case "download":
                changeImg(
                  "#ookla_status_img",
                  "./images/SpeedTestLogoDown-28859f8.png"
                );
                break;
              case "upload":
                changeImg("#ookla_status_img", "./images/SpeedTestLogoUp-74ec9fd.png");
                break;
              default:
                changeImg("#ookla_status_img", "./images/SpeedTestLogo-55c469b.png");
                break;
            }
          }
        ).fail(function () {
          ookla_speedtest_done(updateSpeedTestInterval);
        });
      }, 1000);
    }
  });

  $$("#speedtest").val("$cancel_test");
  $$("#speedtest").off("click");
  $$("#speedtest").on("click", cancel_speedtest);
  $$("#indicate").text("$speedtest_ing_title");
  $$("#ookla_status_img").attr("src", "./images/SpeedTestLogoDown-28859f8.png");
  $$("#latency").text((0).toFixed(2));
  $$("#download").text((0).toFixed(2));
  $$("#upload").text((0).toFixed(2));

  return true;
}

function showHistory() {
  $$("#historyTableTR").show();
  $$("#historyBtn").text("$hide_history");
  $$("#historyBtn").off("click");
  $$("#historyBtn").on("click", hideHistory);
}

function hideHistory() {
  $$("#historyTableTR").hide();
  $$("#historyBtn").text("$view_history");
  $$("#historyBtn").off("click");
  $$("#historyBtn").on("click", showHistory);
}

/**
 * @param num {number}
 */
function formatNumber(num) {
  return num >= 10 ? num : "0" + num;
}

/**
 * @param date {Date}
 */
function formatTime(date) {
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  // var sec = date.getSeconds();
  var standard = hour > 12 ? "PM" : "AM";

  return (
    "" +
    year +
    "-" +
    formatNumber(month) +
    "-" +
    formatNumber(day) +
    " " +
    formatNumber(hour) +
    ":" +
    formatNumber(minute) +
    " " +
    standard
  );
}

function refreshHistory() {
  $$.getJSON(
    "/ookla_speedtest_history.json",
    /**
     * @param historys {SpeedTestResult[]}
     */
    function (historys) {
      $$("#historyTable tbody").empty();
      $$.each(historys, function (idx, history) {
        $$("#historyTable tbody").append(
          "<tr class='even_line_new'><td>" +
            (idx + 1) +
            "</td><td>" +
            history.latency +
            " " +
            "ms" +
            "</td><td>" +
            ((history.download * 8) / 1000000).toFixed(2) +
            " " +
            "Mbps" +
            "</td><td>" +
            ((history.upload * 8) / 1000000).toFixed(2) +
            " " +
            "Mbps" +
            "</td><td>" +
            (history.status === "End" ? "Success" : "Fail") +
            "</td><td>" +
            (history.timestamp != "" ? formatTime(new Date(history.timestamp)) : "--") +
            "</td></tr>"
        );
      });
    }
  );
}
