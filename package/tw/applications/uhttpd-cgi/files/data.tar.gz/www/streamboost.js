function select_lable(num) {
  if (0 != top.enable_action) {
    if (
      (0 == num &&
        ((document.getElementById("streamboost_qos").className =
          "label_click label_click-2"),
        (document.getElementById("wmm").className = "label_unclick")),
      1 == num)
    ) {
      if (
        -1 != this.location.href.indexOf("QOS_dynamic.htm") &&
        (1 == first_flag ||
          (0 == first_flag && 1 == parent.ookla_speedtest_flag))
      )
        return;
      (document.getElementById("wmm").className = "label_click label_click-2"),
        (document.getElementById("streamboost_qos").className =
          "label_unclick");
    }
    (select_num = num),
      0 == select_num
        ? goto_formframe("QOS_dynamic.htm")
        : (this.location.href = "QOS_wmm.htm");
  }
}
function wmmMain() {
  location.href = "QOS_wmm.htm";
}
function qos_advanced() {
  if (0 != $$("#speedtest").get(0).disabled) {
    var cf = document.forms[0];
    (cf.hid_cancel_speedtest.value = "1"),
      "1" == first_flag ||
      (1 == parent.ookla_speedtest_flag && "0" == first_flag)
        ? ((cf.hid_trend_micro_enable.value = 0),
          (cf.hid_first_flag.value = "0"),
          (parent.ookla_speedtest_flag = 0))
        : 1 == parent.ookla_speedtest_flag && (parent.ookla_speedtest_flag = 0),
      check_confirm(cf, "QOS_dynamic.htm", ts),
      enable_links();
  } else this.location.href = "QOS_dynamic.htm";
}
function qos_basic() {
  location.href = "QOS_basic.htm";
}
function format_version(vir) {
  var head = vir.substring(0, 4),
    middle = vir.substring(4, 8),
    tail = vir.substring(15);
  return (parseInt(head) % 2013) + "." + middle + "." + tail;
}
function format_time(time) {
  var year = time.substring(0, 4),
    mouth = time.substring(4, 6),
    day = time.substring(6);
  return (
    new Array(
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    )[parseInt(mouth) - 1] +
    " " +
    day +
    ", " +
    year
  );
}
function confirm_dialox() {
  document.forms[0];
  window
    .open(
      "QOS_improve_service.htm",
      "newwindow",
      "resizable=no,scrollbars=no,toolbar=no,menubar=no,status=no,location=no,alwaysRaised=yes,z-look=yes,width=800,height=600,left=200,top=100"
    )
    .focus();
}
function setSpeed(num) {
  "2" == num
    ? (sAlert("$set_bandwidth_warning"),
      (document.getElementById("define_radio1").style.display = ""),
      (document.getElementById("define_radio2").style.display = ""),
      (document.getElementById("speedtest_content").style.display = "none"))
    : ((document.getElementById("define_radio1").style.display = "none"),
      (document.getElementById("define_radio2").style.display = "none"),
      (document.getElementById("speedtest_content").style.display = ""));
}
function clearNoNum(obj) {
  (obj.value = obj.value.replace(/[^\d.]/g, "")),
    (obj.value = obj.value.replace(/^\./g, "")),
    (obj.value = obj.value.replace(/\.{2,}/g, ".")),
    (obj.value = obj.value
      .replace(".", "$#$")
      .replace(/\./g, "")
      .replace("$#$", ".")),
    (obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d)(\d).*$/, "$$1$$2.$$3"));
}
function check_qos_apply(cf) {
  1 == (cf = document.forms[0]).dynamic_qos_enable.checked
    ? (cf.hid_trend_micro_enable.value = 1)
    : (cf.hid_trend_micro_enable.value = 0),
    1 == cf.AutoUpdateEnable.checked
      ? (cf.hid_detect_database.value = 1)
      : ((cf.hid_detect_database.value = 0),
        (cf.hid_update_agreement.value = "1")),
    1 == cf.help_improve.checked
      ? (cf.hid_improve_service.value = 1)
      : (cf.hid_improve_service.value = 0),
    1 == cf.qosSetting[0].checked
      ? (cf.hid_bandwidth_type.value = 0)
      : (cf.hid_bandwidth_type.value = 1),
    1 == cf.AutoUpdateEnable.checked &&
    ("0" != first_flag ||
      ("0" == first_flag && 0 == cf.qosSetting[0].checked)) &&
    "1" == update_agreement &&
    "1" == cf.hid_trend_micro_enable.value
      ? sAlert(
          "$share_mac_warn",
          function () {
            (document.forms[0].hid_update_agreement.value = "0"),
              check_qos_apply2();
          },
          function () {
            var cf = document.forms[0];
            (cf.AutoUpdateEnable.checked = !1),
              (cf.hid_detect_database.value = 0),
              (cf.hid_update_agreement.value = "1"),
              check_qos_apply2();
          }
        )
      : check_qos_apply2();
}
function check_qos_apply2() {
  var cf = document.forms[0];
  1 == cf.qosSetting[0].checked && "1" == cf.hid_trend_micro_enable.value
    ? "0" == first_flag
      ? sAlert(
          "$warning_bandwidth",
          function () {
            var cf = document.forms[0];
            if ("0" == internet_status) return sAlert("$internet_down"), !1;
            (cf.hid_first_flag.value = "1"),
              parent.ookla_speedtest_flag,
              grayout_menu_links(),
              check_qos_apply3();
          },
          function () {
            return !1;
          }
        )
      : ((cf.hid_first_flag.value = "2"), check_qos_apply3())
    : check_qos_apply3();
}
function check_qos_apply3() {
  var cf = document.forms[0],
    trend_micro_uplink = parseFloat(cf.uplink_value.value).toFixed(2),
    trend_micro_downlink = parseFloat(cf.downlink_value.value).toFixed(2),
    invalid = 0;
  if (
    (isNaN(trend_micro_downlink) || isNaN(trend_micro_uplink)
      ? (invalid = 1)
      : ((cf.downlink_value.value = trend_micro_downlink),
        (cf.uplink_value.value = trend_micro_uplink)),
    1 == cf.qosSetting[1].checked)
  ) {
    if ("0" == internet_status && "1" == cf.hid_trend_micro_enable.value)
      return sAlert("$internet_down"), !1;
    if ("" == cf.uplink_value.value || "" == cf.downlink_value.value)
      return sAlert("$max_required"), !1;
    if (
      trend_micro_uplink < 0.1 ||
      trend_micro_uplink > 1e3 ||
      trend_micro_downlink < 0.1 ||
      trend_micro_downlink > 1e3 ||
      1 == invalid
    )
      return sAlert("$range_error"), !1;
    (cf.hid_trend_micro_uplink.value = parseInt(
      (1e6 * cf.uplink_value.value) / 8
    )),
      (cf.hid_trend_micro_downlink.value = parseInt(
        (1e6 * cf.downlink_value.value) / 8
      )),
      "0" == first_flag
        ? (cf.hid_first_flag.value = "0")
        : (cf.hid_first_flag.value = "2");
  }
  cf.submit();
}
function check_wmm_apply(cf) {
  1 == cf.wmm_enable_2g.checked
    ? (cf.qos_endis_wmm.value = 1)
    : (cf.qos_endis_wmm.value = 0),
    1 == cf.wmm_enable_5g.checked
      ? (cf.qos_endis_wmm_a.value = 1)
      : (cf.qos_endis_wmm_a.value = 0),
    1 == getTop(window).tri_router_flag &&
      (1 == cf.wmm_enable_5g_2nd.checked
        ? (cf.qos_endis_wmm_a_2nd.value = 1)
        : (cf.qos_endis_wmm_a_2nd.value = 0)),
    cf.submit();
}
function check_confirm(cf, url) {
  (cf.hid_bandwidth_type.value = 0),
    "" == cf.uplink_value.value
      ? (cf.hid_trend_micro_uplink.value = "")
      : (cf.hid_trend_micro_uplink.value = parseInt(
          (1e6 * cf.uplink_value.value) / 8
        )),
    "" == cf.downlink_value.value
      ? (cf.hid_trend_micro_downlink.value = "")
      : (cf.hid_trend_micro_downlink.value = parseInt(
          (1e6 * cf.downlink_value.value) / 8
        )),
    1 == cf.AutoUpdateEnable.checked
      ? (cf.hid_detect_database.value = 1)
      : (cf.hid_detect_database.value = 0),
    1 == cf.help_improve.checked
      ? (cf.hid_improve_service.value = 1)
      : (cf.hid_improve_service.value = 0),
    (cf.submit_flag.value = "apply_trend_micro"),
    (cf.anticsrf.value = apply_trend_micro_token),
    (cf.action = "/apply.cgi?/" + url + " timestamp=" + ts),
    cf.submit();
}
function check_basic_ookla_speedtest(form) {
  return "0" == internet_status
    ? (sAlert("$internet_down"), !1)
    : ((parent.ookla_speedtest_flag = 1),
      (form.submit_flag.value = "ookla_speedtest"),
      (form.anticsrf.value = ookla_speedtest_token),
      (form.action = "/func.cgi?/QOS_basic.htm timestamp=" + ts),
      form.submit(),
      !0);
}
function check_ookla_speedtest(form) {
  if ("0" == internet_status && location.href.indexOf("QOS_dynamic.htm") > 0)
    return (
      (getObj("indicate").innerHTML = "$speedtest_connect"),
      (getObj("indicate").style.color = "red"),
      !1
    );
  if (location.href.indexOf("QOS_dynamic.htm") > 0)
    (form.submit_flag.value = "ookla_speedtest"),
    (form.anticsrf.value = ookla_speedtest_token),
      (form.action = "/func.cgi?/QOS_dynamic.htm timestamp=" + ts),
      (parent.ookla_speedtest_flag = 1);
  else if (location.href.indexOf("QOS_basic_setting.htm") > 0) {
    if ("0" == internet_status) return sAlert("$internet_down"), !1;
    (form.submit_flag.value = "basic_qos_ookla_speedtest"),
    (form.anticsrf.value = basic_qos_ookla_speedtest_token),
      (form.action = "/func.cgi?/QOS_basic_setting.htm timestamp=" + ts),
      (parent.basic_qos_ookla_speedtest_flag = 1);
  }
  return grayout_menu_links(), form.submit(), !0;
}
function enable_links() {
  (top.enable_action = 1),
    top.location.href.indexOf("adv_index.htm") > -1
      ? (getTop(window).menu_class_default(),
        getTop(window).subItemsClass("setup_sub"),
        getTop(window).enabledItemsClass(),
        "none" ==
          parent.window.document.getElementById("setup_sub").style.display &&
          getTop(window).open_or_close_sub("setup"),
        getTop(window).menu_color_change("qos"))
      : (basic_menu_class_default(),
        (parent.window.document.getElementById("intqos").className =
          "basic_button_purple"));
}
function grayout_menu_links() {
  if (
    ((top.enable_action = 0), top.location.href.indexOf("adv_index.htm") > -1)
  )
    getTop(window).enabledItemsClass(),
      (parent.window.document.getElementById("adv_home").className =
        "advanced_grey_button_double"),
      (parent.window.document.getElementById("adv_setup_wizard").className =
        "advanced_grey_button_double"),
      (parent.window.document.getElementById("adv_wps").className =
        "advanced_grey_button_double");
  else
    for (
      var div_list = parent.window.document.getElementsByTagName("div"), i = 0;
      i < div_list.length;
      i++
    )
      -1 != div_list[i].className.indexOf("basic_button") &&
        "basic_button_purple" != div_list[i].className &&
        (div_list[i].className = div_list[i].className + "_grey");
}
function check_basic_manual_update(form) {
  return "0" == internet_status
    ? (sAlert("$internet_down"), !1)
    : ((form.submit_flag.value = "detect_update"),
      (form.anticsrf.value = detect_update_token),
      (form.action = "/apply.cgi?/QOS_basic.htm timestamp=" + ts),
      form.submit(),
      !0);
}
function check_manual_update(form) {
  return "0" == internet_status
    ? (sAlert("$internet_down"), !1)
    : ((form.submit_flag.value = "detect_update"),
      (form.anticsrf.value = detect_update_token),
      (form.action = "/apply.cgi?/QOS_dynamic.htm timestamp=" + ts),
      form.submit(),
      !0);
}
function device_icon(type_name) {
  return (
    (type_name < 1 || type_name > 51) && (type_name = 47),
    "<img src=image/streamboost/" +
      type_name +
      ".jpg width=66px height=44px id=icon_img />"
  );
}
function edit_select_device(mac, ip, name, priority, devtype, contype, onOff) {
  document.forms[0];
  mac && (parent.qos_edit_mac = mac),
    ip && (parent.qos_edit_ip = ip),
    name && (parent.qos_edit_name = name),
    priority && (parent.qos_edit_priority = priority),
    devtype && (parent.qos_edit_devtype = devtype),
    contype && (parent.qos_edit_contype = contype),
    onOff && (parent.qos_edit_onOff = onOff),
    (location.href = "QOS_edit_devices.htm");
}
function edit_select_device_fing(
  mac,
  ip,
  name,
  priority,
  devtype,
  devtype_name,
  model,
  contype
) {
  var cf = document.forms[0];
  mac && (parent.qos_edit_mac = mac),
    ip && (parent.qos_edit_ip = ip),
    (parent.qos_edit_name = name || ""),
    priority && (parent.qos_edit_priority = priority),
    devtype && (parent.qos_edit_devtype = devtype),
    "1" == getTop(window).support_new_ntgrtype &&
      (devtype_name && (parent.qos_edit_devtype_name = devtype_name),
      (parent.qos_edit_model = model || "")),
    contype && (parent.qos_edit_contype = contype),
    (cf.hid_edit_mac.value = parent.qos_edit_mac),
    (cf.submit_flag.value = "select_qos_edit"),
    (cf.anticsrf.value = select_qos_edit_token),
    (cf.action = "/apply.cgi?/QOS_edit_devices.htm timestamp=" + ts),
    cf.submit();
}
function select_device(mac, ip, name, priority, devtype, contype) {
  (parent.qos_edit_mac = mac),
    (parent.qos_edit_ip = ip),
    (parent.qos_edit_name = name),
    (parent.qos_edit_priority = priority),
    (parent.qos_edit_devtype = devtype),
    (parent.qos_edit_contype = contype),
    1 == top.is_ru_version
      ? (document.getElementsByName("edit")[0].className = "common_bt")
      : (document.getElementsByName("edit")[0].className = "short_common_bt"),
    (document.getElementsByName("edit")[0].disabled = !1);
}
function show_bora(type) {
  var device_bora = "";
  return (
    "1" == enable_block_device &&
      (device_bora =
        "Allowed" == type
          ? "<b style='color:#5bb6e5'>$acc_allow</b>"
          : "<b style='color:#ff1300'>$acc_block</b>"),
    device_bora
  );
}
function show_icon_name(num) {
  return "1" == num
    ? "$qos_device1"
    : "2" == num
    ? "$qos_device2"
    : "3" == num
    ? "$qos_device3"
    : "4" == num
    ? "$qos_device4"
    : "5" == num
    ? "$qos_device5"
    : "6" == num
    ? "$qos_device6"
    : "7" == num
    ? "$qos_device7"
    : "8" == num
    ? "$qos_device8"
    : "9" == num
    ? "$qos_device9"
    : "10" == num
    ? "$qos_device10"
    : "11" == num
    ? "$qos_device11"
    : "12" == num
    ? "$qos_device12"
    : "13" == num
    ? "$qos_device13"
    : "14" == num
    ? "$qos_device14"
    : "15" == num
    ? "$qos_device15"
    : "16" == num
    ? "$qos_device16"
    : "17" == num
    ? "$qos_device17"
    : "18" == num
    ? "$qos_device18"
    : "19" == num
    ? "$qos_device19"
    : "20" == num
    ? "$qos_device20"
    : "21" == num
    ? "$qos_device21"
    : "22" == num
    ? "$qos_device22"
    : "23" == num
    ? "$qos_device23"
    : "24" == num
    ? "$qos_device24"
    : "25" == num
    ? "$qos_device25"
    : "26" == num
    ? "$qos_device26"
    : "27" == num
    ? "$qos_device27"
    : "28" == num
    ? "$qos_device28"
    : "29" == num
    ? "$qos_device29"
    : "30" == num
    ? "$qos_device30"
    : "31" == num
    ? "$qos_device31"
    : "32" == num
    ? "$qos_device32"
    : "33" == num
    ? "$qos_device33"
    : "34" == num
    ? "$qos_device34"
    : "35" == num
    ? "$qos_device35"
    : "36" == num
    ? "$qos_device36"
    : "37" == num
    ? "$qos_device37"
    : "38" == num
    ? "$qos_device38"
    : "39" == num
    ? "$qos_device39"
    : "40" == num
    ? "$qos_device40"
    : "41" == num
    ? "$qos_device41"
    : "42" == num
    ? "$qos_device42"
    : "43" == num
    ? "$qos_device43"
    : "44" == num
    ? "$qos_device44"
    : "45" == num
    ? "$qos_device45"
    : "46" == num
    ? "$qos_device46"
    : "47" == num
    ? "$qos_device47"
    : "48" == num
    ? "$qos_device48"
    : "49" == num
    ? "$qos_device49"
    : "50" == num
    ? "$qos_device50"
    : "51" == num
    ? "$qos_device51"
    : "$qos_device47";
}
function show_type_name(name) {
  return "wired" == name
    ? "$acc_wired"
    : "primary" == name
    ? "2.4G $wireless"
    : "guest" == name
    ? "2.4G $guest_wireless"
    : "gre" == name
    ? "2.4G $guest_wireless"
    : "primary_an" == name
    ? "5G $wireless"
    : "guest_an" == name
    ? "5G $guest_wireless"
    : "gre_an" == name
    ? "5G $guest_wireless"
    : "vpn" == name
    ? "$qos_vpn"
    : "primary_ad" == name
    ? "60G $wireless"
    : "$acc_wired";
}
function sort_bandwidth(a, b) {
  return a.down_rate < b.down_rate ? 1 : -1;
}
function sort_alp(a, b) {
  return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1;
}
function sort_con(a, b) {
  return a.contype < b.contype ? 1 : -1;
}
function sort_on_off(a, b) {
  return a.isOnOff < b.isOnOff ? 1 : -1;
}
function show_type2(name) {
  return "wired" == name
    ? "<img src=image/eth.gif />"
    : "primary" == name
    ? "<img src=image/wifi.png /><b class='short'>2.4G</b>"
    : "guest" == name
    ? "<img src=image/wifi.png /><b class='long'>2.4G Guest</b>"
    : "gre" == name
    ? "<img src=image/wifi.png /><b class='long'>2.4G Guest</b>"
    : "primary_an" == name
    ? "<img src=image/wifi.png /><b class='short'>5G</b>"
    : "guest_an" == name
    ? "<img src=image/wifi.png /><b class='long'>5G Guest</b>"
    : "gre_an" == name
    ? "<img src=image/wifi.png /><b class='long'>5G Guest</b>"
    : "vpn" == name
    ? "<img src=image/vpn.gif />"
    : "primary_ad" == name
    ? "<img src=image/wifi.png /><b class='short'>60G</b>"
    : "<img src=image/eth.gif />";
}
function show_type(name) {
  return "wired" == name
    ? "<div class='eth'></div>"
    : "primary" == name
    ? "<div class='wifi'>2.4G</div>"
    : "guest" == name
    ? "<div class='wifi'>2.4G Guest</div>"
    : "gre" == name
    ? "<div class='wifi'>2.4G Guest</div>"
    : "primary_an" == name
    ? "<div class='wifi'>5G</div>"
    : "guest_an" == name
    ? "<div class='wifi'>5G Guest</div>"
    : "gre_an" == name
    ? "<div class='wifi'>5G Guest</div>"
    : "vpn" == name
    ? "<div class='contype'></div>"
    : "primary_ad" == name
    ? "<div class='wifi'>60G</div>"
    : "<div class='eth'></div>";
}
function show_priority(pri) {
  return "HIGHEST" == pri
    ? "$qos_highest"
    : "HIGH" == pri
    ? "$qos_high"
    : "MEDIUM" == pri
    ? "$medium_mark"
    : "LOW" == pri
    ? "$qos_low"
    : "$medium_mark";
}
function show_pri_num(pri) {
  return "HIGHEST" == pri
    ? "4"
    : "HIGH" == pri
    ? "3"
    : "MEDIUM" == pri
    ? "2"
    : "LOW" == pri
    ? "1"
    : "2";
}
function TSorter(num) {
  var table = Object,
    trs = Array,
    ths = Array,
    curSortCol = Object,
    prevSortCol = num,
    sortType = Object;
  function get() {}
  function getCell(index) {
    return trs[index].cells[curSortCol];
  }
  function sort(oTH) {
    (curSortCol = oTH.cellIndex),
      (sortType = oTH.abbr),
      (trs = table.tBodies[0].getElementsByTagName("tr")),
      (function (sortType) {
        switch (sortType) {
          case "float_text":
            get = function (index) {
              return parseFloat(getCell(index).firstChild.value);
            };
            break;
          case "str_text":
            get = function (index) {
              return getCell(index).firstChild.value;
            };
            break;
          case "ip_text":
            get = function (index) {
              var value = getCell(index).firstChild.nodeValue,
                each_info = value.split(".");
              return (
                (split_part =
                  parseInt(each_info[0]) +
                  parseInt(each_info[1]) +
                  parseInt(each_info[2]) +
                  parseInt(each_info[3], 10)),
                parseInt(split_part)
              );
            };
            break;
          default:
            get = function (index) {
              return getCell(index).firstChild.nodeValue;
            };
        }
      })(sortType);
    for (var j = 0; j < trs.length; j++)
      "detail_row" == trs[j].className && closeDetails(j + 2);
    prevSortCol == curSortCol
      ? ((oTH.className = "descend" != oTH.className ? "descend" : "ascend"),
        (function () {
          for (var i = 1; i < trs.length; i++)
            table.tBodies[0].insertBefore(trs[i], trs[0]);
        })())
      : ((oTH.className = "descend"),
        "exc_cell" != ths[prevSortCol].className &&
          (ths[prevSortCol].className = ""),
        (function quicksort(lo, hi) {
          if (hi <= lo + 1) return;
          if (hi - lo == 2)
            return void (get(hi - 1) > get(lo) && exchange(hi - 1, lo));
          var i = lo + 1;
          var j = hi - 1;
          get(lo) > get(i) && exchange(i, lo);
          get(j) > get(lo) && exchange(lo, j);
          get(lo) > get(i) && exchange(i, lo);
          var pivot = get(lo);
          for (; 1; ) {
            for (j--; pivot > get(j); ) j--;
            for (i++; get(i) > pivot; ) i++;
            if (j <= i) break;
            exchange(i, j);
          }
          exchange(lo, j);
          j - lo < hi - j
            ? (quicksort(lo, j), quicksort(j + 1, hi))
            : (quicksort(j + 1, hi), quicksort(lo, j));
        })(0, trs.length)),
      (prevSortCol = curSortCol);
  }
  function exchange(i, j) {
    if (i == j + 1) table.tBodies[0].insertBefore(trs[i], trs[j]);
    else if (j == i + 1) table.tBodies[0].insertBefore(trs[j], trs[i]);
    else {
      var tmpNode = table.tBodies[0].replaceChild(trs[i], trs[j]);
      void 0 === trs[i]
        ? table.appendChild(tmpNode)
        : table.tBodies[0].insertBefore(tmpNode, trs[i]);
    }
  }
  (this.init = function (tableName) {
    (table = document.getElementById(tableName)),
      (ths = table.getElementsByTagName("th"));
    for (var i = 1; i < ths.length; i++)
      ths[i].onclick = function () {
        sort(this);
      };
    return !0;
  }),
    (this.def_sort = function (tableName, defNum) {
      return (
        (table = document.getElementById(tableName)),
        sort((ths = table.getElementsByTagName("th"))[defNum]),
        !0
      );
    });
}
function show_or_hid_refresh(cf, tag) {
  0 == tag
    ? (cf.enable_auto_refresh.checked
        ? (cf.hid_dev_auto_refresh.value = "1")
        : (cf.hid_dev_auto_refresh.value = "0"),
      (cf.action = "/apply.cgi?/QOS_show_device.htm timestamp=" + ts),
      (cf.submit_flag.value = "auto_refresh_value"),
      (cf.anticsrf.value = auto_refresh_value_token),
      cf.submit())
    : (cf.enable_auto_refresh.checked
        ? (cf.hid_ap_auto_refresh.value = "1")
        : (cf.hid_ap_auto_refresh.value = "0"),
      cf.submit());
}
var type_list = {
  1: ["Amazon Kindle", "20", "1"],
  2: ["Android Device", "20", "2"],
  3: ["Android Phone", "30", "3"],
  4: ["Android Tablet", "20", "4"],
  5: ["Apple Airport Express", "20", "5"],
  6: ["Blu-ray player", "10", "6"],
  7: ["Bridge", "20", "7"],
  8: ["Cable STB", "10", "8"],
  9: ["Camera", "30", "9"],
  10: ["Router", "20", "10"],
  11: ["DVR", "10", "11"],
  12: ["Gaming Console", "10", "12"],
  13: ["iMac", "20", "13"],
  14: ["iPad", "20", "14"],
  15: ["iPad mini", "20", "15"],
  16: ["iPhone 5/5S/5C", "30 ", "16"],
  17: ["iPhone", "30", "17"],
  18: ["iPod Touch", "30", "18"],
  19: ["Linux PC", "20", "19"],
  20: ["Mac mini", "20", "20"],
  21: ["Mac Pro", "20", "21"],
  22: ["Mac Book", "20", "22"],
  23: ["Media Device", "10", "23"],
  24: ["Network Device", "30", "24"],
  25: ["Other STB", "10", "25"],
  26: ["Powerline", "20", "26"],
  27: ["Printer", "30", "27"],
  28: ["Repeater", "20", "28"],
  29: ["Satellite STB", "10", "29"],
  30: ["scanner", "30", "30"],
  31: ["Sling box", "10", "31"],
  32: ["Smart phone", "30", "32"],
  33: ["Storage (NAS)", "40", "33"],
  34: ["Switch", "20", "34"],
  35: ["TV", "10", "35"],
  36: ["Tablet", "20", "36"],
  37: ["Unix PC", "20", "37"],
  38: ["Windows PC", "20", "38"],
  39: ["Surface", "20", "39"],
  40: ["Wifi Extender", "20", "40"],
  41: ["Apple TV", "10", "41"],
  42: ["AV Receiver", "10", "42"],
  43: ["Chromcast", "10", "43"],
  44: ["Google Nexus 5", "30 ", "44"],
  45: ["Google Nexus 7", "30", "45"],
  46: ["Google Nexus 10", "20", "46"],
  47: ["Other", "30", "47"],
  48: ["WN1000RP", "20", "48"],
  49: ["WN2500RP", "20", "49"],
  50: ["VoIP", "10", "50"],
  51: ["Iphone6", "30", "51"],
  52: ["Arlo", "20", "52"],
  53: ["Amazon Fire TV", "20", "53"],
  54: ["Smart Watch", "20", "54"],
};
