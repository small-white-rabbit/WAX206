function click_backup() {
  (document.forms[0].action = "/backup.cgi?/BAK_backup.htm timestamp=" + ts),
    document.forms[0].submit();
}
function check_restore() {
  if (((cf = document.forms[0]), 0 == cf.mtenRestoreCfg.value.length))
    return alert("$filename_null"), !1;
  var filestr = cf.mtenRestoreCfg.value;
  return "cfg" != filestr.substr(filestr.lastIndexOf(".") + 1)
    ? (alert("$not_correct_file" + "cfg"), !1)
    : 0 == check_size(100, "M", "restore_cfg")
    ? (alert("$restore_select_correct"), !1)
    : !!confirm("$ask_for_restore") &&
      ((cf.action = "/restore.cgi?/restore_process.htm timestamp=" + ts),
      top_left_nolink(),
      (getTop(window).enable_action = 0),
      void cf.submit());
}
function click_yesfactory() {
  (cf = document.forms[0]),
    (cf.action = "/apply.cgi?/pls_wait_factory_reboot.html timestamp=" + ts),
    top_left_nolink(),
    (getTop(window).enable_action = 0),
    cf.submit();
}
