function check_static_ip_mask_gtw() {
  return (
    (form = document.forms[0]),
    (form.hid_ap_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    (form.hid_ap_subnet.value =
      form.WMask1.value +
      "." +
      form.WMask2.value +
      "." +
      form.WMask3.value +
      "." +
      form.WMask4.value),
    (form.hid_ap_gateway.value =
      form.WGateway1.value +
      "." +
      form.WGateway2.value +
      "." +
      form.WGateway3.value +
      "." +
      form.WGateway4.value),
    0 == checkipaddr(form.hid_ap_ipaddr.value) ||
    0 ==
      is_sub_or_broad(
        form.hid_ap_ipaddr.value,
        form.hid_ap_ipaddr.value,
        form.hid_ap_subnet.value
      )
      ? (alert("$invalid_ip"), !1)
      : 0 == checksubnet(form.hid_ap_subnet.value, 0)
      ? (alert("$invalid_mask"), !1)
      : 0 == checkgateway(form.hid_ap_gateway.value) ||
        0 ==
          is_sub_or_broad(
            form.hid_ap_gateway.value,
            form.hid_ap_gateway.value,
            form.hid_ap_subnet.value
          )
      ? (alert("$invalid_gateway"), !1)
      : 0 ==
        isGateway(
          form.hid_ap_ipaddr.value,
          form.hid_ap_subnet.value,
          form.hid_ap_gateway.value
        )
      ? (alert("$invalid_gateway"), !1)
      : 1 == isSameIp(form.hid_ap_ipaddr.value, form.hid_ap_gateway.value)
      ? (alert("$invalid_gateway"), !1)
      : 0 !=
          isSameSubNet(
            form.hid_ap_ipaddr.value,
            form.hid_ap_subnet.value,
            form.hid_ap_gateway.value,
            form.hid_ap_subnet.value
          ) || (alert("$same_subnet_ip_gtw"), !1)
  );
}
function check_static_dns(wan_assign) {
  var form = document.forms[0];
  return (
    (form.ap_dnsaddr1.value =
      form.DAddr1.value +
      "." +
      form.DAddr2.value +
      "." +
      form.DAddr3.value +
      "." +
      form.DAddr4.value),
    (form.ap_dnsaddr2.value =
      form.PDAddr1.value +
      "." +
      form.PDAddr2.value +
      "." +
      form.PDAddr3.value +
      "." +
      form.PDAddr4.value),
    (form.hid_ap_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    "..." == form.ap_dnsaddr1.value && (form.ap_dnsaddr1.value = ""),
    "..." == form.ap_dnsaddr2.value && (form.ap_dnsaddr2.value = ""),
    !!check_DNS(
      form.ap_dnsaddr1.value,
      form.ap_dnsaddr2.value,
      wan_assign,
      form.hid_ap_ipaddr.value
    )
  );
}
function handle_smart_connect() {
  var cf = document.forms[0];
  if (cf.enable_smart_connect.checked == true)
  {
    if ((wireless1_band != "both") && (wireless2_band != "both") && (wireless3_band != "both") || 
        ('0' == con_endis_wl_radio && '1' == con_endis_wla_radio) || 
        ('1' == con_endis_wl_radio && '0' == con_endis_wla_radio))
    {
        cf.enable_smart_connect.checked = false;
        return alert("$smart_connect_alarm");
    }
  }

  cf.enable_smart_connect.checked
    ? ((an_router_flag = "0"),
      (document.getElementById("bgn_settings_title").innerHTML =
        "$adva_wlan_setting (2.4GHz $w2_suffix & " +
        (ac_router_flag ? "5GHz 802.11$w5_suffix)" : "5GHz $w5_suffix)")))
    : ((an_router_flag = org_an_router_flag),
      (document.getElementById("bgn_settings_title").innerHTML =
        "$adva_wlan_setting" + (an_router_flag ? "(2.4GHz $w2_suffix)" : ""))),
    change_web_format(),
    cf.enable_smart_connect.checked
      ? ((document.getElementById("wladv_pin").style.display = "none"),
        (document.getElementById("wladv_enable_wps").style.display = "none"),
        (document.getElementById("wladv_appin_cfg").style.display = "none"),
        (document.getElementById("wladv_keep_exist").style.display = "none"),
        (document.getElementById("wps_blank_line").style.display = "none"),
        (document.getElementById("wps_settings_title").innerHTML =
          "$wps_smart"))
      : ("0" != wps_pin_support &&
          ((document.getElementById("wladv_pin").style.display = ""),
          (document.getElementById("wladv_enable_wps").style.display = ""),
          (document.getElementById("wladv_appin_cfg").style.display = "")),
        (document.getElementById("wladv_keep_exist").style.display = ""),
        (document.getElementById("wps_blank_line").style.display = ""),
        (document.getElementById("wps_settings_title").innerHTML =
          "$wlan_adv_wps")),
    (an_router_flag = org_an_router_flag);
}
function wl_frag_change() {
  1 == document.forms[0].opmode.options[0].selected
    ? (document.getElementById("frag_bgn").style.display = "")
    : (document.getElementById("frag_bgn").style.display = "none");
}
function checkadv(form) {
  if (form.enable_smart_connect.checked == true)
  {
    if ((wireless1_band != "both") && (wireless2_band != "both") && (wireless3_band != "both"))
    {
        form.enable_smart_connect.checked == false;
        return alert("$smart_connect_alarm");
    }
  }
 
  if (0 == check_wlan()) return !1;
  if ("" == form.rts.value || "" == form.rts_an.value)
    return alert("$rts_range"), !1;
  if (
    !(
      form.rts.value > 0 &&
      form.rts.value <= 2347 &&
      form.rts_an.value > 0 &&
      form.rts_an.value <= 2347
    )
  )
    return alert("$rts_range"), !1;
  if (
    "" == form.frag.value ||
    ("" == form.frag_an.value && 1 == getTop(window).fragment_an_flag)
  )
    return alert("$fragmentation_range"), !1;
  if (
    !(
      form.frag.value > 255 &&
      form.frag.value < 2347 &&
      ((form.frag_an.value > 255 && form.frag_an.value < 2347) ||
        1 != getTop(window).fragment_an_flag)
    )
  )
    return alert("$fragmentation_range"), !1;
  if (
    (1 == form.wmm_enable.checked
      ? (form.wladv_endis_wmm.value = "1")
      : (form.wladv_endis_wmm.value = "0"),
    1 == form.wmm_enable_a.checked
      ? (form.wladv_endis_wmm_a.value = "1")
      : (form.wladv_endis_wmm_a.value = "0"),
    "Long Preamble" == form.enable_shortpreamble.value
      ? (form.wl_enable_shortpreamble.value = "1")
      : "Short Preamble" == form.enable_shortpreamble.value
      ? (form.wl_enable_shortpreamble.value = "2")
      : "automatic" == form.enable_shortpreamble.value &&
        (form.wl_enable_shortpreamble.value = "0"),
    "Long Preamble" == form.enable_shortpreamble_an.value
      ? (form.wla_enable_shortpreamble.value = "1")
      : "Short Preamble" == form.enable_shortpreamble_an.value
      ? (form.wla_enable_shortpreamble.value = "2")
      : "automatic" == form.enable_shortpreamble_an.value &&
        (form.wla_enable_shortpreamble.value = "0"),
    wlan_txctrl(
      form,
      form.tx_power_ctrl.value,
      form.tx_power_ctrl_an.value,
      form.wla_hidden_wlan_channel.value,
      form.wl_WRegion.value
    ),
    1 == form.enable_ap.checked
      ? (form.wl_enable_router.value = "1")
      : (form.wl_enable_router.value = "0"),
    1 == form.enable_ap_an.checked
      ? (form.wla_enable_router.value = "1")
      : (form.wla_enable_router.value = "0"),
    1 == form.enable_ap_ad.checked
      ? (form.wig_enable_router.value = "1")
      : (form.wig_enable_router.value = "0"),
    1 == form.pin_disable.checked
      ? (form.endis_pin.value = "0")
      : (form.endis_pin.value = "1"),
    1 == form.prevent_pin_compromise.checked
      ? (form.hid_protect_enable.value = "1")
      : (form.hid_protect_enable.value = "0"),
    "" == form.pin_attack_count.value && (form.pin_attack_count.value = "3"),
    (form.pin_attack_count.value = parseInt(form.pin_attack_count.value, 10)),
    1 == form.wsc_config.checked
      ? ((form.endis_wsc_config.value = "5"),
        (form.endis_wsc_config_a.value = "5"))
      : ((form.endis_wsc_config.value = "1"),
        (form.endis_wsc_config_a.value = "1")),
    1 == form.enable_implicit_beamforming.checked
      ? (form.hid_wla_beamforming.value = "1")
      : (form.hid_wla_beamforming.value = "0"),
    (form.hid_wla_mu_mimo.value = form.enable_mu.checked ? "1" : "0"),
    "1" == getTop(window).use_orbi_style_flag &&
      (1 == form.enable_mu.checked
        ? (form.hid_wla_bf.value = "1")
        : 1 == form.enable_tx_beamforming.checked
        ? (form.hid_wla_bf.value = "1")
        : (form.hid_wla_bf.value = "0")),
    1 == form.enable_atf.checked
      ? (form.hid_enable_atf.value = "1")
      : (form.hid_enable_atf.value = "0"),
    1 == form.enable_ht160.checked
      ? (form.hid_wla_ht160.value = "1")
      : (form.hid_wla_ht160.value = "0"),
    1 == form.enable_11k.checked
      ? (form.hid_11k.value = "1")
      : (form.hid_11k.value = "0"),
    1 == form.disable_pmf.checked
      ? (form.hid_disable_pmf.value = "1")
      : (form.hid_disable_pmf.value = "0"),
    "0" == old_endis_wl_radio && "0" == form.wl_enable_router.value)
  )
    form.wds_change_ip.value = "still_lanip";
  else if ("0" == old_endis_wl_radio && "1" == form.wl_enable_router.value)
    if ("1" == old_wds_endis_fun && "0" == old_wds_repeater_basic) {
      if (
        1 != pr_wds_support_wpa &&
        ("3" == security_mode || "4" == security_mode || "5" == security_mode)
      )
        return (
          !!confirm("$wds_not_wpa") &&
          ((location.href = "WLG_wireless.htm"), !1)
        );
      if ("6" == security_mode)
        return (
          !!confirm("$wds_not_Enterprise") &&
          ((location.href = "WLG_wireless.htm"), !1)
        );
      (getTop(window).enable_action = 0),
        (form.wds_change_ip.value = "to_repeatip");
    } else form.wds_change_ip.value = "still_lanip";
  else
    "1" == old_endis_wl_radio && "0" == form.wl_enable_router.value
      ? "1" == old_wds_endis_fun && "0" == old_wds_repeater_basic
        ? ((getTop(window).enable_action = 0),
          (form.wds_change_ip.value = "to_lanip"))
        : (form.wds_change_ip.value = "still_lanip")
      : "1" == old_wds_endis_fun && "0" == old_wds_repeater_basic
      ? (form.wds_change_ip.value = "still_repeatip")
      : (form.wds_change_ip.value = "still_lanip");
  (form.rts.value = port_range_interception(form.rts.value)),
    (form.rts_an.value = port_range_interception(form.rts_an.value)),
    (form.frag.value = port_range_interception(form.frag.value)),
    (form.wl_rts.value = form.rts.value),
    (form.wla_rts.value = form.rts_an.value),
    (form.wl_frag.value = form.frag.value),
    1 == getTop(window).fragment_an_flag &&
      ((form.frag_an.value = port_range_interception(form.frag_an.value)),
      (form.wla_frag.value = form.frag_an.value)),
    form.wifi_onoff.checked
      ? (form.wladv_enable_schedule.value = "1")
      : (form.wladv_enable_schedule.value = "0"),
    form.wifi_onoff_an.checked
      ? (form.wladv_enable_schedule_a.value = "1")
      : (form.wladv_enable_schedule_a.value = "0"),
    form.wifi_onoff_ad.checked
      ? (form.wladv_enable_schedule_ad.value = "1")
      : (form.wladv_enable_schedule_ad.value = "0"),
    "super_wifi" == form.tx_power_ctrl_an.value &&
      (form.tx_power_ctrl_an.value = wla_tpscale),
    "super_wifi" == form.tx_power_ctrl.value &&
      (form.tx_power_ctrl.value = wl_tpscale),
    form.submit();
}
function checkap(form) {
  if (
    ((form.hid_ap_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    (form.hid_ap_subnet.value =
      form.WMask1.value +
      "." +
      form.WMask2.value +
      "." +
      form.WMask3.value +
      "." +
      form.WMask4.value),
    (form.hid_ap_gateway.value =
      form.WGateway1.value +
      "." +
      form.WGateway2.value +
      "." +
      form.WGateway3.value +
      "." +
      form.WGateway4.value),
    (form.ap_dnsaddr1.value =
      form.DAddr1.value +
      "." +
      form.DAddr2.value +
      "." +
      form.DAddr3.value +
      "." +
      form.DAddr4.value),
    (form.ap_dnsaddr2.value =
      form.PDAddr1.value +
      "." +
      form.PDAddr2.value +
      "." +
      form.PDAddr3.value +
      "." +
      form.PDAddr4.value),
    "2" == wps_progress_status ||
      "3" == wps_progress_status ||
      "start" == wps_progress_status)
  )
    return alert("$wps_in_progress"), !1;
  if (1 == form.enable_apmode.checked)
    if (
      ((form.hid_enable_apmode.value = "1"),
      1 == form.enable_fixed_ip_setting[1].checked)
    ) {
      if (0 == check_static_ip_mask_gtw()) return !1;
      if (0 == check_static_dns(!form.enable_fixed_ip_setting.checked))
        return !1;
      form.hid_dyn_get_ip.value = "0";
    } else form.hid_dyn_get_ip.value = "1";
  else (form.hid_enable_apmode.value = "0"), (form.hid_dyn_get_ip.value = "1");
  form.submit();
}
