function change_answer1(obj) {
  "1" == security_enhance_flag &&
    0 != answer1_empty &&
    0 == focus_trigger_flag1 &&
    ((focus_trigger_flag1 = 1),
    "Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : ((obj.outerHTML =
          '<input type="text" autocomplete="off" maxLength="64" size="30" name="answer1" id="answer1"  onFocus="this.select();change_answer1();" >'),
        document.forms[0].answer1.select()));
}
function change_answer2(obj) {
  "1" == security_enhance_flag &&
    0 != answer2_empty &&
    0 == focus_trigger_flag2 &&
    ((focus_trigger_flag2 = 1),
    "Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : ((obj.outerHTML =
          '<input type="text" autocomplete="off" maxLength="64" size="30" name="answer2" id="answer2"  onFocus="this.select();change_answer2();" >'),
        document.forms[0].answer2.select()));
}
function validatepassword() {
  var disabled = "image/checkbox-selected-gry.svg",
    enabled = "image/checkbox-selected.svg",
    meet_complex = 0,
    meet_len = 0,
    no_same = 0,
    cf = document.forms[0],
    passwd = cf.sysNewPasswd.value;
  "" == passwd &&
    ((cf.apply.disabled = !0),
    1 == getTop(window).r9000_router_flag
      ? (document.getElementById("apply").className = "apply1_bt")
      : (document.getElementById("apply").className = "apply_gray_bt"));
  var re = new RegExp("[a-z]"),
    len = re.test(passwd);
  len
    ? ((cf.pwd_complex2.src = enabled), meet_complex++)
    : (cf.pwd_complex2.src = disabled),
    (len = (re = new RegExp("[A-Z]")).test(passwd))
      ? ((cf.pwd_complex1.src = enabled), meet_complex++)
      : (cf.pwd_complex1.src = disabled),
    (len = (re = new RegExp("[0-9]")).test(passwd))
      ? ((cf.pwd_complex3.src = enabled), meet_complex++)
      : (cf.pwd_complex3.src = disabled),
    (len = (re = new RegExp("((?=[!-~]+)[^A-Za-z0-9])")).test(passwd))
      ? ((cf.pwd_complex4.src = enabled), meet_complex++)
      : (cf.pwd_complex4.src = disabled),
    (cf.pwd_complex.src = meet_complex > 2 ? enabled : disabled),
    passwd.length >= 8 && passwd.length <= 32
      ? ((cf.pwd_len.src = enabled), (meet_len = 1))
      : (cf.pwd_len.src = disabled),
    (len = (re = new RegExp("^.*(.)\\1{2}.*$")).test(passwd))
      ? (cf.pwd_identical.src = disabled)
      : ((cf.pwd_identical.src = enabled), (no_same = 1)),
    meet_complex > 2 && meet_len && no_same
      ? ((document.getElementById("passwd_hint").style.display = "none"),
        (cf.pwd_warn.src = "image/check.png"))
      : ((document.getElementById("passwd_hint").style.display = ""),
        (cf.pwd_warn.src = "image/warning_flag.jpg"));
}
function change_display() {
  "1" == security_enhance_flag &&
    ((document.forms[0].apply.disabled = ""),
    (document.getElementById("apply").className = "apply_bt"),
    (document.forms[0].pwd_warn.style.display = ""),
    (document.getElementById("passwd_hint").style.display = "none"));
}
function checkpasswd(cf) {
  for (i = 0; i < cf.sysNewPasswd.value.length; i++)
    if (0 == isValidChar_space(cf.sysNewPasswd.value.charCodeAt(i)))
      return alert("$password_error"), !1;
  if ("1" == security_enhance_flag && cf.sysNewPasswd.value.length < 8)
    return alert("$password_length_error"), !1;
  if (
    cf.sysNewPasswd.value.length >= 33 ||
    cf.sysConfirmPasswd.value.length >= 33
  )
    return alert("$max_password_length"), !1;
  if ("1" == security_enhance_flag && "password" == cf.sysNewPasswd.value)
    return alert("$must_change_passwd"), !1;
  if (cf.sysNewPasswd.value != cf.sysConfirmPasswd.value)
    return alert("$newpas_notmatch"), !1;
  if ("1" == security_enhance_flag && "" == cf.sysNewPasswd.value)
    return (
      alert("$must_enter_passwd"),
      (cf.apply.disabled = !0),
      (document.getElementById("apply").className = "apply_gray_bt"),
      !1
    );
  if ("" != cf.sysOldPasswd.value && "" == cf.sysNewPasswd.value)
    return alert("$password_null"), !1;

  if (!verifyPassword(cf.sysNewPasswd.value)) {
    alert("$password_error");
    return false;
  }

  if (1 == cf.enable_recovery.checked) {
    if (
      ((cf.hidden_enable_recovery.value = "1"),
      "0" == cf.question1.value || "0" == cf.question2.value)
    )
      return alert("$select_quest"), !1;
    if ("" == cf.answer1.value || "" == cf.answer2.value)
      return alert("$enter_answer"), !1;
    if (cf.answer1.value.length > 64 || cf.answer2.value.length > 64)
      return alert("$invalid_answer"), !1;
    for (i = 0; i < cf.answer1.value.length; i++)
      if (0 == isValidChar_space(cf.answer1.value.charCodeAt(i)))
        return alert("$invalid_answer"), !1;
    for (i = 0; i < cf.answer2.value.length; i++)
      if (0 == isValidChar_space(cf.answer2.value.charCodeAt(i)))
        return alert("$invalid_answer"), !1;
  } else {
    if (
      "" != cf.sysOldPasswd.value &&
      0 ==
        confirm("$pwd_recovery_to_default \n$are_you_sure_not_enable_recovery")
    )
      return !1;
    cf.hidden_enable_recovery.value = "0";
  }
  return (
    (cf.sysOldPasswd.value = $$.base64.encode(cf.sysOldPasswd.value)),
    (cf.sysNewPasswd.value = $$.base64.encode(cf.sysNewPasswd.value)),
    "1" == security_enhance_flag &&
      ((cf.hid_answer1_change.value = focus_trigger_flag1),
      (cf.hid_answer2_change.value = focus_trigger_flag2)),
    (cf.hid_answer1.value = $$.base64.encode(cf.answer1.value)),
    (cf.hid_answer2.value = $$.base64.encode(cf.answer2.value)),
    (cf.answer1.value = "******"),
    (cf.answer2.value = "******"),
    (cf.sysConfirmPasswd.value = cf.sysNewPasswd.value),
    cf.submit(),
    !0
  );
}
