function clickUpgrade(form) {
  if ("" == form.mtenFWUpload.value) return alert("$in_upgrade"), !1;
  var filestr = form.mtenFWUpload.value;
  if ("IMG" != filestr.substr(filestr.lastIndexOf(".") + 1).toUpperCase())
    return alert("$not_correct_file" + "img"), !1;
  if (0 == check_size(100, "M", "router_upload"))
    return alert("$incorrect_firmware"), !1;
  var page_title_div = document.getElementById("page_title_div"),
    FW_checking_div = document.getElementById("FW_checking_div"),
    FW_upg_div = document.getElementById("FW_upg_div"),
    pls_wait_div = document.getElementById("pls_wait_div"),
    condition_div = document.getElementById("condition_div");
  return (
    (page_title_div.style.display = "none"),
    (FW_checking_div.style.display = "none"),
    (FW_upg_div.style.display = "none"),
    (condition_div.style.display = "none"),
    (pls_wait_div.style.display = "block"),
    "1" == getTop(window).game_router_flag &&
      (document.getElementById("main").style = "height:100%"),
    (function(){
      $$.post("/cleanup.cgi", {anticsrf: cleanupCsrfToken})
        .complete(function() {
          form.submit();
        });
    })(),
    !0
  );
}
function check_if_show() {
  var cf = document.forms[0];
  if (1 == cf.enable.checked) cf.auto_check_for_upgrade.value = 1;
  else {
    if (!confirm("$upgrade_turnoff_auto")) return !1;
    cf.auto_check_for_upgrade.value = 0;
  }
  cf.submit();
}
function check_if_show_auto() {
  var cf = document.forms[0];
  if (1 == cf.enable.checked) cf.auto_check_for_upgrade.value = 1;
  else {
    if (!confirm("$upgrade_turnoff_auto")) return (cf.enable.checked = !0), !1;
    cf.auto_check_for_upgrade.value = 0;
  }
  cf.submit();
}
function click_check() {
  var cf = document.forms[0];
  cf.submit_flag.value = "download_confile";
  cf.anticsrf.value = download_confile_token;
  cf.action = "/func.cgi?/AUTO_search.htm timestamp=" + ts;
  cf.submit();
}
function clickUpgradeLanguage(form) {
  if ("" == form.filename.value) return alert("$in_upgrade"), !1;
  var filestr = form.filename.value;
  if ("TABLE" != filestr.substr(filestr.lastIndexOf("-") + 1).toUpperCase())
    return (
      alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1
    );
  var win_file_name = filestr.substr(filestr.lastIndexOf("\\") + 1),
    unix_file_name = filestr.substr(filestr.lastIndexOf("/") + 1);
  if (win_file_name == filestr && unix_file_name != filestr)
    file_name = unix_file_name;
  else if (win_file_name != filestr && unix_file_name == filestr)
    file_name = win_file_name;
  else {
    if (win_file_name != filestr || unix_file_name != filestr)
      return (
        alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1
      );
    file_name = unix_file_name;
  }
  var file_array = file_name.split("-");
  return 4 != file_array.length
    ? (alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1)
    : file_array[0].toUpperCase() != netgear_module.toUpperCase()
    ? (alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1)
    : "LANGUAGE" != file_array[2].toUpperCase()
    ? (alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1)
    : 0 != check_size(100, "M", "lg_upg") ||
      (alert("$not_correct_file" + netgear_module + "-*-Language-table"), !1);
}
function view_details(target) {
  if ("collect" == target)
    var url = "collection_details.html?definedLanguage=1";
  else if ("tnc" == target) url = "simple_tnc_details.html?definedLanguage=1";
  window
    .open(
      url,
      "collect_details",
      "resizable=1,scrollvars=yes,width=800,height=600,left=400,top=100"
    )
    .focus();
}
function conditions_apply(cf2) {
  1 == cf2.agree_upg[0].checked && (cf2.hid_agree_upg.value = "1"),
    1 == cf2.agree_col[0].checked && (cf2.hid_agree_col.value = "1"),
    cf2.submit();
}
