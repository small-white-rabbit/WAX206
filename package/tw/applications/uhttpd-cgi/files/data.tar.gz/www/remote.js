function clearData1() {
  var cf = document.forms[0];
  (cf.local_ip_1.disabled = !0),
    (cf.local_ip_2.disabled = !0),
    (cf.local_ip_3.disabled = !0),
    (cf.local_ip_4.disabled = !0),
    (cf.start_ip_1.disabled = !0),
    (cf.start_ip_2.disabled = !0),
    (cf.start_ip_3.disabled = !0),
    (cf.start_ip_4.disabled = !0),
    (cf.fin_ip_1.disabled = !0),
    (cf.fin_ip_2.disabled = !0),
    (cf.fin_ip_3.disabled = !0),
    (cf.fin_ip_4.disabled = !0);
}
function check_remote() {
  var cf = document.forms[0];
  if (
    (1 == cf.remote_mg_enable.checked
      ? (cf.http_rmenable.value = 1)
      : (cf.http_rmenable.value = 0),
    (cf.local_ip.value =
      cf.local_ip_1.value +
      "." +
      cf.local_ip_2.value +
      "." +
      cf.local_ip_3.value +
      "." +
      cf.local_ip_4.value),
    (warningMessage = "$include_wan_ip"),
    cf.rm_access[0].checked)
  ) {
    if (0 == checkipaddr(cf.local_ip.value)) return alert("$invalid_ip"), !1;
    if (
      ((cf.local_ip.value = address_parseInt(cf.local_ip.value)),
      1 == isSameSubNet(cf.local_ip.value, lan_subnet, lan_ip, lan_subnet))
    )
      return alert("$diff_thisip_lanip"), !1;
    if (1 == isSameIp(cf.local_ip.value, remote_manage_ip))
      return alert(warningMessage), !1;
  } else if (cf.rm_access[1].checked) {
    var start_ip =
        cf.start_ip_1.value +
        "." +
        cf.start_ip_2.value +
        "." +
        cf.start_ip_3.value +
        "." +
        cf.start_ip_4.value,
      end_ip =
        cf.fin_ip_1.value +
        "." +
        cf.fin_ip_2.value +
        "." +
        cf.fin_ip_3.value +
        "." +
        cf.fin_ip_4.value;
    if (0 == checkipaddr(start_ip)) return alert("$invalid_start_ip"), !1;
    if (0 == checkipaddr(end_ip)) return alert("$invalid_end_ip"), !1;
    if (0 == cp_ip2(start_ip, end_ip))
      return alert("$invalid_remote_startendip"), !1;
    if (1 == isSameSubNet(start_ip, lan_subnet, lan_ip, lan_subnet))
      return alert("$invalid_ip"), !1;
    if (1 == isSameSubNet(end_ip, lan_subnet, lan_ip, lan_subnet))
      return alert("$invalid_ip"), !1;
    if (
      ((startipNum = ipNum(start_ip)),
      (endipNum = ipNum(end_ip)),
      (wanipNum = ipNum(remote_manage_ip)),
      (lanipNum = ipNum(lan_ip)),
      lanipNum >= startipNum && lanipNum <= endipNum)
    )
      return alert("$invalid_ip"), !1;
    if (wanipNum >= startipNum && wanipNum <= endipNum)
      return alert(warningMessage), !1;
    cf.local_ip.value =
      address_parseInt(start_ip) + "-" + address_parseInt(end_ip);
  }
  var remote_port = parseInt(cf.http_rmport.value, 10);
  if (
    isNaN(remote_port) ||
    remote_port < 1024 ||
    remote_port > 65534 ||
    -1 != cf.http_rmport.value.indexOf(".")
  )
    return alert("$invalid_port_number"), cf.http_rmport.focus(), !1;
  for (cf.http_rmport.value = remote_port, i = 1; i <= forward_array_num; i++) {
    var str = eval("forwardingArray" + i),
      each_info = str.split(" ");
    if (
      ((sertype = each_info[1]),
      (startport = each_info[2]),
      (endport = each_info[3]),
      (serflag = each_info[7]),
      "UDP" == sertype || "1" == serflag)
    );
    else if (
      remote_port >= parseInt(startport) &&
      remote_port <= parseInt(endport)
    )
      return alert("$invalid_remote_port_used"), !1;
  }
  for (i = 1; i <= trigger_array_num; i++) {
    var str = eval("triggeringArray" + i),
      each_info = str.split(" ");
    if (
      ((constart_port = each_info[6]),
      (conend_port = each_info[7]),
      (tri_type = each_info[5]),
      "UDP" == tri_type)
    );
    else if (
      remote_port >= parseInt(constart_port) &&
      remote_port <= parseInt(conend_port)
    )
      return alert("$used_by_system"), !1;
  }
  for (i = 1; i <= upnp_array_num; i++) {
    var str = eval("upnpArray" + i),
      each_info = str.split(";");
    if (
      ((upnp_int = each_info[2]),
      (upnp_type = each_info[1]),
      upnp_type,
      ("TCP" == upnp_type && remote_port == parseInt(upnp_int)))
    )
      return alert("$invalid_remote_port_used"), !1;
  }
  return 1 == usb_router_flag &&
    0 == check_readyshare_port(remote_port, remote_port, "WAN")
    ? (alert("$invalid_remote_port_used"), !1)
    : ((cf.http_rmport.value = port_range_interception(cf.http_rmport.value)),
      cf.submit(),
      !0);
}
function clearData2() {
  var cf = document.forms[0];
  (cf.start_ip_1.disabled = !0),
    (cf.start_ip_2.disabled = !0),
    (cf.start_ip_3.disabled = !0),
    (cf.start_ip_4.disabled = !0),
    (cf.fin_ip_1.disabled = !0),
    (cf.fin_ip_2.disabled = !0),
    (cf.fin_ip_3.disabled = !0),
    (cf.fin_ip_4.disabled = !0),
    (cf.local_ip_1.disabled = !1),
    (cf.local_ip_2.disabled = !1),
    (cf.local_ip_3.disabled = !1),
    (cf.local_ip_4.disabled = !1);
}
function clearData3() {
  var cf = document.forms[0];
  (cf.start_ip_1.disabled = !1),
    (cf.start_ip_2.disabled = !1),
    (cf.start_ip_3.disabled = !1),
    (cf.start_ip_4.disabled = !1),
    (cf.fin_ip_1.disabled = !1),
    (cf.fin_ip_2.disabled = !1),
    (cf.fin_ip_3.disabled = !1),
    (cf.fin_ip_4.disabled = !1),
    (cf.local_ip_1.disabled = !0),
    (cf.local_ip_2.disabled = !0),
    (cf.local_ip_3.disabled = !0),
    (cf.local_ip_4.disabled = !0);
}
