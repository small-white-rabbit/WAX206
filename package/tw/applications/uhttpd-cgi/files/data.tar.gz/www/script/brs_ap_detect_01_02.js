function initPage() {
  var btns1 = document.getElementById("back");
  (btns1.value = bh_back_mark),
    "admin" == master
      ? (btns1.onclick = function () {
          return goback();
        })
      : (btns1.className = "grey_short_btn");
  var btns2 = document.getElementById("next");
  (btns2.value = bh_next_mark),
    "admin" == master
      ? (btns2.onclick = function () {
          return help_choose_mode();
        })
      : (btns2.className = "grey_short_btn");
}
function help_choose_mode() {
  var choice_radio = document
    .getElementById("choices_div")
    .getElementsByTagName("input");
  if (choice_radio[0].checked)
    this.location.href = "BRS_ap_detect_01_ap_01.html";
  else {
    if (!choice_radio[1].checked) return alert(bh_select_yes_or_no), !1;
    this.location.href = "BRS_ap_detect_01_03.html";
  }
}
function goback() {
  this.location.href = "BRS_ap_detect_01_01.html";
}
addLoadEvent(initPage);
