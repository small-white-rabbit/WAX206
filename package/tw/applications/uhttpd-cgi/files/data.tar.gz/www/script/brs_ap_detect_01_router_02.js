function goto_next(cf, wl_login) {
  if (cf.choose[0].checked) {
    var ssid_bgn = document.getElementById("ESSID").value,
      ssid_an = document.getElementById("ESSID_an").value;
    if (!brs_check_ssid(ssid_bgn) || !brs_check_ssid(ssid_an)) return !1;
    if (0 == checkpsk(cf.passphrase_an, cf.wla_sec_wpaphrase_len)) return;
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return;
    if ("1" == ad_router_flag && !validate_ad(cf)) return;
    (cf.wl_hidden_wpa_psk.value = cf.passphrase.value),
      (cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value),
      (cf.method = "post"),
      (cf.action =
        1 == wl_login
          ? "/apply.cgi?/BRS_ap_detect_01_04.html timestamp=" + ts
          : "/apply.cgi?/BRS_01_checkNet_ping.html timestamp=" + ts),
      (cf.submit_flag.value = "wl_ssid_password"),
      cf.submit();
  } else {
    if (!cf.choose[1].checked) return alert(bh_warning_info), !1;
    this.location.href = "BRS_01_checkNet_ping.html";
  }
}
function goback() {
  var pre_url_info = document.referrer.split("/");
  if ("BRS_ap_detect_01_router_01.html" == pre_url_info[3])
    this.location.href = "BRS_ap_detect_01_router_01.html";
  else if ("BRS_00_02_ap_select.html" == pre_url_info[3])
    this.location.href = "BRS_00_02_ap_select.html";
  else {
    if (void 0 === top.brs_pre_url) return !1;
    this.location.href = top.brs_pre_url;
  }
}
