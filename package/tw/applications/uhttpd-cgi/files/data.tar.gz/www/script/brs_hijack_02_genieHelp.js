function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    connect_text = document.createTextNode(bh_config_net_connection);
  head_tag[0].appendChild(connect_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_connection_further_action);
  paragraph[0].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_want_genie_help)),
    paragraph[1].appendChild(paragraph_text);
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master
      ? (btn.onclick = function () {
          return genieHelpChecking();
        })
      : (btn.className = "grey_short_btn"),
    showFirmVersion("none");
}
function genieHelpChecking() {
  var choices = document
      .getElementById("choices_div")
      .getElementsByTagName("input"),
    cf = document.getElementsByTagName("form")[0];
  if (choices[0].checked) cf.submit();
  else if (choices[1].checked) {
    if (0 == confirm(bh_no_genie_help_confirm)) return !1;
    this.location.href = "BRS_security.html";
  } else {
    if (!choices[2].checked) return alert(bh_select_an_option), !1;
    this.location.href = "BRS_03B_haveBackupFile.html";
  }
  return !0;
}
addLoadEvent(initPage);
