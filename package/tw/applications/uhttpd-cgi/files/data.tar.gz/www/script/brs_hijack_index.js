function initIndex() {
  (document.getElementsByTagName("body").onload = loadValue()), changeUrl();
}
function loadValue() {
  var content_frame = document.getElementById("content_frame");
  1 == getTop(window).hdd_multi_user
    ? "1" == first_hdd_nofind
      ? content_frame.setAttribute("src", "BRS_01_checkNet_ping.html")
      : "1" == from_restore
      ? content_frame.setAttribute(
          "src",
          "BRS_03B_haveBackupFile_wait_ping.html"
        )
      : "1" == from_nowan
      ? content_frame.setAttribute("src", "BRS_03A_A_noWan_check_net.html")
      : "1" == from_download
      ? content_frame.setAttribute("src", "BRS_hdd_download_href.htm")
      : "1" == from_setting
      ? content_frame.setAttribute("src", "BRS_04_applySettings_ping.html")
      : "1" == apmode_flag && "1" == ap_mode && "1" == ap_mode_detection_flag
      ? content_frame.setAttribute("src", "BRS_01_checkNet_ping.html")
      : "1" == apmode_flag && "1" == ap_mode_detection_flag
      ? content_frame.setAttribute("src", "BRS_00_01_check_ap.html")
      : content_frame.setAttribute("src", "BRS_01_checkNet_ping.html")
    : "1" == from_restore
    ? content_frame.setAttribute("src", "BRS_03B_haveBackupFile_wait_ping.html")
    : "1" == from_nowan
    ? content_frame.setAttribute("src", "BRS_03A_A_noWan_check_net.html")
    : "1" == form_set2
    ? content_frame.setAttribute(
        "src",
        "BRS_04_applySettings_ppp_second_obtain_ip.html"
      )
    : "1" == from_setting
    ? "1" == dsl_enable_flag
      ? "1" == apmode_flag && "1" == ap_mode
        ? content_frame.setAttribute("src", "BRS_04_applySettings_ping.html")
        : content_frame.setAttribute(
            "src",
            "BRS_04_applySettings_ppp_obtain_ip.html"
          )
      : content_frame.setAttribute("src", "BRS_04_applySettings_ping.html")
    : "1" == apmode_flag && "1" == ap_mode && "1" == ap_mode_detection_flag
    ? content_frame.setAttribute("src", "BRS_01_checkNet_ping.html")
    : "1" == dsl_enable_flag
    ? content_frame.setAttribute("src", "BRS_01_ture_check_cable.html")
    : "1" == apmode_flag && "1" == ap_mode_detection_flag
    ? content_frame.setAttribute("src", "BRS_00_01_check_ap.html")
    : content_frame.setAttribute("src", "BRS_01_checkNet_ping.html"),
    "1" == support_wan_preference &&
      "1" != set_wan_preference &&
      content_frame.setAttribute("src", "BRS_wan_preference.html"),
    1 == tnc_request_flag &&
      "1" == new_sold_board &&
      "1" != agree_full_TC &&
      content_frame.setAttribute("src", "BRS_full_conditions.html"),
    showFirmVersion("none");
}
function changeUrl() {
  "1" == apmode_flag && "1" == ap_mode
    ? "1" == dns_hijack &&
      this.location.hostname != apmode_get_ip &&
      -1 == this.location.hostname.indexOf("routerlogin.net") &&
      -1 == this.location.hostname.indexOf("routerlogin.com") &&
      (this.location.hostname = apmode_get_ip)
    : "1" == dns_hijack &&
      this.location.hostname != lanip &&
      -1 == this.location.hostname.indexOf("routerlogin.net") &&
      -1 == this.location.hostname.indexOf("routerlogin.com") &&
      (this.location.hostname = "www.routerlogin.net");
}
addLoadEvent(initIndex);
