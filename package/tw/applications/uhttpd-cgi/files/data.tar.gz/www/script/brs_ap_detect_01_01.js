function initPage() {
  var btns1 = document.getElementById("back");
  (btns1.value = bh_back_mark),
    "admin" == master
      ? (btns1.onclick = function () {
          return goto_url(0);
        })
      : (btns1.className = "grey_short_btn");
  var btns2 = document.getElementById("next");
  (btns2.value = bh_next_mark),
    "admin" == master
      ? (btns2.onclick = function () {
          return goto_url(1);
        })
      : (btns2.className = "grey_short_btn");
}
function goto_url(tag) {
  return 0 == tag
    ? ((this.location.href = "BRS_00_02_ap_select.html"), !0)
    : 1 == tag
    ? ((this.location.href = "BRS_ap_detect_01_02.html"), !0)
    : void 0;
}
addLoadEvent(initPage);
