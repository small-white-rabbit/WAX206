function initPage() {
  var head_tag = document.getElementsByTagName("h2"),
    head_text = document.createTextNode(bh_pptp_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_enter_info_below);
  paragraph[0].appendChild(paragraph_text);
  var login_name = document.getElementById("loginName"),
    login_text = document.createTextNode(bh_pptp_login_name);
  login_name.appendChild(login_text);
  var passwd = document.getElementById("passwd"),
    passwd_text = document.createTextNode(bh_ddns_passwd);
  passwd.appendChild(passwd_text);
  var idleTimeout = document.getElementById("idleTimeout"),
    idleTimeout_text = document.createTextNode(bh_basic_pppoe_idle);
  idleTimeout.appendChild(idleTimeout_text);
  var IP_addr_div = document.getElementById("IP_addr"),
    IP_addr_text = document.createTextNode(bh_info_mark_ip);
  IP_addr_div.appendChild(IP_addr_text);
  var serverIP_div = document.getElementById("serverIP"),
    serverIP_text = document.createTextNode(bh_basic_pptp_servip);
  serverIP_div.appendChild(serverIP_text);
  var Gateway_div = document.getElementById("GatewayAddr"),
    Gateway_text = document.createTextNode(bh_sta_routes_gtwip);
  Gateway_div.appendChild(Gateway_text);
  var connectionID_div = document.getElementById("connectionID"),
    connectionID_text = document.createTextNode(bh_basic_pptp_connection_id);
  connectionID_div.appendChild(connectionID_text),
    (document.getElementById("pptp_username").onkeypress = ssidKeyCode),
    (document.getElementById("pptp_passwd").onkeypress = ssidKeyCode),
    (document.getElementById("pptp_idletime").onkeypress = numKeyCode);
  var severIP_input = document.getElementById("pptp_serv_ip");
  (severIP_input.value = "10.0.0.138"), (severIP_input.disabled = !0);
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master
      ? (btn.onclick = function () {
          return checkPPTP();
        })
      : (btn.className = "grey_short_btn"),
    showFirmVersion("none");
}
function checkPPTP() {
  var i,
    cf = document.getElementsByTagName("form")[0],
    pptp_username = document.getElementById("pptp_username"),
    pptp_passwd = document.getElementById("pptp_passwd"),
    pptp_idletime = document.getElementById("pptp_idletime");
  if ("" == pptp_username.value) return alert(bh_login_name_null), !1;
  for (i = 0; i < pptp_passwd.value.length; i++)
    if (0 == isValidChar(pptp_passwd.value.charCodeAt(i)))
      return alert(bh_password_error), !1;
  return pptp_idletime.value.length <= 0
    ? (alert(bh_idle_time_null), !1)
    : _isNumeric(pptp_idletime.value)
    ? !!checkIPaddr() && (cf.submit(), !0)
    : (alert(bh_invalid_idle_time), !1);
}
function checkIPaddr() {
  var cf = document.getElementsByTagName("form")[0];
  if (
    ((cf.ip_address.value =
      cf.myip_1.value +
      "." +
      cf.myip_2.value +
      "." +
      cf.myip_3.value +
      "." +
      cf.myip_4.value),
    (cf.gateway.value =
      cf.mygw_1.value +
      "." +
      cf.mygw_2.value +
      "." +
      cf.mygw_3.value +
      "." +
      cf.mygw_4.value),
    "..." != cf.ip_address.value)
  ) {
    cf.WANAssign.value = 1;
    var pptp_mask = "255.255.255.0";
    if (
      ((pptp_mask =
        parseInt(cf.myip_1.value) < 128
          ? "255.0.0.0"
          : parseInt(cf.myip_1.value) < 192
          ? "255.255.0.0"
          : "255.255.255.0"),
      (cf.pptp_subnet.value = pptp_mask),
      0 == checkipaddr(cf.ip_address.value))
    )
      return alert(bh_invalid_myip), !1;
    if (1 == isSameIp(cf.ip_address.value, cf.pptp_serv_ip.value))
      return alert(bh_same_server_wan_ip), !1;
    if ("..." != cf.gateway.value && 0 == checkgateway(cf.gateway.value))
      return alert(bh_invalid_gateway), !1;
    if ("..." != cf.gateway.value) {
      if (1 == isSameIp(cf.ip_address.value, cf.gateway.value))
        return alert(bh_invalid_gateway), !1;
      if (
        0 ==
        isGateway(cf.ip_address.value, cf.pptp_subnet.value, cf.gateway.value)
      )
        return alert(bh_invalid_gateway), !1;
    }
  } else cf.WANAssign.value = 0;
  return !0;
}
addLoadEvent(initPage);
