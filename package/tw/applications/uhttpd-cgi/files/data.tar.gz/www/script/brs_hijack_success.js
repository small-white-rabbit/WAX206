function initPage() {
  ("1" != getTop(window).have_broadband &&
    "1" != getTop(window).have_lte_flag) ||
  "multi" != getTop(window).multi_wan_mode ||
  "0" != getTop(window).multi_wan_mode_ether
    ? "0" == an_router_flag
      ? 1 == wl_sectype
        ? noPreSecurityInit()
        : preSecurityInit()
      : 1 == wl_sectype && 1 == wla_sectype
      ? noPreSecurityInit()
      : preSecurityInit()
    : loadValue();
}
function loadValue() {
  "multi" == getTop(window).multi_wan_mode &&
    "0" == getTop(window).multi_wan_mode_ether &&
    ((getTop(window).multi_wan_mode_ether = "1"),
    (this.location.href = "WIZ_failover_01.htm"));
}
function preSecurityInit() {
  var head_tag = document.getElementsByTagName("h2"),
    head_text = document.createTextNode(bh_congratulations);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_connect_success_1);
  if (
    (paragraph[0].appendChild(paragraph_text),
    1 == wl_tooltip1 || 1 == wla_tooltip1)
  ) {
    var tooltip = document.getElementById("key_tooltip_1");
    addTooltip(tooltip);
  }
  var networkName_text,
    networkName_div = document.getElementById("network_name");
  "0" == an_router_flag
    ? (networkName_text = document.createTextNode(bh_wirless_name))
    : "1" == an_router_flag &&
      (networkName_text = document.createTextNode(bh_wl_ssid_name)),
    networkName_div.appendChild(networkName_text),
    (networkName_div = document.getElementById("network_name_5G")),
    (networkName_text = document.createTextNode(bh_wla_ssid_name)),
    networkName_div.appendChild(networkName_text);
  var div_5G = document.getElementById("div_5G"),
    passwd_5G = document.getElementById("passwd_5G");
  "0" == an_router_flag
    ? ((div_5G.style.display = "none"), (passwd_5G.style.display = "none"))
    : "1" == an_router_flag &&
      ((div_5G.style.display = ""),
      wl_sectype == wla_sectype && wl_passphrase == wla_passphrase
        ? (passwd_5G.style.display = "none")
        : (passwd_5G.style.display = "")),
    (1 != wl_tooltip1 && 1 != wla_tooltip1) ||
      addTooltip((tooltip = document.getElementById("key_tooltip_2"))),
    1 == wla_tooltip1 &&
      addTooltip((tooltip = document.getElementById("key_tooltip_3"))),
    initBtnsAction();
}
function noPreSecurityInit() {
  var head_tag = document.getElementsByTagName("h2"),
    head_text = document.createTextNode(bh_congratulations);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_connect_success_1);
  (paragraph[0].appendChild(paragraph_text), "0" == an_router_flag)
    ? (document.getElementById("info_div_24").style.display = "none")
    : (document.getElementById("info_div").style.display = "none");
  initBtnsAction();
}
function initBtnsAction() {
  var btns_div1 = document.getElementById("btnsContainer_div1");
  if (btns_div1)
    if (0 == getTop(window).is_ru_version) btns_div1.style.display = "none";
    else {
      "admin" == master &&
        (btns_div1.onclick = function () {
          return saveSettings();
        });
      var btn = btns_div1.getElementsByTagName("div"),
        btn_text = document.createTextNode(bh_save_settings);
      btn[0].appendChild(btn_text);
    }
  var btns_div2 = document.getElementById("btnsContainer_div2");
  btns_div2 &&
    ("admin" == master &&
      (btns_div2.onclick = function () {
        return printSucessPage();
      }),
    (btn = btns_div2.getElementsByTagName("div")),
    (btn_text = document.createTextNode(bh_print_this)),
    btn[0].appendChild(btn_text));
  var btns_div3 = document.getElementById("btnsContainer_div3"),
    btns_div4 = document.getElementById("btnsContainer_div4");
  btns_div3 &&
    btns_div4 &&
    0 == cd_less_download &&
    (btns_div3
      ? ("admin" == master &&
          (btns_div3.onclick = function () {
            return toInternet();
          }),
        (btn = btns_div3.getElementsByTagName("div")),
        (btn_text = document.createTextNode(bh_take_to_internet)),
        btn[0].appendChild(btn_text),
        (btns_div4.style.display = "none"))
      : ((btns_div3.style.display = "none"),
        "admin" == master &&
          (btns_div4.onclick = function () {
            return toDownloadApps();
          }),
        (btn = btns_div4.getElementsByTagName("div")),
        (btn_text = document.createTextNode(bh_next_mark)),
        btn[0].appendChild(btn_text))),
    showFirmVersion("none");
}
function toDownloadApps() {
  this.location.href = "BRS_download_apps.html";
}
function addTooltip(tooltip_name) {
  tooltip_name.setAttribute("title", bh_rollover_help_text),
    (tooltip_name.className = "tooltip");
}
function printSucessPage() {
  return window.print
    ? (window.print(), !0)
    : (alert(bh_not_support_print), !1);
}
function saveSettings() {
  var cf = document.getElementsByTagName("form")[0];
  return (
    (cf.action = "/brs_backup.cgi"),
    (cf.submit_flag.value = ""),
    cf.submit(),
    !0
  );
}
function toInternet() {
  document.getElementsByTagName("form")[0];
  return (
    window.open(
      "to_internet_no_auth.htm",
      "brs_ng",
      "width=960,height=800,menubar=yes,scrollbars=yes,toolbar=yes,status=yes,location=yes,resizable=yes"
    ),
    !0
  );
}
function click_here() {
  var cf = document.getElementsByTagName("form")[0];
  (cf.click_flag.value = "1"),
    (cf.action = "apply.cgi?/BRS_success.html timestamp=" + ts),
    cf.encoding
      ? (cf.encoding = "application/x-www-form-urlencoded")
      : cf.enctype && (cf.enctype = "application/x-www-form-urlencoded"),
    (cf.submit_flag.value = "hijack_success"),
    cf.submit();
  window.open(
    "change_to_wireless.htm",
    "chge_towl",
    "width=960,height=800,menubar=yes,scrollbars=yes,toolbar=yes,status=yes,location=yes,resizable=yes"
  );
}
function XXXtoInternet() {
  window.open(
    "BRS_netgear_success.html",
    null,
    "width=960,height=800,menubar=yes,scrollbars=yes,toolbar=yes,status=yes,location=yes,resizable=yes"
  );
}
addLoadEvent(initPage);
