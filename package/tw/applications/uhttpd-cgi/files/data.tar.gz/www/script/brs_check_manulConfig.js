function loadValue() {
  document.getElementsByTagName("form")[0].submit();
}
addLoadEvent(loadValue);
