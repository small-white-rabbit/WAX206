function initPage() {
  document.getElementsByTagName("h1");
  var btns_container_div = document.getElementById("btnsContainer_div2");
  "admin" == master &&
    (btns_container_div.onclick = function () {
      return checkap(document.forms[0]);
    }),
    ((btns_container_div = document.getElementById(
      "btnsContainer_div1"
    )).onclick = function () {
      return go_back();
    }),
    loadvalue(),
    showFirmVersion("none");
}
function loadvalue() {}
function goto_route() {
  getTop(window).location.href = "https://www.routerlogin.net";
}
function go_back() {
  var pre_url = document.referrer;
  return (
    -1 != pre_url.indexOf("BRS_ap_detect_01_ap_02.html?id=0")
      ? (this.location.href = "BRS_ap_detect_01_ap_02.html?id=0")
      : -1 != pre_url.indexOf("BRS_ap_detect_01_ap_02.html?id=1")
      ? (this.location.href = "BRS_ap_detect_01_ap_02.html?id=1")
      : (this.location.href = "BRS_ap_detect_01_ap_02.html"),
    !0
  );
}
function checkap(form) {
  if (
    "2" == wps_progress_status ||
    "3" == wps_progress_status ||
    "start" == wps_progress_status
  )
    return alert(bh_wps_in_progress), !1;
  (form.hid_enable_apmode.value = "1"),
    (form.hid_dyn_get_ip.value = "1"),
    form.submit();
}
addLoadEvent(initPage);
