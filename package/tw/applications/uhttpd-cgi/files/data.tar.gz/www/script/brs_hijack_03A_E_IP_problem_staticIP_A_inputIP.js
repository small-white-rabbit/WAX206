function initPage() {
  var head_tag = document.getElementsByTagName("h2"),
    head_text = document.createTextNode(bh_fix_ip_setting);
  head_tag[0].appendChild(head_text);
  document.getElementsByTagName("p");
  var IP_addr_div = document.getElementById("IP_addr"),
    IP_addr_text = document.createTextNode(bh_info_mark_ip);
  IP_addr_div.appendChild(IP_addr_text);
  var Sub_mask_div = document.getElementById("Sub_mask"),
    Sub_mask_text = document.createTextNode(bh_info_mark_mask);
  Sub_mask_div.appendChild(Sub_mask_text);
  var Gateway_div = document.getElementById("GatewayAddr"),
    Gateway_text = document.createTextNode(bh_constatus_defgtw);
  Gateway_div.appendChild(Gateway_text);
  var preDNS_div = document.getElementById("preDNS"),
    preDNS_text = document.createTextNode(bh_preferred_dns);
  preDNS_div.appendChild(preDNS_text);
  var alteDNS_div = document.getElementById("alteDNS"),
    alteDNS_text = document.createTextNode(bh_alternate_dns);
  alteDNS_div.appendChild(alteDNS_text);
  var thirdDNS_div = document.getElementById("thirdDNS"),
    thirdDNS_input = document.getElementById("third_dns_input");
  if (1 == dns_third_flag) {
    var thirdDNS_text = document.createTextNode(bh_basic_int_third_dns);
    thirdDNS_div.appendChild(thirdDNS_text);
  } else
    (thirdDNS_div.style.display = "none"),
      (thirdDNS_input.style.display = "none");
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master
      ? (btn.onclick = function () {
          return checkStaticIP();
        })
      : (btn.className = "grey_short_btn"),
    showFirmVersion("none");
}
function checkStaticIP() {
  var cf = document.getElementsByTagName("form")[0];
  return (
    (cf.ip_address.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.subnet_mask.value =
      cf.WMask1.value +
      "." +
      cf.Wmask2.value +
      "." +
      cf.Wmask3.value +
      "." +
      cf.Wmask4.value),
    (cf.gateway.value =
      cf.WGateway1.value +
      "." +
      cf.Wgateway2.value +
      "." +
      cf.Wgateway3.value +
      "." +
      cf.Wgateway4.value),
    0 != check_static_ip_mask_gtw() &&
      0 != check_static_dns(!0) &&
      0 != check_ether_samesubnet() &&
      (cf.submit(), !0)
  );
}
function check_static_ip_mask_gtw() {
  var cf = document.getElementsByTagName("form")[0];
  return 0 == checkipaddr(cf.ip_address.value) ||
    0 ==
      is_sub_or_broad(
        cf.ip_address.value,
        cf.ip_address.value,
        cf.subnet_mask.value
      )
    ? (alert(bh_invalid_ip), !1)
    : 0 == checksubnet(cf.subnet_mask.value)
    ? (alert(bh_invalid_mask), !1)
    : 0 == checkgateway(cf.gateway.value)
    ? (alert(bh_invalid_gateway), !1)
    : 1 != isSameIp(cf.ip_address.value, cf.gateway.value) ||
      (alert(bh_invalid_gateway), !1);
}
function check_ether_samesubnet() {
  var cf = document.getElementsByTagName("form")[0];
  return 1 ==
    isSameSubNet(cf.ip_address.value, cf.subnet_mask.value, lan_ip, lan_subnet)
    ? (alert(bh_same_lan_wan_subnet), !1)
    : 1 == isSameSubNet(cf.ip_address.value, lan_subnet, lan_ip, lan_subnet)
    ? (alert(bh_same_lan_wan_subnet), !1)
    : 1 ==
      isSameSubNet(
        cf.ip_address.value,
        cf.subnet_mask.value,
        lan_ip,
        cf.subnet_mask.value
      )
    ? (alert(bh_same_lan_wan_subnet), !1)
    : 1 != isSameIp(cf.ip_address.value, lan_ip) ||
      (alert(bh_same_lan_wan_subnet), !1);
}
function check_static_dns(wan_assign) {
  var cf = document.getElementsByTagName("form")[0];
  return (
    (cf.preferred_dns.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.alternate_dns.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    1 == dns_third_flag &&
      (cf.third_dns.value =
        cf.TDAddr1.value +
        "." +
        cf.TDAddr2.value +
        "." +
        cf.TDAddr3.value +
        "." +
        cf.TDAddr4.value),
    1 == dns_third_flag
      ? check_three_DNS(
          cf.preferred_dns.value,
          cf.alternate_dns.value,
          cf.third_dns.value,
          wan_assign,
          cf.ip_address.value
        )
      : check_DNS(
          cf.preferred_dns.value,
          cf.alternate_dns.value,
          wan_assign,
          cf.ip_address.value
        )
  );
}
addLoadEvent(initPage);
