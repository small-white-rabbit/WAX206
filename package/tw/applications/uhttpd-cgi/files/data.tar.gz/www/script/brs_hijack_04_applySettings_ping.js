function initPage() {
  showFirmVersion("none"), loadValue();
}
function loadValue() {
  if (0 == getTop(window).dsl_enable_flag)
    "1" == apmode_flag &&
      "1" == ap_mode &&
      "1" == ap_mode_detection_flag &&
      ("success" == ping_result
        ? (this.location.href = "BRS_security.html")
        : "failed" == ping_result &&
          (this.location.href = "BRS_05_networkIssue.html")),
      "3g" == wan_proto
        ? "success" == ping_result
          ? (this.location.href = "BRS_security.html")
          : "failed" == ping_result &&
            (this.location.href = "BRS_05_networkIssue.html")
        : "0" == select_basic && "0" == select_type
        ? "failed" == ping_result
          ? (this.location.href = "BRS_03A_B_pppoe_reenter.html")
          : "success" == ping_result &&
            (this.location.href = "BRS_04_applySettings_wget.html")
        : "0" == select_basic && "1" == select_type
        ? "failed" == ping_result
          ? (this.location.href = "BRS_03A_C_pptp_reenter.html")
          : "success" == ping_result &&
            (this.location.href = "BRS_04_applySettings_wget.html")
        : "0" == select_basic && "4" == select_type
        ? "failed" == ping_result
          ? (this.location.href = "BRS_03A_F_l2tp_reenter.html")
          : "success" == ping_result &&
            (this.location.href = "BRS_04_applySettings_wget.html")
        : 1 == getTop(window).support_orange_flag ||
          1 == getTop(window).support_singapore_isp_flag ||
          1 == getTop(window).support_malaysia_isp_flag ||
          1 == getTop(window).support_spain_isp_flag ||
          1 == getTop(window).support_malaysia_pppoe_isp_flag
        ? "0" != select_basic ||
          ("6" != select_type &&
            "7" != select_type &&
            "8" != select_type &&
            "9" != select_type &&
            "10" != select_type &&
            "11" != select_type &&
            "12" != select_type &&
            "13" != select_type &&
            "14" != select_type &&
            "15" != select_type) ||
          ("success" == ping_result
            ? (this.location.href = "BRS_success.html")
            : "failed" == ping_result &&
              (this.location.href = "BRS_05_networkIssue.html"))
        : "success" == ping_result
        ? (this.location.href = "BRS_security.html")
        : "failed" == ping_result &&
          (this.location.href = "BRS_05_networkIssue.html");
  else if (1 == getTop(window).dsl_enable_flag) {
    if ("1" == debug) return;
    (("Italy" == curr_country && "Fastweb" == curr_isp) ||
      ("Switzerland" == curr_country && "Swisscom" == curr_isp) ||
      ("Switzerland" == curr_country &&
        "Swisscom All IP(with phone)" == curr_isp)) &&
    "vdsl" == wan_type
      ? (this.location.href = "BRS_01_obtain_ip_lift_hijack.html")
      : "success" == ping_result
      ? "success" == ping_ip_result && "success" == ping_gate_result
        ? (this.location.href = "BRS_log11_ping_success.html")
        : "success" == ping_ip_result && "fail" == ping_gate_result
        ? (this.location.href =
            "BRS_log11_ping_successi_ip_success_gate_fail.html")
        : "fail" == ping_ip_result && "success" == ping_gate_result
        ? (this.location.href =
            "BRS_log11_ping_success_ip_fail_gate_success.html")
        : (this.location.href = "BRS_log11_ping_success_ip_fail.html")
      : "success" == ping_ip_result && "success" == ping_gate_result
      ? (this.location.href = "BRS_log11_ping_fail.html")
      : "success" == ping_ip_result && "fail" == ping_gate_result
      ? (this.location.href = "BRS_log11_ping_fail_ip_sucess_gate_fail.html")
      : "fail" == ping_ip_result && "success" == ping_gate_result
      ? (this.location.href = "BRS_log11_ping_faili_ip_fail_gate_success.html")
      : (this.location.href = "BRS_log11_ping_fail_ip_fail.html");
  }
}
addLoadEvent(initPage);
