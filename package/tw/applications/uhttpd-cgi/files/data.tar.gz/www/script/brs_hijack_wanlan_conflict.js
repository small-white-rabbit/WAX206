function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_important);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_wanlan_conflict_info);
  paragraph[0].appendChild(paragraph_text);
  var bold_ipaddr = document.createElement("b"),
    ipaddr = document.createTextNode(ip_addr);
  bold_ipaddr.appendChild(ipaddr), paragraph[0].appendChild(bold_ipaddr);
  var btns_container_div = document.getElementById("btnsContainer_div");
  "admin" == master &&
    (btns_container_div.onclick = function () {
      clickContinue();
    });
  var btn = document.getElementById("btn_div"),
    btn_text = document.createTextNode(bh_continue_mark);
  btn.appendChild(btn_text), 1 == toppic && showFirmVersion("none");
}
function clickContinue() {
  document.forms[0].submit();
}
addLoadEvent(initPage);
