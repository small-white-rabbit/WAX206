function initPage() {
  document.getElementById("btnsContainer_div").onclick = function () {
    return goto_finish();
  };
  var btn = document.getElementById("btn_div"),
    btn_text = document.createTextNode(bh_finish_mark);
  btn.appendChild(btn_text), setTimeout("show_content_div()", 25e3);
}
function goto_finish() {
  "0" == router_or_ap && (this.location.href = "BRS_01_checkNet_ping.html"),
    "1" == router_or_ap && (this.location.href = "BRS_00_03_ap_setup.html");
}
function show_content_div() {
  (document.getElementById("wait_div").style.display = "none"),
    (document.getElementById("content_div").style.display = "");
}
addLoadEvent(initPage);
