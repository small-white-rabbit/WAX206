function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    connect_text = document.createTextNode(bh_no_internet_ip3);
  head_tag[0].appendChild(connect_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_use_pc_mac);
  paragraph[0].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_mac_in_product_label)),
    paragraph[1].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_enter_mac)),
    paragraph[2].appendChild(paragraph_text);
  var input_item = document
      .getElementById("mac_input_div")
      .getElementsByTagName("input"),
    input_text = document.createTextNode(bh_mac_format);
  insertAfter(input_text, input_item[0]),
    (document.getElementById("spoofmac").onkeypress = macKeyCode);
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master &&
      (btn.onclick = function () {
        return checkMacApply();
      }),
    showFirmVersion("");
}
function checkMacApply() {
  var cf = document.getElementsByTagName("form")[0],
    mac_input = document.getElementById("spoofmac"),
    the_mac = mac_input.value;
  if (-1 == the_mac.indexOf(":") && "12" == the_mac.length) {
    var tmp_mac =
      the_mac.substr(0, 2) +
      ":" +
      the_mac.substr(2, 2) +
      ":" +
      the_mac.substr(4, 2) +
      ":" +
      the_mac.substr(6, 2) +
      ":" +
      the_mac.substr(8, 2) +
      ":" +
      the_mac.substr(10, 2);
    mac_input.value = tmp_mac;
  } else if (6 == the_mac.split("-").length) {
    tmp_mac = the_mac.replace(/-/g, ":");
    mac_input.value = tmp_mac;
  }
  return 0 != maccheck_multicast(mac_input.value) && (cf.submit(), !0);
}
addLoadEvent(initPage);
