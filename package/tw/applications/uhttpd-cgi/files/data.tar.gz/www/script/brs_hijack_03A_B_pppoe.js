function initPage() {
  var head_tag = document.getElementsByTagName("h2"),
    head_text = document.createTextNode(bh_pppoe_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_enter_info_below);
  paragraph[0].appendChild(paragraph_text);
  var login_name = document.getElementById("loginName"),
    login_text = document.createTextNode(bh_pppoe_login_name);
  login_name.appendChild(login_text);
  var passwd = document.getElementById("passwd"),
    passwd_text = document.createTextNode(bh_ddns_passwd);
  passwd.appendChild(passwd_text),
    (document.getElementById("pppoe_name").onkeypress = ssidKeyCode),
    (document.getElementById("pppoe_password").onkeypress = ssidKeyCode),
    1 == getTop(window).dsl_enable_flag &&
      ((cf = document.forms[0]),
      (cf.pppoe_username.value = ""),
      (cf.pppoe_passwd.value = ""));
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master
      ? (btn.onclick = function () {
          return checkPPPoE();
        })
      : (btn.className = "grey_short_btn"),
    showFirmVersion("none");
}
function checkPPPoE() {
  var i,
    cf = document.getElementsByTagName("form")[0],
    pppoe_name = document.getElementById("pppoe_name"),
    pppoe_passwd = document.getElementById("pppoe_password");
  if ("" == pppoe_name.value) return alert(bh_login_name_null), !1;
  for (i = 0; i < pppoe_passwd.value.length; i++)
    if (0 == isValidChar(pppoe_passwd.value.charCodeAt(i)))
      return alert(bh_password_error), !1;
  return cf.submit(), !0;
}
addLoadEvent(initPage);
