function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_ISP_namePasswd_error);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_enter_info_again);
  paragraph[0].appendChild(paragraph_text);
  var login_name = document.getElementById("loginName"),
    login_text = document.createTextNode(bh_pppoe_login_name);
  login_name.appendChild(login_text);
  var passwd = document.getElementById("passwd"),
    passwd_text = document.createTextNode(bh_ddns_passwd);
  passwd.appendChild(passwd_text),
    (document.getElementById("pppoe_name").onkeypress = ssidKeyCode),
    (document.getElementById("pppoe_password").onkeypress = ssidKeyCode);
  var btns1 = document.getElementById("self_config");
  (btns1.value = bh_manual_config_connection),
    "admin" == master
      ? (btns1.onclick = function () {
          return manuallyConfig();
        })
      : (btns1.className = "grey_long_btn");
  var btns2 = document.getElementById("again");
  (btns2.value = bh_try_again),
    "admin" == master
      ? (btns2.onclick = function () {
          return checkPPPoE();
        })
      : (btns2.className = "grey_common_btn"),
    showFirmVersion("");
}
function manuallyConfig() {
  if (0 == confirm(bh_no_genie_help_confirm)) return !1;
  if (1 == getTop(window).dsl_enable_flag)
    this.location.href = "BRS_log12_incorrect_go_to_internet.html";
  else {
    document.getElementsByTagName("form")[0];
    "1" == hijack_process
      ? (location.href = "BRS_security.html")
      : (location.href = "BAS_basic.htm");
  }
  return !0;
}
function checkPPPoE() {
  var i,
    cf = document.getElementsByTagName("form")[0],
    pppoe_name = document.getElementById("pppoe_name"),
    pppoe_passwd = document.getElementById("pppoe_password");
  if ("" == pppoe_name.value) return alert(bh_login_name_null), !1;
  for (i = 0; i < pppoe_passwd.value.length; i++)
    if (0 == isValidChar(pppoe_passwd.value.charCodeAt(i)))
      return alert(bh_password_error), !1;
  return cf.submit(), !0;
}
addLoadEvent(initPage);
