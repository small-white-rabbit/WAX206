function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_apply_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_plz_waite_apply_connection);
  paragraph[0].appendChild(paragraph_text),
    showFirmVersion("none"),
    loadValue();
}
function loadValue() {
  "success" == ping_result
    ? (this.location.href = "BRS_04_applySettings_ping.html")
    : count > 3 && (this.location.href = "BRS_04_applySettings_ping.html"),
    setTimeout("loadValue();", 1e3);
}
addLoadEvent(initPage);
