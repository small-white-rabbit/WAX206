function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_apply_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_plz_waite_apply_connection);
  paragraph[0].appendChild(paragraph_text),
    showFirmVersion("none"),
    "1" == ap_mode
      ? getTop(window).location.href.indexOf("BRS_index.htm") > -1
        ? getTop(window).location.href.indexOf("routerlogin.net") > -1
          ? setTimeout(
              "getTop(window).location.href='https://routerlogin.com/BRS_index.htm';",
              1e5
            )
          : setTimeout(
              "getTop(window).location.href='https://routerlogin.net/BRS_index.htm';",
              1e5
            )
        : setTimeout(
            "this.location.href='BRS_04_applySettings_ping.html';",
            1e5
          )
      : "1" == getTop(window).dsl_enable_flag
      ? getTop(window).location.href.indexOf("BRS_index.htm") > -1
        ? getTop(window).location.href.indexOf("routerlogin.net") > -1
          ? setTimeout("set_jump(1)", 2e4)
          : setTimeout("set_jump(2)", 2e4)
        : setTimeout(
            "this.location.href='BRS_04_applySettings_ppp_obtain_ip.html';",
            3e4
          )
      : getTop(window).location.href.indexOf("BRS_index.htm") > -1 &&
        1 != getTop(window).support_orange_flag &&
        "1" != getTop(window).orange_apply_flag
      ? getTop(window).location.href.indexOf("routerlogin.net") > -1
        ? 1 == getTop(window).support_orange_flag
          ? setTimeout(
              "getTop(window).location.href='https://routerlogin.com/BRS_index.htm';",
              75e3
            )
          : setTimeout(
              "getTop(window).location.href='https://routerlogin.com/BRS_index.htm';",
              6e4
            )
        : 1 == getTop(window).support_orange_flag
        ? setTimeout(
            "getTop(window).location.href='https://routerlogin.net/BRS_index.htm';",
            75e3
          )
        : setTimeout(
            "getTop(window).location.href='https://routerlogin.net/BRS_index.htm';",
            6e4
          )
      : 1 == getTop(window).support_orange_flag
      ? (setTimeout(
          "this.location.href='BRS_04_applySettings_ping.html';",
          75e3
        ),
        (getTop(window).orange_apply_flag = "0"))
      : setTimeout("this.location.href='BRS_04_applySettings_ping.html';", 6e4);
}
function set_jump(num) {
  var tHttp = createXMLHttpRequest(),
    url = "/obtain_ip.txt?ts=" + new Date().getTime();
  (tHttp.onreadystatechange = function () {
    4 == tHttp.readyState && 200 == tHttp.status
      ? (getTop(window).location.href =
          1 == num
            ? "https://routerlogin.com/BRS_index.htm"
            : "https://routerlogin.net/BRS_index.htm")
      : 4 == tHttp.readyState &&
        0 == tHttp.status &&
        (1 == num
          ? setTimeout(
              "getTop(window).location.href='https://routerlogin.com/BRS_index.htm';",
              2e4
            )
          : setTimeout(
              "getTop(window).location.href='https://routerlogin.net/BRS_index.htm';",
              2e4
            ));
  }),
    tHttp.open("GET", url, !0),
    tHttp.send(null);
}
addLoadEvent(initPage);
