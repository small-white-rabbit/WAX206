function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_plz_wait_moment);
  head_tag[0].appendChild(head_text),
    document
      .getElementById("waiting_img")
      .setAttribute("src", "image/wait30.gif"),
    setTimeout("formSubmit()", 5e4),
    showFirmVersion("none");
}
function formSubmit() {
  var cf = document.getElementsByTagName("form")[0];
  "1" == getTop(window).dsl_enable_flag
    ? (this.location.href = "BRS_dsl_type_detc.html")
    : cf.submit();
}
addLoadEvent(initPage);
