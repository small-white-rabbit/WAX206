function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_no_cable),
    wait_text = document.createTextNode(bh_detecting_connection);
  head_tag[0].appendChild(head_text), head_tag[1].appendChild(wait_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_wizard_setup_nowan_check);
  paragraph[0].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_plz_wait_process)),
    paragraph[2].appendChild(paragraph_text);
  var btns_container_div = document.getElementById("btnsContainer_div");
  "admin" == master &&
    (btns_container_div.onclick = function () {
      return clickRetry();
    });
  var btn = document.getElementById("btn_div"),
    btn_text = document.createTextNode(bh_try_again);
  btn.appendChild(btn_text), showFirmVersion("");
}
function clickRetry() {
  return (
    (document.getElementById("no_wan").style.display = "none"),
    (document.getElementById("please_wait").style.display = ""),
    showFirmVersion("none"),
    "1" == hijack_process
      ? -1 == location.href.indexOf("www.routerlogin.net")
        ? setTimeout(
            "getTop(window).location.href='https://www.routerlogin.net/BRS_retry.htm';",
            3e4
          )
        : setTimeout(
            "getTop(window).location.href='https://www.routerlogin.com/BRS_retry.htm';",
            3e4
          )
      : -1 == location.href.indexOf("www.routerlogin.net")
      ? setTimeout(
          "getTop(window).location.href='https://www.routerlogin.net/adv_index.htm';",
          3e4
        )
      : setTimeout(
          "getTop(window).location.href='https://www.routerlogin.com/adv_index.htm';",
          3e4
        ),
    !0
  );
}
addLoadEvent(initPage);
