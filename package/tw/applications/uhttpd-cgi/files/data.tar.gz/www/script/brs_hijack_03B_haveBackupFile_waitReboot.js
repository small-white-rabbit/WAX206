function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_settings_restoring);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_plz_waite_restore);
  paragraph[0].appendChild(paragraph_text), setTimeout("pageRedirect()", 15e4);
}
function pageRedirect(stat) {
  -1 == location.href.indexOf("www.routerlogin.net")
    ? (getTop(window).location.href =
        "https://www.routerlogin.net/BRS_03B_haveBackupFile_change_domain.htm")
    : (getTop(window).location.href =
        "https://www.routerlogin.com/BRS_03B_haveBackupFile_change_domain.htm");
}
addLoadEvent(initPage);
