function initPage() {
  if ("2" != restore_status) {
    var head_tag = document.getElementsByTagName("h1"),
      head_text = document.createTextNode(bh_settings_restoring);
    head_tag[0].appendChild(head_text);
    var paragraph = document.getElementsByTagName("p"),
      paragraph_text = document.createTextNode(bh_plz_waite_restore);
    paragraph[0].appendChild(paragraph_text);
  } else {
    (head_tag = document.getElementsByTagName("h1"))[0].setAttribute(
      "class",
      "h1_red"
    );
    head_text = document.createTextNode(bh_failure_head);
    head_tag[0].appendChild(head_text);
    (paragraph = document.getElementsByTagName("p")),
      (paragraph_text = document.createTextNode(bh_few_second));
    paragraph[0].appendChild(paragraph_text);
  }
  statusChecking();
}
function statusChecking() {
  if ("0" == restore_status || "1" == restore_status)
    setTimeout("pageRedirect(1)", 1e3);
  else if ("2" == restore_status) setTimeout("pageRedirect(2)", 3e3);
  else if ("3" == restore_status) {
    document.getElementsByTagName("form")[0].submit();
  }
}
function pageRedirect(stat) {
  1 == stat
    ? (this.location.href = "BRS_03B_haveBackupFile_fileRestore.html")
    : 2 == stat && (this.location.href = "BRS_03B_haveBackupFile.html");
}
addLoadEvent(initPage);
