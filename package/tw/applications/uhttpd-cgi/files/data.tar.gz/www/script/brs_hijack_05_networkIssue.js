function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_netword_issue);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_cannot_connect_internet);
  paragraph[0].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_plz_reveiw_items)),
    paragraph[1].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_try_again_or_manual_config)),
    paragraph[2].appendChild(paragraph_text);
  var list_items = document
    .getElementsByTagName("ul")[0]
    .getElementsByTagName("li");
  (paragraph_text = document.createTextNode(bh_cable_connection)),
    list_items[0].appendChild(paragraph_text),
    (paragraph_text = document.createTextNode(bh_modem_power_properly)),
    list_items[1].appendChild(paragraph_text);
  var choices = document
      .getElementById("choices_div")
      .getElementsByTagName("input"),
    choices_text = document.createTextNode(bh_yes_mark);
  insertAfter(choices_text, choices[0]),
    (choices_text = document.createTextNode(bh_I_want_manual_config)),
    insertAfter(choices_text, choices[1]);
  var btns_container_div = document.getElementById("btnsContainer_div");
  "admin" == master &&
    (btns_container_div.onclick = function () {
      return clickNext();
    });
  var btn = document.getElementById("btn_div"),
    btn_text = document.createTextNode(bh_next_mark);
  btn.appendChild(btn_text), showFirmVersion("");
}
function clickNext() {
  var choices = document
      .getElementById("choices_div")
      .getElementsByTagName("input"),
    cf = document.getElementsByTagName("form")[0];
  if (choices[0].checked)
    if (
      "1" == getTop(window).apmode_flag &&
      "1" == ap_mode &&
      "1" == getTop(window).ap_mode_detection_flag
    )
      this.location.href = "BRS_00_02_ap_select.html";
    else {
      if (
        ("1" != getTop(window).have_broadband ||
          (1 != getTop(window).is_ru_version &&
            1 != getTop(window).is_pr_version)) &&
        "1" != getTop(window).have_lte_flag
      )
        return showFirmVersion("none"), cf.submit(), !0;
      (getTop(window).multi_wan_mode_ether = "0"),
        (this.location.href = "WIZ_sel_3g_adsl.htm");
    }
  else if (choices[1].checked)
    return (
      0 != confirm(bh_no_genie_help_confirm) &&
      (1 == getTop(window).support_orange_flag ||
      1 == getTop(window).support_singapore_isp_flag ||
      1 == getTop(window).support_malaysia_isp_flag ||
      1 == getTop(window).support_spain_isp_flag ||
      1 == getTop(window).support_malaysia_pppoe_isp_flag
        ? "0" != internet_type ||
          ("6" != internet_ppp_type &&
            "7" != internet_ppp_type &&
            "8" != internet_ppp_type &&
            "9" != internet_ppp_type &&
            "10" != internet_ppp_type &&
            "11" != internet_ppp_type &&
            "12" != internet_ppp_type &&
            "13" != internet_ppp_type &&
            "14" != internet_ppp_type &&
            "15" != internet_ppp_type) ||
          ((cf.submit_flag.value = "hijack_toStatus"),
          (cf.action = "/apply.cgi?/index.htm timestamp=" + ts),
          (cf.target = "_top"),
          cf.submit())
        : (this.location.href = "BRS_security.html"),
      !0)
    );
}
addLoadEvent(initPage);
