function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_ISP_namePasswd_error);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_enter_info_again);
  paragraph[0].appendChild(paragraph_text);
  var login_name = document.getElementById("loginName"),
    login_text = document.createTextNode(bh_pptp_login_name + ":");
  login_name.appendChild(login_text);
  var passwd = document.getElementById("passwd"),
    passwd_text = document.createTextNode(bh_ddns_passwd + ":");
  passwd.appendChild(passwd_text);
  var idleTimeout = document.getElementById("idleTimeout"),
    idleTimeout_text = document.createTextNode(bh_basic_pppoe_idle);
  idleTimeout.appendChild(idleTimeout_text);
  var IP_addr_div = document.getElementById("IP_addr"),
    IP_addr_text = document.createTextNode(bh_info_mark_ip);
  IP_addr_div.appendChild(IP_addr_text);
  var sub_mask_div = document.getElementById("subnet_mask"),
    sub_mask_text = document.createTextNode(bh_info_mark_mask);
  sub_mask_div.appendChild(sub_mask_text);
  var serverIP_div = document.getElementById("serverIP"),
    serverIP_text = document.createTextNode(bh_basic_pptp_servip);
  serverIP_div.appendChild(serverIP_text);
  var Gateway_div = document.getElementById("Gateway"),
    Gateway_text = document.createTextNode(bh_sta_routes_gtwip);
  Gateway_div.appendChild(Gateway_text),
    (document.getElementById("inputName").onkeypress = ssidKeyCode),
    (document.getElementById("inputPasswd").onkeypress = ssidKeyCode),
    (document.getElementById("inputIdle").onkeypress = numKeyCode),
    (document.getElementById("inputIPaddr").onkeypress = ipaddrKeyCode),
    (document.getElementById("inputSubnetMask").onkeypress = ipaddrKeyCode);
  var severIP_input = document.getElementById("inputServerIP");
  (severIP_input.value = "10.0.0.138"),
    (severIP_input.disabled = !0),
    (document.getElementById("inputGateway").onkeypress = ipaddrKeyCode);
  var btns_div1 = document.getElementById("btnsContainer_div1");
  "admin" == master &&
    (btns_div1.onclick = function () {
      return manuallyConfig();
    });
  var btn = btns_div1.getElementsByTagName("div"),
    btn_text = document.createTextNode(bh_manual_config_connection);
  btn[0].appendChild(btn_text);
  var btns_div2 = document.getElementById("btnsContainer_div2");
  "admin" == master &&
    (btns_div2.onclick = function () {
      return checkL2TP();
    }),
    (btn = btns_div2.getElementsByTagName("div")),
    (btn_text = document.createTextNode(bh_try_again)),
    btn[0].appendChild(btn_text),
    showFirmVersion("");
}
function manuallyConfig() {
  if (0 == confirm(bh_no_genie_help_confirm)) return !1;
  if (1 == getTop(window).dsl_enable_flag)
    this.location.href = "BRS_log12_incorrect_go_to_internet.html";
  else {
    document.getElementsByTagName("form")[0];
    "1" == hijack_process
      ? (location.href = "BRS_security.html")
      : (location.href = "BAS_basic.htm");
  }
  return !0;
}
function checkL2TP() {
  var i,
    cf = document.getElementsByTagName("form")[0],
    l2tp_username = document.getElementById("inputName"),
    l2tp_passwd = document.getElementById("inputPasswd"),
    l2tp_idletime = document.getElementById("inputIdle");
  if ("" == l2tp_username.value) return alert(bh_login_name_null), !1;
  for (i = 0; i < l2tp_passwd.value.length; i++)
    if (0 == isValidChar(l2tp_passwd.value.charCodeAt(i)))
      return alert(bh_password_error), !1;
  return l2tp_idletime.value.length <= 0
    ? (alert(bh_idle_time_null), !1)
    : _isNumeric(l2tp_idletime.value)
    ? !!checkIPaddr() && (cf.submit(), !0)
    : (alert(bh_invalid_idle_time), !1);
}
function checkIPaddr() {
  var cf = document.getElementsByTagName("form")[0],
    l2tp_myip = document.getElementById("inputIPaddr"),
    l2tp_gateway = document.getElementById("inputGateway");
  if ("" != l2tp_myip.value) {
    if (((cf.WANAssign.value = 1), 0 == checkipaddr(l2tp_myip.value)))
      return alert(bh_invalid_myip), !1;
    if ("" != l2tp_gateway.value && 0 == checkgateway(l2tp_gateway.value))
      return alert(bh_invalid_gateway), !1;
    if (
      "" != l2tp_gateway.value &&
      1 == isSameIp(l2tp_myip.value, pptp_gateway.value)
    )
      return alert(bh_invalid_gateway), !1;
  } else cf.WANAssign.value = 0;
  return !0;
}
addLoadEvent(initPage);
