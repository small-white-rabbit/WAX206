function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_bpa_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_enter_info_below);
  paragraph[0].appendChild(paragraph_text);
  var login_name = document.getElementById("loginName"),
    login_text = document.createTextNode(bh_pptp_login_name);
  login_name.appendChild(login_text);
  var passwd = document.getElementById("passwd"),
    passwd_text = document.createTextNode(bh_ddns_passwd);
  passwd.appendChild(passwd_text);
  var idleTimeout_div = document.getElementById("idleTimeout"),
    idleTimeout_text = document.createTextNode(bh_basic_pppoe_idle);
  idleTimeout_div.appendChild(idleTimeout_text);
  var serverIP_div = document.getElementById("serverIP"),
    serverIP_text = document.createTextNode(bh_basic_bpa_auth_serv);
  serverIP_div.appendChild(serverIP_text),
    (document.getElementById("inputName").onkeypress = ssidKeyCode),
    (document.getElementById("inputPasswd").onkeypress = ssidKeyCode),
    (document.getElementById("inputIdle").onkeypress = numKeyCode),
    (document.getElementById("inputServerIP").onkeypress = ssidKeyCode),
    (document.getElementById("btnsContainer_div").onclick = function () {
      return checkBPA();
    });
  var btn = document.getElementById("btn_text_div"),
    btn_text = document.createTextNode(bh_next_mark);
  btn.appendChild(btn_text);
}
function checkBPA() {
  var cf = document.getElementsByTagName("form")[0],
    bpa_username = document.getElementById("inputName"),
    bpa_passwd = document.getElementById("inputPasswd"),
    bpa_idletime = document.getElementById("inputIdle"),
    bpa_server = document.getElementById("inputServerIP");
  if ("" == bpa_username.value) return alert(bh_login_name_null), !1;
  for (i = 0; i < bpa_passwd.value.length; i++)
    if (0 == isValidChar(bpa_passwd.value.charCodeAt(i)))
      return alert(bh_password_error), !1;
  if (bpa_idletime.value.length <= 0) return alert(bh_idle_time_null), !1;
  if (!_isNumeric(bpa_idletime.value)) return alert(bh_invalid_idle_time), !1;
  if (bpa_server.value.length <= 0) return alert(bh_bpa_invalid_serv_name), !1;
  var i,
    server_addr_array = bpa_server.value.split(".");
  for (i = 0; i < server_addr_array.length; i++)
    if (server_addr_array[i].length > 63)
      return alert(bh_invalid_servip_length), !1;
  for (i = 0; i < bpa_server.value.length; i++)
    if (0 == isValidChar(bpa_server.value.charCodeAt(i)))
      return alert(bh_bpa_invalid_serv_name), !1;
  return cf.submit(), !0;
}
addLoadEvent(initPage);
