function goto_next(cf, wl_login) {
  var pre_url_info_2 = document.referrer.split("/");
  if (cf.use_ap[0].checked) {
    var ssid_bgn = document.getElementById("ESSID").value,
      ssid_an = document.getElementById("ESSID_an").value;
    if (!brs_check_ssid(ssid_bgn) || !brs_check_ssid(ssid_an)) return !1;
    if (0 == checkpsk(cf.passphrase_an, cf.wla_sec_wpaphrase_len)) return;
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return;
    if ("1" == ad_router_flag && !validate_ad(cf)) return;
    return (
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value),
      (cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value),
      (cf.method = "post"),
      1 == wl_login
        ? "BRS_ap_detect_01_ap_01.html" == pre_url_info_2[3]
          ? ((cf.ap_pre_link.value = "0"),
            (cf.action =
              "/apply.cgi?/BRS_ap_detect_01_04.html timestamp=" + ts))
          : ((cf.ap_pre_link.value = "1"),
            (cf.action =
              "/apply.cgi?/BRS_ap_detect_01_04.html timestamp=" + ts))
        : "BRS_ap_detect_01_ap_01.html" == pre_url_info_2[3]
        ? ((cf.ap_pre_link.value = "0"),
          (cf.action = "/apply.cgi?/BRS_00_03_ap_setup.html timestamp=" + ts))
        : ((cf.ap_pre_link.value = "1"),
          (cf.action = "/apply.cgi?/BRS_00_03_ap_setup.html timestamp=" + ts)),
      (cf.submit_flag.value = "wl_ssid_password"),
      cf.submit(),
      !0
    );
  }
  if (!cf.use_ap[1].checked) return alert(bh_warning_info), !1;
  1 == wl_login
    ? "BRS_ap_detect_01_ap_01.html" == pre_url_info_2[3]
      ? (this.location.href = "BRS_ap_detect_01_03_note.html?id=0")
      : (this.location.href = "BRS_ap_detect_01_03_note.html?id=1")
    : "BRS_ap_detect_01_ap_01.html" == pre_url_info_2[3]
    ? (this.location.href = "BRS_00_03_ap_setup.html?id=0")
    : (this.location.href = "BRS_00_03_ap_setup.html?id=1");
}
function goback() {
  var pre_url_info_1 = document.referrer.split("/");
  if ("BRS_ap_detect_01_ap_01.html" == pre_url_info_1[3])
    this.location.href = "BRS_ap_detect_01_ap_01.html";
  else if ("BRS_00_02_ap_select.html" == pre_url_info_1[3])
    this.location.href = "BRS_00_02_ap_select.html";
  else if (-1 != pre_url_info_1[3].indexOf("id=")) {
    "0" == pre_url_info_1[3].split("=")[1]
      ? (this.location.href = "BRS_ap_detect_01_ap_01.html")
      : (this.location.href = "BRS_00_02_ap_select.html");
  } else
    "0" == ap_pre_link
      ? (this.location.href = "BRS_ap_detect_01_ap_01.html")
      : (this.location.href = "BRS_00_02_ap_select.html");
}
