function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_no_cable);
  document.createTextNode(bh_detecting_connection);
  head_tag[0].appendChild(head_text),
    (document.getElementById("btnsContainer_div2").onclick = function () {
      return genienowanChecking();
    });
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_wizard_setup_nowan_check);
  paragraph[0].appendChild(paragraph_text);
  var btnskip = document.getElementById("btnskip_div"),
    btnskip_text = document.createTextNode(bh_next_mark);
  btnskip.appendChild(btnskip_text), showFirmVersion("");
}
function genienowanChecking() {
  document.forms[0];
  document.getElementById("choices_div").getElementsByTagName("input")[0]
    .checked
    ? (this.location.href = "BRS_00_01_check_ap_wait.html")
    : (this.location.href = "BRS_security.html");
}
function clickRetry() {
  return (this.location.href = "BRS_00_01_check_ap_wait.html"), !0;
}
function clickskip() {
  return (
    (getTop(window).wan_port = 1),
    (this.location.href = "BRS_00_01_check_ap.html"),
    !0
  );
}
addLoadEvent(initPage);
