function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_settings_restoration);
  head_tag[0].appendChild(head_text);
  document.getElementsByTagName("p");
  document.getElementById("browse").value = bh_browse_mark;
  var btns_div1 = document.getElementById("back");
  (btns_div1.value = bh_back_mark),
    "admin" == master
      ? (btns_div1.onclick = function () {
          return goBack();
        })
      : (btns_div1.className = "grey_short_btn");
  var btns_div2 = document.getElementById("next");
  (btns_div2.value = bh_next_mark),
    "admin" == master
      ? (btns_div2.onclick = function () {
          return retoreSettings();
        })
      : (btns_div2.className = "grey_short_btn");
}
function goBack() {
  return (
    "0" == getTop(window).dsl_enable_flag
      ? (this.location.href = "BRS_02_genieHelp.html")
      : getTop(window).location.href.indexOf("BRS_index.htm") > -1
      ? (this.location.href = "BRS_ISP_country_help.html")
      : (this.location.href = "DSL_WIZ_sel.htm"),
    !0
  );
}
function retoreSettings() {
  var cf = document.getElementsByTagName("form")[0],
    filestr = document.getElementById("file_upgrade").value;
  return 0 == filestr.length
    ? (alert(bh_filename_null), !1)
    : "cfg" != filestr.substr(filestr.lastIndexOf(".") + 1)
    ? (alert(bh_not_correct_file + "cfg"), !1)
    : !!confirm(bh_ask_for_restore) &&
      ((cf.action =
        "/restore.cgi?/BRS_03B_haveBackupFile_fileRestore.html timestamp=" +
        ts),
      void cf.submit());
}
function IE_version() {
  var s,
    Sys = {};
  return (
    (s = navigator.userAgent.toLowerCase().match(/msie ([\d.]+)/)) &&
      (Sys.ie = s[1]),
    "6.0" == Sys.ie
      ? 6
      : "7.0" == Sys.ie
      ? 7
      : "8.0" == Sys.ie
      ? 8
      : "9.0" == Sys.ie
      ? 9
      : "10.0" == Sys.ie
      ? 10
      : 11
  );
}
addLoadEvent(initPage);
