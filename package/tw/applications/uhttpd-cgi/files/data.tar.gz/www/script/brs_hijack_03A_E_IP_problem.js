function manuallyConfig() {
  document.getElementsByTagName("form")[0];
  return (this.location.href = "BRS_security.html"), !0;
}
function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    connect_text = document.createTextNode(bh_no_internet_ip);
  head_tag[0].appendChild(connect_text);
  var choices = document
      .getElementById("choices_div")
      .getElementsByTagName("input"),
    choices_text = document.createTextNode(bh_select_no_IP_option1);
  insertAfter(choices_text, choices[0]),
    (choices_text = document.createTextNode(bh_select_no_IP_option2)),
    insertAfter(choices_text, choices[1]),
    (choices_text = document.createTextNode(bh_select_no_IP_option3)),
    insertAfter(choices_text, choices[2]);
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    "admin" == master
      ? (btn.onclick = function () {
          return modemCycleChoice();
        })
      : (btn.className = "grey_short_btn"),
    showFirmVersion("");
}
function modemCycleChoice() {
  var cf = document.getElementsByTagName("form")[0],
    choices = document
      .getElementById("choices_div")
      .getElementsByTagName("input");
  if (choices[0].checked || choices[1].checked) cf.submit();
  else {
    if (!choices[2].checked) return alert(bh_select_an_option), !1;
    this.location.href = "BRS_03A_E_IP_problem_staticIP.html";
  }
  return !0;
}
addLoadEvent(initPage);
