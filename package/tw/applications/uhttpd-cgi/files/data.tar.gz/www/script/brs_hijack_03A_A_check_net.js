function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_detecting_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_plz_wait_process);
  paragraph[0].appendChild(paragraph_text),
    showFirmVersion("none"),
    setTimeout("loadValue()", 3e3);
}
function loadValue() {
  var cf = document.getElementsByTagName("form")[0];
  "failed" == checking_result
    ? cf.submit()
    : "success" == checking_result &&
      (this.location.href = "BRS_security.html");
}
addLoadEvent(initPage);
