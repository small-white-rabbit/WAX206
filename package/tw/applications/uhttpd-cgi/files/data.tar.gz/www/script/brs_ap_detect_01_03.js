function initPage() {
  var btns_div1 = document.getElementById("btnsContainer_div1");
  "admin" == master &&
    (btns_div1.onclick = function () {
      return goback();
    });
  var btn = btns_div1.getElementsByTagName("div"),
    btn_text = document.createTextNode(bh_back_mark);
  btn[0].appendChild(btn_text);
  var btns_div2 = document.getElementById("btnsContainer_div2");
  "admin" == master &&
    (btns_div2.onclick = function () {
      return goto_next();
    }),
    (btn = btns_div2.getElementsByTagName("div")),
    (btn_text = document.createTextNode(bh_next_mark)),
    btn[0].appendChild(btn_text);
}
function goto_next() {
  var choice_radio = document
    .getElementById("choices_div")
    .getElementsByTagName("input");
  if (choice_radio[0].checked)
    this.location.href = "BRS_ap_detect_01_router_01.html";
  else {
    if (!choice_radio[1].checked) return alert(bh_select_yes_or_no), !1;
    this.location.href = "BRS_ap_detect_01_ap_01.html";
  }
}
function goback() {
  this.location.href = "BRS_ap_detect_01_02.html";
}
addLoadEvent(initPage);
