function initPage() {
  loadValue();
}
function loadValue() {
  var cf = document.getElementsByTagName("form")[0],
    finish = 0;
  "failed" == ping_result
    ? 1 == getTop(window).dsl_enable_flag
      ? ((this.location.href = "BRS_log02_connection_fail.html"), (finish = 1))
      : ("1" == getTop(window).apmode_flag &&
        "1" == ap_mode &&
        "1" == ap_mode_detection_flag
          ? (this.location.href = "BRS_05_networkIssue.html")
          : ("1" == getTop(window).have_broadband &&
              (1 == getTop(window).is_ru_version ||
                1 == getTop(window).is_pr_version)) ||
            "1" == getTop(window).have_lte_flag
          ? (this.location.href = "BRS_021_genieHelp.html")
          : 1 == getTop(window).is_ru_version
          ? (this.location.href = "RU_welcome.htm")
          : (this.location.href = "BRS_02_genieHelp.html"),
        (finish = 1))
    : "success" == ping_result &&
      (1 == getTop(window).dsl_enable_flag
        ? ((this.location.href = "BRS_log02_connection_success.html"),
          (finish = 1))
        : (1 == getTop(window).hdd_multi_user
            ? 2 == hijack_process && 0 == parent.first_hdd_nofind
              ? cf.submit()
              : (this.location.href = "BRS_security.html")
            : 2 == hijack_process
            ? cf.submit()
            : (this.location.href = "BRS_security.html"),
          (finish = 1))),
    1 != finish && setTimeout("loadValue();", 1e3);
}
addLoadEvent(initPage);
