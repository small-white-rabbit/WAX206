/**
 * @param frameWindow {Window}
 * @returns {Window}
*/
function getTop(frameWindow) {
  try {
    var parentWindow = frameWindow.parent;
    return void 0 !== frameWindow.netgear_version
      ? frameWindow
      : parentWindow === frameWindow
      ? frameWindow
      : parentWindow.origin !== frameWindow.origin
      ? frameWindow
      : getTop(parentWindow);
  } catch (e) {
    return top;
  }
}
function check_DNS(dnsaddr1, dnsaddr2, wan_assign, wan_ip) {
  if ("" != dnsaddr1) {
    if (0 == checkdnsaddr(dnsaddr1)) return alert(bh_invalid_primary_dns), !1;
    if (1 == wan_assign && isSameIp(dnsaddr1, wan_ip))
      return alert(bh_invalid_primary_dns), !1;
  }
  if ("" != dnsaddr2) {
    if (0 == checkdnsaddr(dnsaddr2)) return alert(bh_invalid_second_dns), !1;
    if (1 == wan_assign && isSameIp(dnsaddr2, wan_ip))
      return alert(bh_invalid_second_dns), !1;
  }
  return "" != dnsaddr1 || "" != dnsaddr2 || (alert(bh_dns_must_specified), !1);
}
function check_three_DNS(dnsaddr1, dnsaddr2, dnsaddr3, wan_assign, wan_ip) {
  if ("" != dnsaddr1) {
    if (0 == checkdnsaddr(dnsaddr1)) return alert(bh_invalid_primary_dns), !1;
    if (1 == wan_assign && isSameIp(dnsaddr1, wan_ip))
      return alert(bh_invalid_primary_dns), !1;
  }
  if ("" != dnsaddr2) {
    if (0 == checkdnsaddr(dnsaddr2)) return alert(bh_invalid_second_dns), !1;
    if (1 == wan_assign && isSameIp(dnsaddr2, wan_ip))
      return alert(bh_invalid_second_dns), !1;
  }
  if ("" != dnsaddr3) {
    if (0 == checkdnsaddr(dnsaddr3)) return alert(hb_invalid_third_dns), !1;
    if (1 == wan_assign && isSameIp(dnsaddr3, wan_ip))
      return alert(hb_invalid_third_dns), !1;
  }
  return (
    "" != dnsaddr1 ||
    "" != dnsaddr2 ||
    "" != dnsaddr3 ||
    (alert(bh_dns_must_specified), !1)
  );
}
function SelectionTextLength(text) {
  var select_text = "";
  return (
    document.selection && document.selection.createRange
      ? (select_text = document.selection.createRange().text)
      : "" == select_text &&
        null != text.selectionStart &&
        (select_text = text.value.substring(
          text.selectionStart,
          text.selectionEnd
        )),
    select_text.length
  );
}
function keydown(e, text) {
  (190 != e.keyCode && 110 != e.keyCode) ||
    0 == text.value.length ||
    0 != SelectionTextLength(text) ||
    text.form[(getIndex(text) + 1) % text.form.length].focus();
}
function keyup(e, text) {
  3 == text.value.length &&
    ((e.keyCode > 47 && e.keyCode < 58) ||
      (e.keyCode > 95 && e.keyCode < 106)) &&
    text.form[(getIndex(text) + 1) % text.form.length].focus();
}
function getIndex(input) {
  for (var index = -1, i = 0; i < input.form.length && -1 == index; )
    input.form[i] == input ? (index = i) : i++;
  return index;
}
function get_browser() {
  return -1 != navigator.userAgent.indexOf("MSIE")
    ? "IE"
    : -1 != navigator.userAgent.indexOf("Firefox")
    ? "Firefox"
    : -1 != navigator.userAgent.indexOf("Safari")
    ? "Safari"
    : -1 != navigator.userAgent.indexOf("Camino")
    ? "Camino"
    : -1 != navigator.userAgent.indexOf("Gecko/")
    ? "Gecko"
    : "";
}
function _isNumeric(str) {
  var i;
  for (i = 0; i < str.length; i++) {
    var c = str.substring(i, i + 1);
    if (!("0" <= c && c <= "9")) return !1;
  }
  return !0;
}
function isSameIp(ipstr1, ipstr2) {
  var count = 0,
    ip1_array = ipstr1.split("."),
    ip2_array = ipstr2.split(".");
  for (i = 0; i < 4; i++)
    (num1 = parseInt(ip1_array[i])),
      (num2 = parseInt(ip2_array[i])),
      num1 == num2 && count++;
  return 4 == count;
}
function is_sub_or_broad(be_checkip, ip, mask) {
  addr_arr = be_checkip.split(".");
  var ip_addr = 0;
  for (i = 0; i < 4; i++)
    (addr_str = parseInt(addr_arr[i], 10)),
      (ip_addr = 256 * ip_addr + parseInt(addr_str));
  var ip_sub = isSub(ip, mask),
    ip_broadcast = isBroadcast(ip, mask);
  return ip_addr != ip_sub && ip_addr != ip_broadcast;
}
function isGateway(lanIp, lanMask, gtwIp) {
  gtw_arr = gtwIp.split(".");
  var ip_gtw = 0;
  for (i = 0; i < 4; i++)
    (gtw_str = parseInt(gtw_arr[i], 10)),
      (ip_gtw = 256 * ip_gtw + parseInt(gtw_str));
  addr_arr = lanIp.split(".");
  var ip_addr = 0;
  for (i = 0; i < 4; i++)
    (addr_str = parseInt(addr_arr[i], 10)),
      (ip_addr = 256 * ip_addr + parseInt(addr_str));
  var ip_sub = isSub(lanIp, lanMask),
    ip_broadcast = isBroadcast(lanIp, lanMask);
  return (
    parseInt(ip_sub) < parseInt(ip_gtw) &&
    parseInt(ip_gtw) < parseInt(ip_broadcast)
  );
}
function isSub(lanIp, lanMask) {
  (ip_arr = lanIp.split(".")), (mask_arr = lanMask.split("."));
  var ip_sub = 0;
  for (i = 0; i < 4; i++)
    (ip_str = parseInt(ip_arr[i], 10)),
      (mask_str = parseInt(mask_arr[i], 10)),
      (ip_sub = 256 * ip_sub + parseInt(ip_str & mask_str));
  return ip_sub;
}
function isBroadcast(lanIp, lanMask) {
  (ip_arr = lanIp.split(".")), (mask_arr = lanMask.split("."));
  var ip_broadcast = 0;
  for (i = 0; i < 4; i++)
    (ip_str = parseInt(ip_arr[i], 10)),
      (mask_str = parseInt(mask_arr[i], 10)),
      (n_str = ~mask_str + 256),
      (ip_broadcast = 256 * ip_broadcast + parseInt(ip_str | n_str));
  return ip_broadcast;
}
function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {
  var count = 0;
  for (
    lan1a = lan1Ip.split("."),
      lan1m = lan1Mask.split("."),
      lan2a = lan2Ip.split("."),
      lan2m = lan2Mask.split("."),
      i = 0;
    i < 4;
    i++
  )
    (l1a_n = parseInt(lan1a[i], 10)),
      (l1m_n = parseInt(lan1m[i], 10)),
      (l2a_n = parseInt(lan2a[i], 10)),
      (l2m_n = parseInt(lan2m[i], 10)),
      (l1a_n & l1m_n) == (l2a_n & l2m_n) && count++;
  return 4 == count;
}
function checkdnsaddr(dnsaddr) {
  document.forms[0];
  var dnsArray = dnsaddr.split("."),
    dnsstr = dnsArray[0] + dnsArray[1] + dnsArray[2] + dnsArray[3],
    i = 0;
  if (
    "" == dnsArray[0] ||
    dnsArray[0] < 0 ||
    dnsArray[0] > 255 ||
    "" == dnsArray[1] ||
    dnsArray[1] < 0 ||
    dnsArray[1] > 255 ||
    "" == dnsArray[2] ||
    dnsArray[2] < 0 ||
    dnsArray[2] > 255 ||
    "" == dnsArray[3] ||
    dnsArray[3] < 0 ||
    dnsArray[3] > 255
  )
    return !1;
  for (i = 0; i < dnsstr.length; i++)
    if (
      "0" != dnsstr.charAt(i) &&
      "1" != dnsstr.charAt(i) &&
      "2" != dnsstr.charAt(i) &&
      "3" != dnsstr.charAt(i) &&
      "4" != dnsstr.charAt(i) &&
      "5" != dnsstr.charAt(i) &&
      "6" != dnsstr.charAt(i) &&
      "7" != dnsstr.charAt(i) &&
      "8" != dnsstr.charAt(i) &&
      "9" != dnsstr.charAt(i)
    )
      return !1;
  if (dnsArray[0] > 223 || 0 == dnsArray[0]) return !1;
  if ("0.0.0.0" == dnsaddr || "255.255.255.255" == dnsaddr) return !1;
  if ("127" == dnsaddr.split(".")[0]) return !1;
  if (!dnsArray || 4 != dnsArray.length) return !1;
  for (i = 0; i < 4; i++) {
    if (((thisSegment = dnsArray[i]), "" == thisSegment)) return !1;
    if (3 == i) {
      if (!(dnsArray[3] >= 0 && dnsArray[3] < 255)) return !1;
    } else if (!(thisSegment >= 0 && thisSegment <= 255)) return !1;
  }
  return !0;
}
function checkipaddr(ipaddr) {
  document.forms[0];
  var ipArray = ipaddr.split("."),
    ipstr = ipArray[0] + ipArray[1] + ipArray[2] + ipArray[3],
    i = 0;
  if (
    "" == ipArray[0] ||
    ipArray[0] < 0 ||
    ipArray[0] > 255 ||
    "" == ipArray[1] ||
    ipArray[1] < 0 ||
    ipArray[1] > 255 ||
    "" == ipArray[2] ||
    ipArray[2] < 0 ||
    ipArray[2] > 255 ||
    "" == ipArray[3] ||
    ipArray[3] < 0 ||
    ipArray[3] > 255
  )
    return !1;
  for (i = 0; i < ipstr.length; i++)
    if (
      "0" != ipstr.charAt(i) &&
      "1" != ipstr.charAt(i) &&
      "2" != ipstr.charAt(i) &&
      "3" != ipstr.charAt(i) &&
      "4" != ipstr.charAt(i) &&
      "5" != ipstr.charAt(i) &&
      "6" != ipstr.charAt(i) &&
      "7" != ipstr.charAt(i) &&
      "8" != ipstr.charAt(i) &&
      "9" != ipstr.charAt(i)
    )
      return !1;
  if (ipArray[0] > 223 || 0 == ipArray[0]) return !1;
  if ("0.0.0.0" == ipaddr || "255.255.255.255" == ipaddr) return !1;
  if ("127" == ipaddr.split(".")[0]) return !1;
  if (!ipArray || 4 != ipArray.length) return !1;
  for (i = 0; i < 4; i++) {
    if (((thisSegment = ipArray[i]), "" == thisSegment)) return !1;
    if (3 == i) {
      if (!(ipArray[3] > 0 && ipArray[3] < 255)) return !1;
    } else if (!(thisSegment >= 0 && thisSegment <= 255)) return !1;
  }
  return !0;
}
function checksubnet(subnet) {
  var subnetArray = subnet.split("."),
    subnetstr =
      subnetArray[0] + subnetArray[1] + subnetArray[2] + subnetArray[3],
    i = 0,
    maskTest = 0,
    validValue = !0;
  if (
    "" == subnetArray[0] ||
    subnetArray[0] < 0 ||
    subnetArray[0] > 255 ||
    "" == subnetArray[1] ||
    subnetArray[1] < 0 ||
    subnetArray[1] > 255 ||
    "" == subnetArray[2] ||
    subnetArray[2] < 0 ||
    subnetArray[2] > 255 ||
    "" == subnetArray[3] ||
    subnetArray[3] < 0 ||
    subnetArray[3] > 255
  )
    return !1;
  for (i = 0; i < subnetstr.length; i++)
    if (
      "0" != subnetstr.charAt(i) &&
      "1" != subnetstr.charAt(i) &&
      "2" != subnetstr.charAt(i) &&
      "3" != subnetstr.charAt(i) &&
      "4" != subnetstr.charAt(i) &&
      "5" != subnetstr.charAt(i) &&
      "6" != subnetstr.charAt(i) &&
      "7" != subnetstr.charAt(i) &&
      "8" != subnetstr.charAt(i) &&
      "9" != subnetstr.charAt(i)
    )
      return !1;
  if (!subnetArray || 4 != subnetArray.length) return !1;
  for (i = 0; i < 4; i++) {
    if (((thisSegment = subnetArray[i]), "" == thisSegment)) return !1;
    if (!(thisSegment >= 0 && thisSegment <= 255)) return !1;
  }
  if (
    (subnetArray[0] < 255
      ? subnetArray[1] > 0 || subnetArray[2] > 0 || subnetArray[3] > 0
        ? (validValue = !1)
        : (maskTest = subnetArray[0])
      : subnetArray[1] < 255
      ? subnetArray[2] > 0 || subnetArray[3] > 0
        ? (validValue = !1)
        : (maskTest = subnetArray[1])
      : subnetArray[2] < 255
      ? subnetArray[3] > 0
        ? (validValue = !1)
        : (maskTest = subnetArray[2])
      : (maskTest = subnetArray[3]),
    validValue)
  ) {
    switch (maskTest) {
      case "0":
      case "128":
      case "192":
      case "224":
      case "240":
      case "248":
      case "252":
      case "254":
      case "255":
        break;
      default:
        validValue = !1;
    }
    "0.0.0.0" == subnet && (validValue = !1);
  } else validValue = !1;
  return validValue;
}
function checkgateway(gateway) {
  document.forms[0];
  var dgArray = gateway.split("."),
    dgstr = dgArray[0] + dgArray[1] + dgArray[2] + dgArray[3],
    i = 0;
  if (
    "" == dgArray[0] ||
    dgArray[0] < 0 ||
    dgArray[0] > 255 ||
    "" == dgArray[1] ||
    dgArray[1] < 0 ||
    dgArray[1] > 255 ||
    "" == dgArray[2] ||
    dgArray[2] < 0 ||
    dgArray[2] > 255 ||
    "" == dgArray[3] ||
    dgArray[3] < 0 ||
    dgArray[3] > 255
  )
    return !1;
  for (i = 0; i < dgstr.length; i++)
    if (
      "0" != dgstr.charAt(i) &&
      "1" != dgstr.charAt(i) &&
      "2" != dgstr.charAt(i) &&
      "3" != dgstr.charAt(i) &&
      "4" != dgstr.charAt(i) &&
      "5" != dgstr.charAt(i) &&
      "6" != dgstr.charAt(i) &&
      "7" != dgstr.charAt(i) &&
      "8" != dgstr.charAt(i) &&
      "9" != dgstr.charAt(i)
    )
      return !1;
  if (dgArray[0] > 223 || 0 == dgArray[0]) return !1;
  if ("0.0.0.0" == gateway || "255.255.255.255" == gateway) return !1;
  if ("127.0.0.1" == gateway) return !1;
  if (!dgArray || 4 != dgArray.length) return !1;
  for (i = 0; i < 4; i++) {
    if (((thisSegment = dgArray[i]), "" == thisSegment)) return !1;
    if (!(thisSegment >= 0 && thisSegment <= 255)) return !1;
  }
  return !0;
}
function getkey(type, e) {
  var keycode, event;
  if (window.event) (event = window.event), (keycode = window.event.keyCode);
  else {
    if (!e) return !0;
    (event = e), (keycode = e.which);
  }
  return (
    !(!event.ctrlKey || (99 != keycode && 118 != keycode && 120 != keycode)) ||
    ("apname" == type
      ? 34 != keycode && 39 != keycode && 92 != keycode
      : "ipaddr" == type
      ? (keycode > 47 && keycode < 58) ||
        8 == keycode ||
        0 == keycode ||
        46 == keycode
      : "ssid" == type
      ? 32 != keycode
      : "wep" == type
      ? (keycode > 47 && keycode < 58) ||
        (keycode > 64 && keycode < 71) ||
        (keycode > 96 && keycode < 103) ||
        8 == keycode ||
        0 == keycode
      : "num" == type
      ? (keycode > 47 && keycode < 58) || 8 == keycode || 0 == keycode
      : "colon_num" == type
      ? (keycode > 47 && keycode < 58) ||
        46 == keycode ||
        8 == keycode ||
        0 == keycode
      : "num_letter" == type
      ? (keycode > 47 && keycode < 58) ||
        (keycode > 64 && keycode < 91) ||
        (keycode > 96 && keycode < 123) ||
        8 == keycode ||
        0 == keycode
      : "hostname" == type
      ? (keycode > 47 && keycode < 58) ||
        45 == keycode ||
        (keycode > 64 && keycode < 91) ||
        (keycode > 96 && keycode < 123) ||
        8 == keycode ||
        0 == keycode
      : "ddns_hostname" == type
      ? (keycode > 47 && keycode < 58) ||
        45 == keycode ||
        46 == keycode ||
        (keycode > 64 && keycode < 91) ||
        (keycode > 96 && keycode < 123) ||
        8 == keycode ||
        0 == keycode
      : "mac" == type
      ? (keycode > 47 && keycode < 58) ||
        (keycode > 64 && keycode < 71) ||
        (keycode > 96 && keycode < 103) ||
        8 == keycode ||
        0 == keycode ||
        58 == keycode ||
        45 == keycode
      : "folderPath" == type
      ? 47 != keycode &&
        42 != keycode &&
        63 != keycode &&
        34 != keycode &&
        60 != keycode &&
        62 != keycode &&
        124 != keycode
      : "shareName" == type
      ? 47 != keycode &&
        42 != keycode &&
        63 != keycode &&
        34 != keycode &&
        58 != keycode &&
        60 != keycode &&
        62 != keycode &&
        92 != keycode &&
        93 != keycode &&
        124 != keycode
      : "mediaServerName" == type &&
        ((47 != keycode &&
          42 != keycode &&
          63 != keycode &&
          34 != keycode &&
          58 != keycode &&
          60 != keycode &&
          62 != keycode &&
          92 != keycode &&
          93 != keycode &&
          124 != keycode) ||
          (alert("$media_server_name_colon"), !1)))
  );
}
function setDisabled(OnOffFlag, formFields) {
  for (var i = 1; i < setDisabled.arguments.length; i++)
    setDisabled.arguments[i].disabled = OnOffFlag;
}
function maccheck_multicast(mac_addr) {
  mac_array = mac_addr.split(":");
  var mac11 = mac_array[0];
  if (
    "1" == (mac11 = mac11.substr(1, 1)) ||
    "3" == mac11 ||
    "5" == mac11 ||
    "7" == mac11 ||
    "9" == mac11 ||
    "b" == mac11 ||
    "d" == mac11 ||
    "f" == mac11 ||
    "B" == mac11 ||
    "D" == mac11 ||
    "F" == mac11
  )
    return alert(bh_invalid_mac), !1;
  if (6 != mac_array.length) return alert(bh_invalid_mac), !1;
  if (
    "" == mac_array[0] ||
    "" == mac_array[1] ||
    "" == mac_array[2] ||
    "" == mac_array[3] ||
    "" == mac_array[4] ||
    "" == mac_array[5]
  )
    return alert(bh_invalid_mac), !1;
  if (
    ("00" == mac_array[0] &&
      "00" == mac_array[1] &&
      "00" == mac_array[2] &&
      "00" == mac_array[3] &&
      "00" == mac_array[4] &&
      "00" == mac_array[5]) ||
    ("ff" == mac_array[0] &&
      "ff" == mac_array[1] &&
      "ff" == mac_array[2] &&
      "ff" == mac_array[3] &&
      "ff" == mac_array[4] &&
      "ff" == mac_array[5]) ||
    ("FF" == mac_array[0] &&
      "FF" == mac_array[1] &&
      "FF" == mac_array[2] &&
      "FF" == mac_array[3] &&
      "FF" == mac_array[4] &&
      "FF" == mac_array[5])
  )
    return alert(bh_invalid_mac), !1;
  if (
    2 != mac_array[0].length ||
    2 != mac_array[1].length ||
    2 != mac_array[2].length ||
    2 != mac_array[3].length ||
    2 != mac_array[4].length ||
    2 != mac_array[5].length
  )
    return alert(bh_invalid_mac), !1;
  for (i = 0; i < mac_addr.length; i++)
    if (0 == isValidMac(mac_addr.charAt(i))) return alert(bh_invalid_mac), !1;
  return !0;
}
function setMAC(cf, this_mac) {
  var dflag;
  cf.MACAssign[0].checked || cf.MACAssign[1].checked
    ? ((dflag = !0),
      (cf.Spoofmac.value = this_mac),
      setDisabled(dflag, cf.Spoofmac))
    : (setDisabled((dflag = !1), cf.Spoofmac), (cf.Spoofmac.value = this_mac));
}
function isValidMac(digit) {
  var macVals = new Array(
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      ":"
    ),
    len = macVals.length,
    i = 0,
    ret = !1;
  for (i = 0; i < len && digit != macVals[i]; i++);
  return i < len && (ret = !0), ret;
}
function isValidChar(each_char) {
  if (each_char < 33 || each_char > 126) return !1;
}
function clearNoNum(obj) {
  (obj.value = obj.value.replace(/[^\d.]/g, "")),
    (obj.value = obj.value.replace(/^\./g, "")),
    (obj.value = obj.value.replace(/\.{2,}/g, ".")),
    (obj.value = obj.value
      .replace(".", "$#$")
      .replace(/\./g, "")
      .replace("$#$", ".")),
    (obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d)(\d).*$/, "$$1$$2.$$3"));
}
