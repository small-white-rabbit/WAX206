function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    head_text = document.createTextNode(bh_apply_connection);
  head_tag[0].appendChild(head_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_plz_waite_apply_connection);
  paragraph[0].appendChild(paragraph_text),
    showFirmVersion("none"),
    loadValue();
}
function loadValue() {
  1 == getTop(window).dsl_enable_flag
    ? "0" == select_basic && "7" == select_type
      ? "Germany" == country && "Deutsche Telekom" == isp
        ? "failed" == wget_result
          ? (this.location.href = "BRS_03A_B_vdsl_Gemany_pppoe_reenter.html")
          : "success" == wget_result &&
            (this.location.href = "BRS_security.html")
        : "Germany" == country && "1&1" == isp
        ? "failed" == wget_result
          ? (this.location.href = "BRS_03A_B_vdsl_Gemany11_pppoe_reenter.html")
          : "success" == wget_result &&
            (this.location.href = "BRS_security.html")
        : "failed" == wget_result
        ? (this.location.href = "BRS_03A_B_vdsl_pppoe_reenter.html")
        : "success" == wget_result && (this.location.href = "BRS_security.html")
      : "0" == select_basic && "5" == select_type
      ? "failed" == wget_result
        ? (this.location.href = "BRS_03A_B_pppoa_reenter.html")
        : "success" == wget_result && (this.location.href = "BRS_security.html")
      : "0" == select_basic && "0" == select_type
      ? "failed" == wget_result
        ? (this.location.href = "BRS_03A_B_pppoe_reenter.html")
        : "success" == wget_result && (this.location.href = "BRS_security.html")
      : "0" == select_basic && "1" == select_type
      ? "failed" == wget_result
        ? (this.location.href = "BRS_03A_C_pptp_reenter.html")
        : "success" == wget_result && (this.location.href = "BRS_security.html")
      : "0" == select_basic &&
        "4" == select_type &&
        ("failed" == wget_result
          ? (this.location.href = "BRS_03A_F_l2tp_reenter.html")
          : "success" == wget_result &&
            (this.location.href = "BRS_security.html"))
    : "0" == select_basic && "0" == select_type
    ? "failed" == wget_result
      ? (this.location.href = "BRS_03A_B_pppoe_reenter.html")
      : "success" == wget_result && (this.location.href = "BRS_security.html")
    : "0" == select_basic && "1" == select_type
    ? "failed" == wget_result
      ? (this.location.href = "BRS_03A_C_pptp_reenter.html")
      : "success" == wget_result && (this.location.href = "BRS_security.html")
    : "0" == select_basic &&
      "4" == select_type &&
      ("failed" == wget_result
        ? (this.location.href = "BRS_03A_F_l2tp_reenter.html")
        : "success" == wget_result &&
          (this.location.href = "BRS_security.html"));
}
addLoadEvent(initPage);
