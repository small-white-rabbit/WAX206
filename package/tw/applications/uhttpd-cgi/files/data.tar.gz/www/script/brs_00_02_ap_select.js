function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    connect_text = document.createTextNode(bh_ap_select_title);
  head_tag[0].appendChild(connect_text);
  var paragraph = document.getElementsByTagName("p"),
    paragraph_text = document.createTextNode(bh_select_tips);
  paragraph[0].appendChild(paragraph_text);
  var btn = document.getElementById("next");
  (btn.value = bh_next_mark),
    (btn.onclick = function () {
      return genieHelpChecking();
    }),
    showFirmVersion("none");
}
function genieHelpChecking() {
  var choices = document
    .getElementById("choices_div")
    .getElementsByTagName("input");
  document.getElementsByTagName("form")[0];
  if (choices[0].checked) location.href = "BRS_ap_detect_01_01.html";
  else if (choices[1].checked && choices[3].checked)
    location.href = "BRS_ap_detect_01_ap_02.html";
  else {
    if (!choices[1].checked || !choices[2].checked)
      return alert(bh_select_router_or_ap), !1;
    (location.href = "BRS_ap_detect_01_router_02.html"),
      (top.brs_pre_url = this.location.href);
  }
  return !0;
}
function goto_url(tag) {
  1 == tag && window.open('<% product_rae_img_path("Router") %>', "show_statistic"),
    2 == tag && window.open('<% product_rae_img_path("AP") %>', "show_statistic"),
    3 == tag && window.open("ap_detect_learn.html", "show_statistic");
}
addLoadEvent(initPage);
