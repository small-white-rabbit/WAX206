function initPage() {
  var head_tag = document.getElementsByTagName("h1"),
    connect_text = document.createTextNode(bh_internet_checking);
  head_tag[0].appendChild(connect_text),
    document
      .getElementById("waiting_img")
      .setAttribute("src", "image/wait30.gif"),
    loadValue();
}
function loadValue() {
  document.getElementsByTagName("form")[0];
  "failed" == ping_result
    ? (("WW" == getTop(window).netgear_region.toUpperCase() ||
        "" == getTop(window).netgear_region) &&
        "Russian" == getTop(window).gui_region) ||
      "RU" == getTop(window).netgear_region.toUpperCase()
      ? (this.location.href = "RU_welcome.htm")
      : "1" == getTop(window).dsl_enable_flag
      ? "failed" == ping_ip_result && "failed" == ping_gate_result
        ? (this.location.href = "BRS_log11_dhcp_ping_fail_ip_fail.html")
        : "failed" == ping_ip_result && "success" == ping_gate_result
        ? (this.location.href =
            "BRS_log11_dhcp_ping_fail_ip_fail_gate_sucess.html")
        : "success" == ping_ip_result && "failed" == ping_gate_result
        ? (this.location.href =
            "BRS_log11_dhcp_ping_fail_ip_sucess_gate_fail.html")
        : (this.location.href = "BRS_log11_dhcp_ping_fail.html")
      : (this.location.href = "BRS_05_networkIssue.html")
    : "success" == ping_result &&
      ("1" == getTop(window).dsl_enable_flag
        ? "failed" == ping_ip_result && "failed" == ping_gate_result
          ? (this.location.href = "BRS_log11_dhcp_ping_success_ip_fail.html")
          : "failed" == ping_ip_result && "success" == ping_gate_result
          ? (this.location.href =
              "BRS_log11_dhcp_ping_success_ip_fail_gate_success.html")
          : "success" == ping_ip_result && "failed" == ping_gate_result
          ? (this.location.href =
              "BRS_log11_dhcp_ping_success_ip_sucess_gate_fail.html")
          : (this.location.href = "BRS_log11_dhcp_ping_success.html")
        : (this.location.href = "BRS_security.html")),
    setTimeout("loadValue();", 1e3);
}
addLoadEvent(initPage);
