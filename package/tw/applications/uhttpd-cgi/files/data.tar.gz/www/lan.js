function dhcponoff() {
  var cf = document.forms[0];
  1 == cf.dhcp_server.checked
    ? ((cf.sysPoolStartingAddr4.disabled = !1),
      (cf.sysPoolFinishAddr4.disabled = !1),
      (1 == dhcp_lease_time_flag && (cf.lanLeaseTime.disabled = !1)),
      (cf.add.disabled = !1),
      (cf.edit[1].disabled = !1),
      (cf.delete.disabled = !1))
    : ((cf.sysPoolStartingAddr4.disabled = !0),
      (cf.sysPoolFinishAddr4.disabled = !0),
      (1 == dhcp_lease_time_flag && (cf.lanLeaseTime.disabled = !0)),
      (cf.add.disabled = !0),
      (cf.edit[1].disabled = !0),
      (cf.delete.disabled = !0));
}
function valid_add() {
  if (253 == array_num) return alert("$reservation_length_64"), !1;
  location.href = "reservation_add.htm";
}
function lanip_change(cf) {
  var addr_array = new Array();
  (cf.lan_ipaddr.value =
    cf.sysLANIPAddr1.value +
    "." +
    cf.sysLANIPAddr2.value +
    "." +
    cf.sysLANIPAddr3.value +
    "." +
    cf.sysLANIPAddr4.value),
    (addr_array = cf.lan_ipaddr.value.split(".")),
    (cf.sysPoolStartingAddr1.value = cf.sysPoolFinishAddr1.value =
      addr_array[0]),
    (cf.sysPoolStartingAddr2.value = cf.sysPoolFinishAddr2.value =
      addr_array[1]),
    (cf.sysPoolStartingAddr3.value = cf.sysPoolFinishAddr3.value =
      addr_array[2]);
}
function check_clientNumber(cf) {
  cf.lan_subnet.value =
    cf.sysLANSubnetMask1.value +
    "." +
    cf.sysLANSubnetMask2.value +
    "." +
    cf.sysLANSubnetMask3.value +
    "." +
    cf.sysLANSubnetMask4.value;
  var lan_mask = cf.lan_subnet.value;
  cf.lan_ipaddr.value =
    cf.sysLANIPAddr1.value +
    "." +
    cf.sysLANIPAddr2.value +
    "." +
    cf.sysLANIPAddr3.value +
    "." +
    cf.sysLANIPAddr4.value;
  var lan_ip = cf.lan_ipaddr.value,
    mask_array = lan_mask.split("."),
    lan_array = lan_ip.split("."),
    netmask = parseInt(mask_array[3], 10),
    client = 255 - netmask,
    localip = parseInt(lan_array[3], 10),
    net_start = (netmask & localip) + 1,
    net_end = net_start + client - 1;
  return localip == net_start - 1
    ? (cf.lan_ipaddr.focus(), !1)
    : localip >= net_end
    ? (cf.lan_ipaddr.focus(), !1)
    : parseInt(cf.sysPoolStartingAddr4.value, 10) < net_start ||
      parseInt(cf.sysPoolStartingAddr4.value, 10) >= net_end
    ? (cf.sysPoolStartingAddr4.focus(), !1)
    : !(
        parseInt(cf.sysPoolFinishAddr4.value, 10) < net_start ||
        parseInt(cf.sysPoolFinishAddr4.value, 10) >= net_end
      ) || (cf.sysPoolFinishAddr4.focus(), !1);
}
function checklan(form) {
  var cf = document.forms[0],
    change_count = 0;
  (form.change_network_flag.value = 0),
    (form.change_network2_flag.value = 0),
    (form.change_ip_flag.value = 0),
    (form.dmz_ip.value = dmz_ip),
    (form.bs_trustedip.value = bs_trustedip),
    (form.dhcp_start.value =
      form.sysPoolStartingAddr1.value +
      "." +
      form.sysPoolStartingAddr2.value +
      "." +
      form.sysPoolStartingAddr3.value +
      "." +
      form.sysPoolStartingAddr4.value),
    (form.dhcp_end.value =
      form.sysPoolFinishAddr1.value +
      "." +
      form.sysPoolFinishAddr2.value +
      "." +
      form.sysPoolFinishAddr3.value +
      "." +
      form.sysPoolFinishAddr4.value),
    (form.lan_ipaddr.value =
      form.sysLANIPAddr1.value +
      "." +
      form.sysLANIPAddr2.value +
      "." +
      form.sysLANIPAddr3.value +
      "." +
      form.sysLANIPAddr4.value),
    (form.lan_subnet.value =
      form.sysLANSubnetMask1.value +
      "." +
      form.sysLANSubnetMask2.value +
      "." +
      form.sysLANSubnetMask3.value +
      "." +
      form.sysLANSubnetMask4.value);
  var lan_array = form.lan_ipaddr.value.split(".");
  if (1 == dhcp_lease_time_flag) {
    var lease_time = form.lanLeaseTime.value;
    if (
      "" == lease_time ||
      !_isNumeric(lease_time) ||
      parseInt(lease_time) < 1 ||
      parseInt(lease_time) > 24
    )
      return alert("Incorrect value; correct values are from 1 to 24."), !1;
    cf.hid_lease_time.value = lease_time;
  }
  if (
    ((form.hid_array_num.value = array_num),
    0 == checkipaddr(form.lan_ipaddr.value) ||
      0 ==
        is_sub_or_broad(
          form.lan_ipaddr.value,
          form.lan_ipaddr.value,
          form.lan_subnet.value
        ))
  )
    return alert("$invalid_ip"), !1;
  if ("" != dmz_ip && "1" == dmz_enable) {
    var dmz_array = dmz_ip.split(".");
    if (isSameIp(form.lan_ipaddr.value, dmz_ip))
      return alert("$same_dmz_lan_ip"), !1;
  }
  if (0 == checksubnet(form.lan_subnet.value, 0))
    return alert("$invalid_mask"), !1;
  if (
    "1" == endis_wl_radio &&
    "1" == wds_endis_fun &&
    "0" == wds_repeater_basic
  );
  else if (1 == form.dhcp_server.checked) {
    if (0 == checkipaddr(form.dhcp_start.value))
      return alert("$invalid_dhcp_startip"), !1;
    if (
      ((form.dhcp_start.value = address_parseInt(form.dhcp_start.value)),
      0 == checkipaddr(form.dhcp_end.value))
    )
      return alert("$invalid_dhcp_endip"), !1;
    if (
      ((form.dhcp_end.value = address_parseInt(form.dhcp_end.value)),
      parseInt(form.sysPoolStartingAddr4.value, 10) >
        parseInt(form.sysPoolFinishAddr4.value, 10))
    )
      return alert("$invalid_dhcp_startendip"), !1;
    if (!check_clientNumber(form)) return alert("$invalid_dhcp_startendip"), !1;
    if (
      ((form.lan_ipaddr.value = address_parseInt(form.lan_ipaddr.value)),
      (form.lan_subnet.value = address_parseInt(form.lan_subnet.value)),
      0 ==
        isSameSubNet(
          form.lan_ipaddr.value,
          form.lan_subnet.value,
          form.dhcp_start.value,
          form.lan_subnet.value
        ))
    )
      return alert("$same_subnet_ip_dhcpstart"), !1;
    if (
      0 ==
      isSameSubNet(
        form.lan_ipaddr.value,
        form.lan_subnet.value,
        form.dhcp_end.value,
        form.lan_subnet.value
      )
    )
      return alert("$same_subnet_ip_dhcpend"), !1;
    var out_of_range = "";
    if (array_num > 0)
      for (i = 1; i <= array_num; i++) {
        var start_array = form.sysPoolStartingAddr4.value,
          end_array = form.sysPoolFinishAddr4.value,
          str = eval("resevArray" + i),
          each_info = str.split(" "),
          each4 = each_info[0].split(".");
        (parseInt(each4[3]) < parseInt(start_array) ||
          parseInt(each4[3]) > parseInt(end_array)) &&
          ("" == out_of_range ? (out_of_range = i) : (out_of_range += " " + i));
      }
    form.out_of_range.value = out_of_range;
  }
  1 == form.dhcp_server.checked
    ? (form.dhcp_mode.value = 1)
    : (form.dhcp_mode.value = 0);
  var conflicted_with_wanip = "$conflict_with_wanip";
  if ("0.0.0.0" != wan_ip) {
    if ("pppoe" == wan_type || "pptp" == wan_type || "mulpppoe1" == wan_type) {
      if (
        1 ==
        isSameSubNet(
          form.lan_ipaddr.value,
          form.lan_subnet.value,
          wan_ip,
          form.lan_subnet.value
        )
      )
        return alert("$conflict_with_wanip"), !1;
    } else {
      if (
        1 ==
        isSameSubNet(
          form.lan_ipaddr.value,
          form.lan_subnet.value,
          wan_ip,
          wan_mask
        )
      )
        return alert("$conflict_with_wanip"), !1;
      if (
        1 ==
        isSameSubNet(
          form.lan_ipaddr.value,
          form.lan_subnet.value,
          wan_ip,
          form.lan_subnet.value
        )
      )
        return alert("$conflict_with_wanip"), !1;
      if (1 == isSameSubNet(form.lan_ipaddr.value, wan_mask, wan_ip, wan_mask))
        return alert("$conflict_with_wanip"), !1;
    }
    if (1 == isSameIp(wan_ip, form.lan_ipaddr.value))
      return alert("$conflict_with_wanip"), !1;
  }
  if ("0.0.0.0" != bas_pptp_ip && "pptp" == wan_type) {
    if (
      1 ==
      isSameSubNet(
        form.lan_ipaddr.value,
        form.lan_subnet.value,
        bas_pptp_ip,
        form.lan_subnet.value
      )
    )
      return alert("$conflicted_with_wanip"), !1;
    if (1 == isSameIp(bas_pptp_ip, form.lan_ipaddr.value))
      return alert("$conflicted_with_wanip"), !1;
  }
  if (1 == getTop(window).have_multi_lan) {
    var otherLan = checkLanxIpConflict(
      form.lan_ipaddr.value,
      form.lan_subnet.value
    );
    if ("" != otherLan && "lan1" != otherLan)
      return (
        alert(
          "IP address is conflicted with " +
            tabs[otherLan].name +
            " IP subnet, please enter again."
        ),
        !1
      );
  }
  if (
    ((0 != isSameIp(old_lanmask, form.lan_subnet.value) &&
      0 != isSameIp(form.dhcp_start_old.value, form.dhcp_start.value) &&
      0 != isSameIp(form.dhcp_end_old.value, form.dhcp_end.value)) ||
      change_count++,
    0 == isSameIp(old_lanip, form.lan_ipaddr.value))
  ) {
    if (
      (change_count++,
      0 ==
        isSameSubNet(
          form.lan_ipaddr.value,
          "255.255.255.0",
          old_lanip,
          "255.255.255.0"
        ))
    ) {
      (new_lanip_array = form.lan_ipaddr.value.split(".")),
        (new_lansubnet_array = form.lan_subnet.value.split(".")),
        (addr1 = new_lanip_array[0] & new_lansubnet_array[0]),
        (addr2 = new_lanip_array[1] & new_lansubnet_array[1]),
        (addr3 = new_lanip_array[2] & new_lansubnet_array[2]),
        (addr4 = new_lanip_array[3] & new_lansubnet_array[3]);
      var route_dest = addr1 + "." + addr2 + "." + addr3 + "." + addr4,
        sub_leng = 3;
      (form.net_leng.value = 3),
        (form.network.value =
          new_lanip_array[0] +
          "." +
          new_lanip_array[1] +
          "." +
          new_lanip_array[2]);
      var new_reoute_dest_str =
        new_lanip_array[0] +
        "." +
        new_lanip_array[1] +
        "." +
        new_lanip_array[2] +
        ".";
      if ("" != dmz_ip) {
        var dmz_array = dmz_ip.split(".");
        form.dmz_ip.value =
          1 == sub_leng
            ? new_reoute_dest_str +
              dmz_array[1] +
              "." +
              dmz_array[2] +
              "." +
              dmz_array[3]
            : 2 == sub_leng
            ? new_reoute_dest_str + dmz_array[2] + "." + dmz_array[3]
            : new_reoute_dest_str + dmz_array[3];
      }
      if ("" != bs_trustedip) {
        var bs_trustedip_array = bs_trustedip.split(".");
        form.bs_trustedip.value =
          1 == sub_leng
            ? new_reoute_dest_str +
              bs_trustedip_array[1] +
              "." +
              bs_trustedip_array[2] +
              "." +
              bs_trustedip_array[3]
            : 2 == sub_leng
            ? new_reoute_dest_str +
              bs_trustedip_array[2] +
              "." +
              bs_trustedip_array[3]
            : new_reoute_dest_str + bs_trustedip_array[3];
      }
      form.change_network_flag.value = 1;
    }
    (form.change_ip_flag.value = 1),
      top_left_nolink(),
      (getTop(window).enable_action = 0);
  }
  if (0 == isSameIp(old_lanmask, form.lan_subnet.value)) {
    var oldNetwork = old_lanmask.split("."),
      nowNetwork = form.lan_subnet.value.split(".");
    (oldNumofNetwork = getNumOfNetwork(oldNetwork)),
      (newNumofNetwork = getNumOfNetwork(nowNetwork)),
      oldNumofNetwork < newNumofNetwork &&
        (form.change_network2_flag.value = 1);
  }
  return (
    form.dhcp_start_old.value == form.dhcp_start.value &&
    form.dhcp_end_old.value == form.dhcp_end.value
      ? (form.dhcp_pool_tag.value = 0)
      : (form.dhcp_pool_tag.value = 1),
    change_count > 0 &&
      alert(
        "$change_ip_manually1" +
          " After this new IP change, the corresponding configurations (DMZ, port forwarding/triggering, block service and block site trusted IP, Address Reservation Table) will be flushed too."
      ),
    cf.submit(),
    !0
  );
}
function getNumOfNetwork(netArray) {
  var getNum = 0;
  return (
    (getNum = 255 * netArray[0] * 255 * 255),
    (getNum += 255 * netArray[1] * 255),
    (getNum += 255 * netArray[2]),
    (getNum += netArray[3])
  );
}
var tabs = {
  lan1: { name: "LAN 1", link: "LAN_lan.htm" },
  lan2: { name: "LAN 2", link: "LAN_lanx.htm?lan=2" },
  lan3: { name: "LAN 3", link: "LAN_lanx.htm?lan=3" },
  lan4: { name: "LAN 4", link: "LAN_lanx.htm?lan=4" },
};
function show_tabs(cur_tab) {
  if ((console.log(cur_tab), 1 == getTop(window).have_multi_lan)) {
    var tabs_html = '<tr id="labels"><td colspan=2>',
      lan_count = 0;
    for (var k in tabs) {
      var tab = tabs[k];
      ++lan_count <= lan_num &&
        (tabs_html +=
          '<div class="label_unclick" id="' +
          k +
          '" onclick="click_tab(\'' +
          k +
          '\')">                        <div class="label_left"></div><div class="label_middle"><b><span>' +
          tab.name +
          '</span></b></div>                        <div class="label_right"></div></div>');
    }
    (tabs_html += "</td></tr>"),
      document.write(tabs_html),
      (document.getElementById(cur_tab).className =
        "label_click label_click-2");
  }
}
function click_tab(tab) {
  var tab_link = {};
  for (var k in tabs) tab_link[k] = tabs[k].link;
  var cur_tab = {};
  if (
    ((cur_tab[tab] = tab_link[tab]),
    delete tab_link[tab],
    document.getElementById(tab))
  ) {
    for (var k in ((document.getElementById(tab).className =
      "label_click label_click-2"),
    tab_link))
      document.getElementById(k) &&
        (document.getElementById(k).className = "label_unclick");
    location.href = cur_tab[tab];
  }
}
function checkLanxIpConflict(ip, mask) {
  for (var k in lanData) {
    if (isSameIp(ip, lanData[k].lan_ipaddr)) return k;
    if (isSameSubNet(ip, mask, lanData[k].lan_ipaddr, lanData[k].lan_mask))
      return k;
  }
  return "";
}
