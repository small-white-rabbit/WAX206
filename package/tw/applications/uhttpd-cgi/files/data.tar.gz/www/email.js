var error_email_addr = "$error_email_addr",
  user_name_error = "$user_name_error",
  user_name_null = "$user_name_null",
  password_error = "$password_error",
  password_null = "$password_null";
function setPort(cf) {
  cf.portnum_auto &&
    (cf.portnum_auto[0].checked
      ? (cf.email_port.disabled = !0)
      : (cf.email_port.disabled = !1));
}
function setGray(cf, click, hour_24_flag) {
  cf.email_notify.checked
    ? ((cf.block_site.disabled = !1),
      (cf.email_smtp.disabled = !1),
      (cf.email_addr.disabled = !1),
      cf.email_addr2 && (cf.email_addr2.disabled = !1),
      (cf.email_port.disabled = !1),
      cf.portnum_auto &&
        ((cf.portnum_auto[0].disabled = !1),
        (cf.portnum_auto[1].disabled = !1)),
      (cf.cfAlert_Select.disabled = !1),
      (cf.smtp_auth.disabled = !1),
      cf.sec_connection && (cf.sec_connection.disabled = !1),
      1 == click && (cf.block_site.checked = 0),
      (cf.cloud_noti.disabled = !1),
      (cf.usb_backup_noti.disabled = !1))
    : ((cf.block_site.disabled = !0),
      (cf.email_smtp.disabled = !0),
      (cf.email_addr.disabled = !0),
      cf.email_addr2 && (cf.email_addr2.disabled = !0),
      (cf.email_port.disabled = !0),
      cf.portnum_auto &&
        ((cf.portnum_auto[0].disabled = !0),
        (cf.portnum_auto[1].disabled = !0)),
      (cf.cfAlert_Select.disabled = !0),
      (cf.smtp_auth.disabled = !0),
      (cf.cfAlert_Day.disabled = !0),
      (cf.cfAlert_Hour.disabled = !0),
      0 == hour_24_flag &&
        ((cf.cfAlert_am[0].disabled = !0), (cf.cfAlert_am[1].disabled = !0)),
      cf.sec_connection && (cf.sec_connection.disabled = !0),
      (cf.cloud_noti.disabled = !0),
      (cf.usb_backup_noti.disabled = !0)),
    setAuth(cf);
}
function setAuth(cf) {
  cf.email_notify.checked && 1 == cf.smtp_auth.checked
    ? ((cf.auth_user.disabled = !1), (cf.auth_pwd.disabled = !1))
    : ((cf.auth_user.disabled = !0), (cf.auth_pwd.disabled = !0));
}
function disable_am(disable_flag, cf) {
  (cf.cfAlert_am[0].disabled = disable_flag),
    (cf.cfAlert_am[1].disabled = disable_flag);
}
function OnAlertChange(cf, hour_24_flag) {
  var index = cf.cfAlert_Select.selectedIndex;
  0 == index || 1 == index || 4 == index
    ? ((cf.cfAlert_Day.selectedIndex = 0),
      (cf.cfAlert_Hour.selectedIndex = 0),
      (cf.cfAlert_Day.disabled = !0),
      (cf.cfAlert_Hour.disabled = !0),
      (AlertTimeDisabled = !0),
      (AlertHourDisabled = !0),
      0 == hour_24_flag && disable_am(!0, cf))
    : 2 == index
    ? ((cf.cfAlert_Day.selectedIndex = 0),
      (cf.cfAlert_Day.disabled = !0),
      (cf.cfAlert_Hour.disabled = !1),
      (AlertTimeDisabled = !0),
      (AlertHourDisabled = !1),
      0 == hour_24_flag && disable_am(!1, cf))
    : 3 == index &&
      ((cf.cfAlert_Day.disabled = !1),
      (cf.cfAlert_Hour.disabled = !1),
      (AlertTimeDisabled = !1),
      (AlertHourDisabled = !1),
      0 == hour_24_flag && disable_am(!1, cf)),
    rewrite_list_value(cf, "cfAlert_Select");
}
function check_email(cf, hour_24_flag) {
  if (cf.email_notify.checked) {
    for (
      cf.email_notify_enabled.value = "1", i = 0;
      i < cf.email_smtp.value.length;
      i++
    )
      if (0 == isValidChar(cf.email_smtp.value.charCodeAt(i)))
        return alert("$error_email_smtp"), cf.email_smtp.focus(), !1;
    if ("" == cf.email_smtp.value)
      return alert("$error_email_smtp"), cf.email_smtp.focus(), !1;
    for (i = 0; i < cf.email_addr.value.length; i++)
      if (0 == isValidChar(cf.email_addr.value.charCodeAt(i)))
        return alert("$error_email_addr"), cf.email_addr.focus(), !1;
    if (cf.email_addr2 && "" != cf.email_addr2.value) {
      for (i = 0; i < cf.email_addr2.value.length; i++)
        if (0 == isValidChar(cf.email_addr2.value.charCodeAt(i)))
          return alert("$error_email_addr"), cf.email_addr2.focus(), !1;
      if (
        (-1 == cf.email_addr2.value.indexOf("@", 0) ||
          -1 == cf.email_addr2.value.indexOf(".", 0)) &&
        "" != cf.email_addr2.value
      )
        return alert("$error_email_addr"), cf.email_addr2.focus(), !1;
    }
    if ("" == cf.email_addr.value)
      return alert("please fill Primary E-mail Address!"), !1;
    if (
      -1 == cf.email_addr.value.indexOf("@", 0) ||
      -1 == cf.email_addr.value.indexOf(".", 0)
    )
      return alert("$error_email_addr"), cf.email_addr.focus(), !1;
    cf.portnum_auto &&
      (1 == cf.portnum_auto[0].checked
        ? (cf.email_port_sta.value = 1)
        : ((cf.email_port_sta.value = 0),
          (cf.email_port_num.value = parseInt(cf.email_port.value, 10))));
    var emailPort = parseInt(cf.email_port.value, 10);
    if (
      ((cf.portnum_auto && 1 == cf.portnum_auto[1].checked) ||
        !cf.portnum_auto) &&
      (isNaN(emailPort) || emailPort <= 0 || emailPort >= 65535)
    )
      return alert("$invalid_email_port"), !1;
    if (
      (cf.email_port &&
        (cf.email_port.value = parseInt(cf.email_port.value, 10)),
      1 == cf.smtp_auth.checked)
    ) {
      for (i = 0; i < cf.auth_user.value.length; i++)
        if (0 == isValidChar(cf.auth_user.value.charCodeAt(i)))
          return alert("$user_name_error"), !1;
      for (i = 0; i < cf.auth_pwd.value.length; i++)
        if (0 == isValidChar(cf.auth_pwd.value.charCodeAt(i)))
          return alert("$password_error"), !1;
      if ("" == cf.auth_user.value) return alert("$user_name_null"), !1;
      if ("" == cf.auth_pwd.value) return alert("$password_null"), !1;
      cf.email_endis_auth.value = 1;
    } else cf.email_endis_auth.value = 0;
  } else
    (cf.email_notify_enabled.value = "0"),
      1 == cf.smtp_auth.checked
        ? (cf.email_endis_auth.value = 1)
        : (cf.email_endis_auth.value = 0);
  cf.send_email_noti.checked
    ? (cf.send_email_noti_hid.value = "1")
    : (cf.send_email_noti_hid.value = "0"),
    cf.block_site.checked
      ? (cf.send_alert_immediately.value = "1")
      : (cf.send_alert_immediately.value = "0");
  var schedule_time = parseInt(cf.cfAlert_Hour.value);
  return (
    2 == cf.cfAlert_Select.selectedIndex &&
      (0 == hour_24_flag && cf.cfAlert_am[1].checked && (schedule_time += 12),
      (cf.schedule_hour.value = schedule_time)),
    3 == cf.cfAlert_Select.selectedIndex &&
      (0 == hour_24_flag && cf.cfAlert_am[1].checked && (schedule_time += 12),
      (cf.schedule_hour.value = schedule_time)),
    (cf.email_addr_hid1.value = cf.email_addr.value),
    cf.email_addr2 && (cf.email_addr_hid2.value = cf.email_addr2.value),
    (cf.email_smtp_hid.value = cf.email_smtp.value),
    (cf.auth_user_hid.value = cf.auth_user.value),
    (cf.auth_pwd_hid.value = cf.auth_pwd.value),
    (cf.cfAlert_Select_hid.value = convert_value_to_original(
      cf,
      "cfAlert_Select"
    )),
    (cf.cfAlert_Day_hid.value = cf.cfAlert_Day.value),
    cf.portnum_auto &&
      1 == cf.portnum_auto[0].checked &&
      (parent.smtp_auto_detect = 1),
    1 == cf.cloud_noti.checked
      ? (cf.cloud_email_noti_hid.value = "1")
      : (cf.cloud_email_noti_hid.value = "0"),
    1 == cf.usb_backup_noti.checked
      ? (cf.usb_backup_email_noti_hid.value = "1")
      : (cf.usb_backup_email_noti_hid.value = "0"),
    cf.submit(),
    !0
  );
}
function change_email_password(obj) {
  "password" == obj.type &&
    ("Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : ((obj.outerHTML =
          '<input type="text" class="input_width input1" name="auth_pwd" id="auth_pwd" size="24" maxlength="50" onFocus="change_email_password(this);" onKeyPress="return getkey(\'ssid\', event)">'),
        document.forms[0].auth_pwd.select())),
    (document.forms[0].hidden_pwd_change.value = "1");
}
