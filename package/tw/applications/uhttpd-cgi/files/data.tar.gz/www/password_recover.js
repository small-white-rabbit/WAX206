function Base64() {
  (_keyStr =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="),
    (this.encode = function (input) {
      var chr1,
        chr2,
        chr3,
        enc1,
        enc2,
        enc3,
        enc4,
        output = "",
        i = 0;
      for (input = _utf8_encode(input); i < input.length; )
        (enc1 = (chr1 = input.charCodeAt(i++)) >> 2),
          (enc2 = ((3 & chr1) << 4) | ((chr2 = input.charCodeAt(i++)) >> 4)),
          (enc3 = ((15 & chr2) << 2) | ((chr3 = input.charCodeAt(i++)) >> 6)),
          (enc4 = 63 & chr3),
          isNaN(chr2) ? (enc3 = enc4 = 64) : isNaN(chr3) && (enc4 = 64),
          (output =
            output +
            _keyStr.charAt(enc1) +
            _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) +
            _keyStr.charAt(enc4));
      return output;
    }),
    (this.decode = function (input) {
      var chr1,
        chr2,
        chr3,
        enc2,
        enc3,
        enc4,
        output = "",
        i = 0;
      for (input = input.replace(/[^A-Za-z0-9\+\/\=]/g, ""); i < input.length; )
        (chr1 =
          (_keyStr.indexOf(input.charAt(i++)) << 2) |
          ((enc2 = _keyStr.indexOf(input.charAt(i++))) >> 4)),
          (chr2 =
            ((15 & enc2) << 4) |
            ((enc3 = _keyStr.indexOf(input.charAt(i++))) >> 2)),
          (chr3 =
            ((3 & enc3) << 6) | (enc4 = _keyStr.indexOf(input.charAt(i++)))),
          (output += String.fromCharCode(chr1)),
          64 != enc3 && (output += String.fromCharCode(chr2)),
          64 != enc4 && (output += String.fromCharCode(chr3));
      return (output = _utf8_decode(output));
    }),
    (_utf8_encode = function (string) {
      string = string.replace(/\r\n/g, "\n");
      for (var utftext = "", n = 0; n < string.length; n++) {
        var c = string.charCodeAt(n);
        c < 128
          ? (utftext += String.fromCharCode(c))
          : c > 127 && c < 2048
          ? ((utftext += String.fromCharCode((c >> 6) | 192)),
            (utftext += String.fromCharCode((63 & c) | 128)))
          : ((utftext += String.fromCharCode((c >> 12) | 224)),
            (utftext += String.fromCharCode(((c >> 6) & 63) | 128)),
            (utftext += String.fromCharCode((63 & c) | 128)));
      }
      return utftext;
    }),
    (_utf8_decode = function (utftext) {
      for (var string = "", i = 0, c = (c1 = c2 = 0); i < utftext.length; )
        (c = utftext.charCodeAt(i)) < 128
          ? ((string += String.fromCharCode(c)), i++)
          : c > 191 && c < 224
          ? ((c2 = utftext.charCodeAt(i + 1)),
            (string += String.fromCharCode(((31 & c) << 6) | (63 & c2))),
            (i += 2))
          : ((c2 = utftext.charCodeAt(i + 1)),
            (c3 = utftext.charCodeAt(i + 2)),
            (string += String.fromCharCode(
              ((15 & c) << 12) | ((63 & c2) << 6) | (63 & c3)
            )),
            (i += 3));
      return string;
    });
}
function display_account_info() {
  var result1,
    result2,
    base = new Base64(),
    de_val1 = base.decode(str1),
    de_val2 = base.decode(str2);
  (result1 = convert_string(de_val1)),
    (result2 = convert_string(de_val2)),
    (document.getElementById("username").innerHTML = result1),
    (document.getElementById("password").innerHTML = result2);
}
function convert_string(value) {
  var len1,
    len2,
    a,
    b,
    c,
    m0,
    m1,
    m2,
    str = "";
  if ((len1 = value.length) < (len2 = numbers.length))
    for (var i = 0; i < len1; i++)
      (m0 = (a = value.charCodeAt(i)) - 32 - (b = numbers.charCodeAt(i))) >
        31 &&
        m0 < 127 &&
        (c = m0),
        (m1 = a - 32 + 95 - b) > 31 && m1 < 127 && (c = m1),
        (m2 = a - 32 + 95 * 2 - b) > 31 && m2 < 127 && (c = m2),
        (str += String.fromCharCode(c));
  else {
    for (i = 0; i < len2; i++)
      (m0 = (a = value.charCodeAt(i)) - 32 - (b = numbers.charCodeAt(i))) >
        31 &&
        m0 < 127 &&
        (c = m0),
        (m1 = a - 32 + 95 - b) > 31 && m1 < 127 && (c = m1),
        (m2 = a - 32 + 95 * 2 - b) > 31 && m2 < 127 && (c = m2),
        (str += String.fromCharCode(c));
    for (i = len2; i < len1; i++) str += value.charAt(i);
  }
  return str;
}
