var hour_schedule_12 = [
    "12:00 $midnight_mark.",
    "12:30 a.m.",
    "01:00 a.m.",
    "01:30 a.m.",
    "02:00 a.m.",
    "02:30 a.m.",
    "03:00 a.m.",
    "03:30 a.m.",
    "04:00 a.m.",
    "04:30 a.m.",
    "05:00 a.m.",
    "05:30 a.m.",
    "06:00 a.m.",
    "06:30 a.m.",
    "07:00 a.m.",
    "07:30 a.m.",
    "08:00 a.m.",
    "08:30 a.m.",
    "09:00 a.m.",
    "09:30 a.m.",
    "10:00 a.m.",
    "10:30 a.m.",
    "11:00 a.m.",
    "11:30 a.m.",
    "12:00 $noon_mark",
    "12:30 p.m.",
    "01:00 p.m.",
    "01:30 p.m.",
    "02:00 p.m.",
    "02:30 p.m.",
    "03:00 p.m.",
    "03:30 p.m.",
    "04:00 p.m.",
    "04:30 p.m.",
    "05:00 p.m.",
    "05:30 p.m.",
    "06:00 p.m.",
    "06:30 p.m.",
    "07:00 p.m.",
    "07:30 p.m.",
    "08:00 p.m.",
    "08:30 p.m.",
    "09:00 p.m.",
    "09:30 p.m.",
    "10:00 p.m.",
    "10:30 p.m.",
    "11:00 p.m.",
    "11:30 p.m.",
  ],
  hour_schedule_24 = [
    "00:00",
    "00:30",
    "01:00",
    "01:30",
    "02:00",
    "02:30",
    "03:00",
    "03:30",
    "04:00",
    "04:30",
    "05:00",
    "05:30",
    "06:00",
    "06:30",
    "07:00",
    "07:30",
    "08:00",
    "08:30",
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "14:00",
    "14:30",
    "15:00",
    "15:30",
    "16:00",
    "16:30",
    "17:00",
    "17:30",
    "18:00",
    "18:30",
    "19:00",
    "19:30",
    "20:00",
    "20:30",
    "21:00",
    "21:30",
    "22:00",
    "22:30",
    "23:00",
    "23:30",
  ],
  week_days = ["Sun.", "Mon.", "Tues.", "Wed.", "Thu.", "Fri.", "Sat."];
function check_schedule_onoff() {
  var disable_flag,
    cf = document.forms[0],
    i = 0;
  if (
    (0 == cf.enable_ap.checked || "0" == ntp_updated
      ? ((disable_flag = !0), (getObj("schedule_bgn_enable").color = "gray"))
      : ((disable_flag = !1), (getObj("schedule_bgn_enable").color = "black")),
    (cf.wifi_onoff.disabled = disable_flag),
    (cf["Add a new period"][0].disabled = disable_flag),
    (cf["Edit"][0].disabled = disable_flag),
    (cf["Delete"][0].disabled = disable_flag),
    wireless_schedule_num > 1)
  )
    for (i = 0; i < wireless_schedule_num; i++)
      cf.ruleSelect_2g[i].disabled = disable_flag;
  else wireless_schedule_num > 0 && (cf.ruleSelect_2g.disabled = disable_flag);
  if (
    (0 == cf.enable_ap_an.checked || "0" == ntp_updated
      ? ((disable_flag = !0), (getObj("schedule_an_enable").color = "gray"))
      : ((disable_flag = !1), (getObj("schedule_an_enable").color = "black")),
    (cf.wifi_onoff_an.disabled = disable_flag),
    (cf["Add a new period"][1].disabled = disable_flag),
    (cf["Edit"][1].disabled = disable_flag),
    (cf["Delete"][1].disabled = disable_flag),
    wireless_schedule_num_a > 1)
  )
    for (i = 0; i < wireless_schedule_num_a; i++)
      cf.ruleSelect_5g[i].disabled = disable_flag;
  else
    wireless_schedule_num_a > 0 && (cf.ruleSelect_5g.disabled = disable_flag);
  if (
    (0 == cf.enable_ap_ad.checked || "0" == ntp_updated
      ? ((disable_flag = !0), (getObj("schedule_ad_enable").color = "gray"))
      : ((disable_flag = !1), (getObj("schedule_ad_enable").color = "black")),
    (cf.wifi_onoff_ad.disabled = disable_flag),
    (cf["Add a new period"][2].disabled = disable_flag),
    (cf["Edit"][2].disabled = disable_flag),
    (cf["Delete"][2].disabled = disable_flag),
    wireless_schedule_num_ad > 1)
  )
    for (i = 0; i < wireless_schedule_num_ad; i++)
      cf.ruleSelect_60g[i].disabled = disable_flag;
  else
    wireless_schedule_num_ad > 0 && (cf.ruleSelect_60g.disabled = disable_flag);
}
function enable_schedule_button() {
  var cf = document.forms[0];
  cf.enable_ap.checked && "1" == ntp_updated
    ? ((cf.wifi_onoff.disabled = !1),
      (cf["Add a new period"][0].disabled = !1),
      (cf["Edit"][0].disabled = !1),
      (cf["Delete"][0].disabled = !1))
    : ((cf.wifi_onoff.disabled = !0),
      (cf["Add a new period"][0].disabled = !0),
      (cf["Edit"][0].disabled = !0),
      (cf["Delete"][0].disabled = !0)),
    cf.enable_ap_an.checked && "1" == ntp_updated
      ? ((cf.wifi_onoff_an.disabled = !1),
        (cf["Add a new period"][1].disabled = !1),
        (cf["Edit"][1].disabled = !1),
        (cf["Delete"][1].disabled = !1))
      : ((cf.wifi_onoff_an.disabled = !0),
        (cf["Add a new period"][1].disabled = !0),
        (cf["Edit"][1].disabled = !0),
        (cf["Delete"][1].disabled = !0)),
    cf.enable_ap_ad.checked && "1" == ntp_updated
      ? ((cf.wifi_onoff_ad.disabled = !1),
        (cf["Add a new period"][2].disabled = !1),
        (cf["Edit"][2].disabled = !1),
        (cf["Delete"][2].disabled = !1))
      : ((cf.wifi_onoff_ad.disabled = !0),
        (cf["Add a new period"][2].disabled = !0),
        (cf["Edit"][2].disabled = !0),
        (cf["Delete"][2].disabled = !0));
}
function check_wireless_schedule(chan_type, btn_flag) {
  var cf = document.forms[0],
    edit_type,
    del_submit_flag,
    anticsrfToken,
    schedule_num,
    array_name;
  if (
    ("bgn" == chan_type
      ? ((array_name = "ruleSelect_2g"),
        (schedule_num = wireless_schedule_num),
        (parent.wifi_schedule_select = "bgn"),
        (edit_type = "edit_bgn"),
        (del_submit_flag = "wireless_schedule_delete"),
        (anticsrfToken = wireless_schedule_delete_token))
      : "an" == chan_type
      ? ((array_name = "ruleSelect_5g"),
        (schedule_num = wireless_schedule_num_a),
        (parent.wifi_schedule_select = "an"),
        (edit_type = "edit_an"),
        (del_submit_flag = "wireless_schedule_delete_an"),
        (anticsrfToken = wireless_schedule_delete_an_token))
      : "tri" == chan_type
      ? ((array_name = "ruleSelect_5g2"),
        (schedule_num = wireless_schedule_num_tri),
        (parent.wifi_schedule_select = "tri"),
        (edit_type = "edit_tri"),
        (del_submit_flag = "wireless_schedule_delete_tri"),
        (anticsrfToken = wireless_schedule_delete_tri_token))
      : "ad" == chan_type &&
        ((array_name = "ruleSelect_60g"),
        (schedule_num = wireless_schedule_num_ad),
        (parent.wifi_schedule_select = "ad"),
        (edit_type = "edit_ad"),
        (del_submit_flag = "wireless_schedule_delete_ad"),
        (anticsrfToken = wireless_schedule_delete_ad_token)),
    "add" == btn_flag)
  ) {
    if (schedule_num >= 21) return alert("$adva_max_rules"), !1;
    location.href = "WLG_schedule_add.htm";
  } else if ("edit" == btn_flag) {
    if (!(schedule_num > 0)) return (location.href = "edit_fail.htm"), !1;
    var i = 0;
    if (((cf.wladv_schedule_edit_num.value = ""), schedule_num > 1))
      for (i = 0; i < schedule_num; i++)
        eval("cf." + array_name + "[" + i + "]").checked &&
          (cf.wladv_schedule_edit_num.value =
            parseInt(eval("cf." + array_name + "[" + i + "]").value, 10) + 1);
    else
      eval("cf." + array_name).checked &&
        (cf.wladv_schedule_edit_num.value =
          parseInt(eval("cf." + array_name).value, 10) + 1);
    if ("" == cf.wladv_schedule_edit_num.value)
      return (location.href = "edit_fail.htm"), !1;
    (cf.wladv_schedule_type.value = edit_type),
      (cf.submit_flag.value = "wireless_schedule_select_to_edit"),
      (cf.anticsrf.value = wireless_schedule_select_to_edit_token),
      (cf.action = "/apply.cgi?/WLG_schedule_edit.htm timestamp=" + ts),
      cf.submit();
  } else if ("delete" == btn_flag) {
    if (!(schedule_num > 0)) return (location.href = "del_fail.htm"), !1;
    var i = 0;
    if (((cf.wladv_schedule_delete_num.value = ""), schedule_num > 1))
      for (i = 0; i < schedule_num; i++)
        eval("cf." + array_name + "[" + i + "]").checked &&
          (cf.wladv_schedule_delete_num.value =
            parseInt(eval("cf." + array_name + "[" + i + "]").value, 10) + 1);
    else
      eval("cf." + array_name).checked &&
        (cf.wladv_schedule_delete_num.value =
          parseInt(eval("cf." + array_name).value, 10) + 1);
    if ("" == cf.wladv_schedule_delete_num.value)
      return (location.href = "del_fail.htm"), !1;
    (cf.submit_flag.value = del_submit_flag),
      (cf.anticsrf.value = anticsrfToken),
      (cf.action = "/apply.cgi?/WLG_adv.htm timestamp=" + ts),
      cf.submit();
  }
}
function schedule_check_pattern() {
  var onoff,
    cf = document.forms[0];
  cf.selday[0].checked ? (onoff = !0) : cf.selday[1].checked && (onoff = !1),
    setDisabled(onoff, cf.sun, cf.mon, cf.tue, cf.wed, cf.thu, cf.fri, cf.sat);
}
function check_schedule_legality(modify_flag, item_value) {
  var array_name, array_num, i;
  if (
    ("bgn" == wifi_schedule_select
      ? ((array_name = "wireless_schedule_array"),
        (array_num = wireless_schedule_num))
      : "an" == wifi_schedule_select
      ? ((array_name = "wireless_schedule_array_a"),
        (array_num = wireless_schedule_num_a))
      : "ad" == wifi_schedule_select &&
        ((array_name = "wireless_schedule_array_ad"),
        (array_num = wireless_schedule_num_ad)),
    array_num > 0)
  )
    for (i = 1; i <= array_num; i++) {
      var array_value = eval(array_name + i);
      if (array_value == item_value) {
        if ("add" == modify_flag) return alert("$service_rule_dup"), !1;
        if ("edit" == modify_flag && i != edit_num)
          return alert("$service_rule_dup"), !1;
      }
    }
}
function wireless_schedule_add(modify_flag) {
  var i,
    cf = document.forms[0],
    schedule_all = "",
    schedule_days = "",
    j = 0;
  if (cf.selday[0].checked) schedule_days = "Daily";
  else if (cf.selday[1].checked) {
    var weekday, selectday;
    for (i = 0; i < 7; i++)
      0 == i
        ? (weekday = cf.sun)
        : 1 == i
        ? (weekday = cf.mon)
        : 2 == i
        ? (weekday = cf.tue)
        : 3 == i
        ? (weekday = cf.wed)
        : 4 == i
        ? (weekday = cf.thu)
        : 5 == i
        ? (weekday = cf.fri)
        : 6 == i && (weekday = cf.sat),
        weekday.checked &&
          (schedule_days = schedule_days + weekday.value + ",");
    for (
      schedule_days.length > 0 &&
        (schedule_days = schedule_days.substring(0, schedule_days.length - 1)),
        i = 0;
      i < 7;
      i++
    )
      0 == i
        ? (selectday = cf.sun)
        : 1 == i
        ? (selectday = cf.mon)
        : 2 == i
        ? (selectday = cf.tue)
        : 3 == i
        ? (selectday = cf.wed)
        : 4 == i
        ? (selectday = cf.thu)
        : 5 == i
        ? (selectday = cf.fri)
        : 6 == i && (selectday = cf.sat),
        selectday.checked && (j += 1);
    if (j <= 0) return alert("$invalid_noday"), !1;
  }
  return cf.start_time.value == cf.end_time.value
    ? (alert("$same_time"), !1)
    : ((schedule_all =
        cf.start_time.value + "-" + cf.end_time.value + "-" + schedule_days),
      0 !=
        check_schedule_legality(
          modify_flag,
          (schedule_all = remove_space(schedule_all))
        ) && ((cf.schedule_info.value = schedule_all), cf.submit(), !0));
}
