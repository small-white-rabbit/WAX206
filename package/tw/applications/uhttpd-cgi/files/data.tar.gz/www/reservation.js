function check_reservation_add(cf, flag) {
  var rsvipaddr = new Array();
  if (253 == array_num && "add" == flag)
    return alert("$reservation_length_64"), !1;
  if (
    ((rsvipaddr =
      cf.rsv_ip1.value +
      "." +
      cf.rsv_ip2.value +
      "." +
      cf.rsv_ip3.value +
      "." +
      cf.rsv_ip4.value),
    "" == cf.dv_name.value)
  )
    return alert("$device_name_null"), !1;
  if (cf.dv_name.value.length > 15) return alert("$devname_warning"), !1;
  for (i = 0; i < cf.dv_name.value.length; i++)
    if (0 == isValidChar_space(cf.dv_name.value.charCodeAt(i)))
      return alert("$device_name_error"), !1;
  if (0 == checkipaddr(rsvipaddr)) return alert("$invalid_ip"), !1;
  if (rsvipaddr == lanip) return alert("$invalid_ip"), !1;
  if (12 == cf.rsv_mac.value.length && -1 == cf.rsv_mac.value.indexOf(":")) {
    var mac = cf.rsv_mac.value;
    cf.rsv_mac.value =
      mac.substr(0, 2) +
      ":" +
      mac.substr(2, 2) +
      ":" +
      mac.substr(4, 2) +
      ":" +
      mac.substr(6, 2) +
      ":" +
      mac.substr(8, 2) +
      ":" +
      mac.substr(10, 2);
  } else if (6 == cf.rsv_mac.value.split("-").length) {
    var tmp_mac = cf.rsv_mac.value.replace(/-/g, ":");
    cf.rsv_mac.value = tmp_mac;
  }
  if (0 == maccheck(cf.rsv_mac.value)) return !1;
  if (0 == isSameSubNet(rsvipaddr, lanmask, lanip, lanmask))
    return alert("$diff_lan_this_subnet"), !1;
  for (
    cf.duplicated_reservation.value = "", cf.duplicated_num.value = 0, i = 1;
    i <= array_num;
    i++
  ) {
    var str = eval("resevArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if ("edit" == flag) {
      if (
        select_editnum != i &&
        (rsvipaddr == each_info[0] ||
          cf.rsv_mac.value.toLowerCase() == each_info[1].toLowerCase())
      )
        if (0 == cf.duplicated_num.value) {
          if (!confirm("$reservation_dup")) return !1;
          (cf.duplicated_num.value = 1),
            (cf.duplicated_reservation.value = i.toString());
        } else
          cf.duplicated_num.value++,
            (cf.duplicated_reservation.value =
              cf.duplicated_reservation.value + " " + i.toString());
    } else if (
      rsvipaddr == each_info[0] ||
      cf.rsv_mac.value.toLowerCase() == each_info[1].toLowerCase()
    )
      if (0 == cf.duplicated_num.value) {
        if (!confirm("$reservation_dup")) return !1;
        (cf.duplicated_num.value = 1),
          (cf.duplicated_reservation.value = i.toString());
      } else
        cf.duplicated_num.value++,
          (cf.duplicated_reservation.value =
            cf.duplicated_reservation.value + " " + i.toString());
  }
  return (
    (cf.reservation_ipaddr.value = address_parseInt(rsvipaddr)),
    "undefined" != typeof apply_flag && (apply_flag = 1),
    cf.submit(),
    !0
  );
}
function check_reservation_del(cf) {
  if (0 == array_num) return alert("$port_del"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num) {
    if (1 == cf.ruleSelect.checked) {
      if (1 == is_ipmac) return alert("$ipmac_del_warning"), !1;
      count_select++, (select_num = 1);
    }
  } else
    for (i = 0; i < array_num; i++)
      1 == cf.ruleSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_del"), !1)
    : ((cf.select_del.value = select_num),
      (cf.submit_flag.value = "reservation_del"),
      (cf.anticsrf.value = reservation_del_token),
      cf.submit(),
      !0);
}
function check_reservation_editnum(cf) {
  if (0 == array_num) return alert("$port_edit"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.ruleSelect.checked &&
      (count_select++,
      (select_num = 1),
      1 == is_ipmac && alert("$ipmac_edit_warning"));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.ruleSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_edit"), !1)
    : ((cf.select_edit.value = select_num),
      (cf.submit_flag.value = "reservation_editnum"),
      (cf.anticsrf.value = reservation_editnum_token),
      (cf.action = "/apply.cgi?/reservation_edit.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function data_select(num) {
  var cf = document.forms[0];
  if (
    ("<unknown>" == show_name_array[num] ||
    "&lt;unknown&gt;" == show_name_array[num]
      ? (cf.dv_name.value = "<$unknown_mark>")
      : (cf.dv_name.value = show_name_array[num]
          .replace(/&#92;/g, "\\")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&#40;/g, "(")
          .replace(/&#41;/g, ")")
          .replace(/&#34;/g, '"')
          .replace(/&#39;/g, "'")
          .replace(/&#35;/g, "#")
          .replace(/&#38;/g, "&")),
    cf.dv_name.value.length > "15" &&
      (cf.dv_name.value = cf.dv_name.value.substr(0, 15)),
    "<unknown>" == show_mac_array[num] ||
    "&lt;unknown&gt;" == show_mac_array[num]
      ? (cf.rsv_mac.value = "")
      : (cf.rsv_mac.value = show_mac_array[num]),
    "----" != show_ip_array[num])
  ) {
    var ip_array = show_ip_array[num].split(".");
    (cf.rsv_ip1.value = ip_array[0]),
      (cf.rsv_ip2.value = ip_array[1]),
      (cf.rsv_ip3.value = ip_array[2]),
      (cf.rsv_ip4.value = ip_array[3]);
  }
}
