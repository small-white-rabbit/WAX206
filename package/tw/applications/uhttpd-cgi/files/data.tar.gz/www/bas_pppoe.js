function show_hidden_help_top_button(help_flag) {
  if (!isIE_or_Opera() || IE_version() >= 8) Not_IE_show_hidden_help(help_flag);
  else {
    var frame_height = getTop(window)
      .document.getElementById("formframe_div")
      .style.height.replace(/px/, "");
    help_flag % 2 == 0
      ? ((document.getElementById("main").style.height = frame_height - 285),
        (document.getElementById("help").style.display = ""),
        (document.getElementById("help_switch").className = "open_help"))
      : ((document.getElementById("help").style.display = "none"),
        (document.getElementById("help_switch").className = "close_help"),
        (document.getElementById("main").style.height = frame_height - 165));
  }
}
function myip_update() {
  var cf = document.forms[0];
  cf.myip_1.value.length > 0 &&
  cf.myip_2.value.length > 0 &&
  cf.myip_3.value.length > 0 &&
  cf.myip_4.value.length > 0
    ? setDisabled(!1, cf.mymask_1, cf.mymask_2, cf.mymask_3, cf.mymask_4)
    : setDisabled(!0, cf.mymask_1, cf.mymask_2, cf.mymask_3, cf.mymask_4);
}
function setIP(cf, page) {
  var dflag = cf.WANAssign[0].checked;
  if (
    (setDisabled(dflag, cf.WPethr1, cf.WPethr2, cf.WPethr3, cf.WPethr4),
    (DisableFixedIP = dflag),
    !document.getElementsByTagName("span")[0])
  )
    return !1;
  cf.WANAssign[1].checked
    ? ((cf.DNSAssign[1].checked = !0),
      setDNS(cf),
      (cf.DNSAssign[0].disabled = !0),
      (document.getElementsByTagName("span")[0].style.color = "gray"))
    : ((document.getElementsByTagName("span")[0].style.color = "black"),
      (cf.DNSAssign[0].disabled = !1));
}
function setDNS(cf) {
  var dflag = cf.DNSAssign[0].checked;
  setDisabled(
    dflag,
    cf.DAddr1,
    cf.DAddr2,
    cf.DAddr3,
    cf.DAddr4,
    cf.PDAddr1,
    cf.PDAddr2,
    cf.PDAddr3,
    cf.PDAddr4
  ),
    (DisableFixedDNS = dflag);
}
function change_pppoe_password(obj) {
  obj.value = "";
  document.forms[0].hidden_pwd_change.value = "1";
}
function check_wizard_pppoe(check, servername, page) {
  var form = document.forms[0];
  if ("" == form.pppoe_username.value) return alert("$login_name_null"), !1;
  for (i = 0; i < form.pppoe_username.value.length; i++)
    if (0 == isValidChar(form.pppoe_username.value.charCodeAt(i)))
      return alert("$loginname_not_allowed"), !1;
  for (i = 0; i < form.pppoe_passwd.value.length; i++)
    if (0 == isValidChar(form.pppoe_passwd.value.charCodeAt(i)))
      return alert("$password_error"), !1;
  for (i = 0; i < servername.length; i++)
    if (0 == isValidChar(servername.charCodeAt(i)))
      return alert("$servname_not_allowed"), !1;
  if ("1" == convert_value_to_original(form, "pppoe_dod")) {
    if (form.pppoe_idletime.value.length <= 0)
      return alert("$idle_time_null"), !1;
    if (!_isNumeric(form.pppoe_idletime.value))
      return alert("$invalid_idle_time"), !1;
  }
  return (
    1 == check
      ? ((form.run_test.value = "test"),
        "wiz" == page &&
          (form.action = "/apply.cgi?/WIZ_update.htm timestamp=" + ts))
      : (form.run_test.value = "no"),
    !0
  );
}
function check_pppoe(form, check) {
  if (
    (format_IP(
      "myip_1",
      "myip_2",
      "myip_3",
      "myip_4",
      "mymask_1",
      "mymask_2",
      "mymask_3",
      "mymask_4",
      "WPethr1",
      "WPethr2",
      "WPethr3",
      "WPethr4",
      "DAddr1",
      "DAddr2",
      "DAddr3",
      "DAddr4",
      "PDAddr1",
      "PDAddr2",
      "PDAddr3",
      "PDAddr4"
    ),
    1 == form.auto_conn_24hr.checked
      ? (form.hidden_auto_conn_flag.value = 1)
      : (form.hidden_auto_conn_flag.value = 0),
    (form.hidden_conn_time_num.value = form.auto_conn_time.selectedIndex),
    1 === getTop(window).support_ds_lite_flag && is_jp_version)
  ) {
    if (
      1 != form.enable_ds_lite.checked &&
      0 == check_wizard_pppoe(check, form.pppoe_servername.value, "bas")
    )
      return !1;
  } else if (1 == getTop(window).have_mape && is_jp_version) {
    if (
      "v6plus" != ipv6_type &&
      "dslite" != ipv6_type &&
      0 == check_wizard_pppoe(check, form.pppoe_servername.value, "bas")
    )
      return !1;
  } else if (0 == check_wizard_pppoe(check, form.pppoe_servername.value, "bas"))
    return !1;
  if (
    ((form.hidden_pppoe_idle_time.value = form.pppoe_idletime.value),
    (form.hid_pppoe_dod.value = convert_value_to_original(form, "pppoe_dod")),
    1 == pppoe_myip_flag)
  )
    if (
      ((form.pppoe_myip.value =
        form.myip_1.value +
        "." +
        form.myip_2.value +
        "." +
        form.myip_3.value +
        "." +
        form.myip_4.value),
      (form.pppoe_mask.value =
        form.mymask_1.value +
        "." +
        form.mymask_2.value +
        "." +
        form.mymask_3.value +
        "." +
        form.mymask_4.value),
      "..." != form.pppoe_myip.value)
    ) {
      if (
        ((form.intranet_wan_assign.value = 1),
        0 == checkipaddr(form.pppoe_myip.value))
      )
        return alert("$invalid_myip"), !1;
      if (
        (1 ==
          isSameSubNet(form.pppoe_myip.value, lan_subnet, lan_ip, lan_subnet) &&
          (form.conflict_wanlan.value = 1),
        1 == isSameIp(form.pppoe_myip.value, lan_ip) &&
          (form.conflict_wanlan.value = 1),
        "..." == form.pppoe_mask.value &&
          (parseInt(form.myip_1.value) < 128
            ? (form.pppoe_mask.value = "255.0.0.0")
            : parseInt(form.myip_1.value) < 192
            ? (form.pppoe_mask.value = "255.255.0.0")
            : (form.pppoe_mask.value = "255.255.255.0")),
        0 == checksubnet(form.pppoe_mask.value, 1))
      )
        return alert("$invalid_mask"), !1;
      1 ==
        isSameSubNet(
          form.pppoe_myip.value,
          form.pppoe_mask.value,
          lan_ip,
          form.pppoe_mask.value
        ) && (form.conflict_wanlan.value = 1),
        1 ==
          isSameSubNet(
            form.pppoe_myip.value,
            form.pppoe_mask.value,
            lan_ip,
            lan_subnet
          ) && (cf.conflict_wanlan.value = 1),
        (form.pppoe_myip.value = address_parseInt(form.pppoe_myip.value)),
        (form.pppoe_mask.value = address_parseInt(form.pppoe_mask.value));
    } else
      (form.pppoe_myip.value = ""),
        (form.pppoe_mask.value = ""),
        (form.intranet_wan_assign.value = 0);
  if (1 == form.WANAssign[1].checked) {
    if (
      ((form.pppoe_ipaddr.value =
        form.WPethr1.value +
        "." +
        form.WPethr2.value +
        "." +
        form.WPethr3.value +
        "." +
        form.WPethr4.value),
      0 == checkipaddr(form.pppoe_ipaddr.value) ||
        0 == is_sub_or_broad(form.pppoe_ipaddr.value, lan_ip, lan_subnet))
    )
      return alert("$invalid_ip"), !1;
    1 ==
      isSameSubNet(form.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (form.conflict_wanlan.value = 1),
      1 == isSameIp(form.pppoe_ipaddr.value, lan_ip) &&
        (form.conflict_wanlan.value = 1);
  }
  if (
    1 == form.DNSAssign[1].checked &&
    ((form.pppoe_dnsaddr1.value =
      form.DAddr1.value +
      "." +
      form.DAddr2.value +
      "." +
      form.DAddr3.value +
      "." +
      form.DAddr4.value),
    (form.pppoe_dnsaddr2.value =
      form.PDAddr1.value +
      "." +
      form.PDAddr2.value +
      "." +
      form.PDAddr3.value +
      "." +
      form.PDAddr4.value),
    (form.pppoe_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    "..." == form.pppoe_dnsaddr1.value
      ? (form.pppoe_dnsaddr1.value = "")
      : (form.pppoe_dnsaddr1.value = address_parseInt(
          form.pppoe_dnsaddr1.value
        )),
    "..." == form.pppoe_dnsaddr2.value
      ? (form.pppoe_dnsaddr2.value = "")
      : (form.pppoe_dnsaddr2.value = address_parseInt(
          form.pppoe_dnsaddr2.value
        )),
    !check_DNS(
      form.pppoe_dnsaddr1.value,
      form.pppoe_dnsaddr2.value,
      form.WANAssign[1].checked,
      form.pppoe_ipaddr.value
    ))
  )
    return !1;
  if (
    ((form.hid_mtu_value.value = wan_mtu_now),
    (form.pppoe_ipaddr.value = address_parseInt(form.pppoe_ipaddr.value)),
    "pppoe" != old_wan_type
      ? ((form.change_wan_type.value = 0), mtu_change(wanproto_type))
      : "1" == old_pppoe_wan_assign
      ? old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
        ? (form.change_wan_type.value = 0)
        : form.WANAssign[0].checked
        ? (form.change_wan_type.value = 0)
        : (form.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign &&
        (old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
          ? (form.change_wan_type.value = 0)
          : (form.change_wan_type.value = 1)),
    form.MACAssign[2].checked)
  ) {
    if (
      ((the_mac = form.Spoofmac.value),
      -1 == the_mac.indexOf(":") && "12" == the_mac.length)
    ) {
      var tmp_mac =
        the_mac.substr(0, 2) +
        ":" +
        the_mac.substr(2, 2) +
        ":" +
        the_mac.substr(4, 2) +
        ":" +
        the_mac.substr(6, 2) +
        ":" +
        the_mac.substr(8, 2) +
        ":" +
        the_mac.substr(10, 2);
      form.Spoofmac.value = tmp_mac;
    } else if (6 == the_mac.split("-").length) {
      tmp_mac = the_mac.replace(/-/g, ":");
      form.Spoofmac.value = tmp_mac;
    }
    if (0 == maccheck_multicast(form.Spoofmac.value)) return !1;
  }
  if (
    ((form.hid_enable_vpn.value = vpn_enable),
    "1" != old_endis_ddns && "1" == vpn_enable)
  ) {
    if (1 != confirm("$no_change_static_ip"))
      return (form.hid_enable_vpn.value = "1"), !1;
    form.hid_enable_vpn.value = "0";
  }
  if (
    0 == parent.enable_vlan_pppoe_support &&
    "1" == vlan_iptv_enable &&
    0 == confirm("$vlan_pppoe_support_query")
  )
    return !1;
  if (
    !(
      (1 === getTop(window).support_ds_lite_flag &&
        is_jp_version &&
        1 == form.enable_ds_lite.checked) ||
      (1 == getTop(window).have_mape &&
        is_jp_version &&
        ("v6plus" == ipv6_type || "dslite" == ipv6_type)) ||
      ("1" != form.hid_pppoe_dod.value && "2" != form.hid_pppoe_dod.value) ||
      ("1" != readycloud_enable &&
        "1" != vpn_enable &&
        "1" != upnp_enableMedia &&
        1 != parent.geniecloud_flag) ||
      0 != confirm("$ppp_dial_on_demand_query")
    )
  )
    return !1;
  if (
    1 === getTop(window).use_orbi_style_flag &&
    1 == form.wan_preference[4].checked
  )
    if ("0" != qos_endis_on && "0" != aggre_option) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS and Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if ("0" != qos_endis_on) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if (
      "0" != aggre_option &&
      0 ==
        confirm(
          "Enabling WAN aggregation disables Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
    )
      return !1;
  if (
    ("1" == form.sfp_module.value
      ? (form.hid_sfp_module.value = 1)
      : (form.hid_sfp_module.value = 0),
    1 === getTop(window).support_ds_lite_flag && is_jp_version)
  ) {
    if (1 == form.enable_ds_lite.checked) {
      if (
        (("disabled" != ipv6_type &&
          "6to4" != ipv6_type &&
          "bridge" != ipv6_type) ||
          alert(
            'IPv6 connection type will be set to "Auto Config" automatically'
          ),
        (form.hid_enable_ds.value = 1),
        "1" == form.hid_aftr_ipv6.value)
      ) {
        if ("" == form.aftr_ipv6_addr.value)
          return alert("Empty Manual Config AFTR IPv6 Address!"), !1;
        var tmp = form.aftr_ipv6_addr.value;
        "http://" == tmp.slice(0, 7)
          ? (tmp = tmp.slice(7))
          : "https://" == tmp.slice(0, 8) && (tmp = tmp.slice(8));
        var i = tmp.indexOf("/");
        (i = -1 == i ? tmp.length : i),
          (tmp = tmp.slice(0, i)),
          (ipv6_array = tmp.split(":"));
        var isIpv6IP = /^[0-9A-Fa-f:]+$$/g.test(tmp),
          is_fqdn_addr = /^(www\.)?[-a-zA-Z0-9]+(\.[-a-zA-Z0-9]+)+$$/g.test(
            tmp
          );
        if (isIpv6IP) {
          if (ipv6_array.length < 4 || ipv6_array.length > 8)
            return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
        } else if (!is_fqdn_addr)
          return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
      }
    } else form.hid_enable_ds.value = 0;
    1 == form.enable_nd_proxy.checked
      ? (form.hid_enable_nd.value = 1)
      : (form.hid_enable_nd.value = 0);
  }
  return form.submit(), !0;
}
function setIP_welcome_pppoe() {
  cf = document.forms[0];
  var dflag = cf.WANAssign[0].checked;
  setDisabled(dflag, cf.WPethr1, cf.WPethr2, cf.WPethr3, cf.WPethr4),
    (DisableFixedIP = dflag);
}
function setDNS_welcome_pppoe() {
  cf = document.forms[0];
  var dflag = cf.DNSAssign[0].checked;
  setDisabled(
    dflag,
    cf.DAddr1,
    cf.DAddr2,
    cf.DAddr3,
    cf.DAddr4,
    cf.PDAddr1,
    cf.PDAddr2,
    cf.PDAddr3,
    cf.PDAddr4
  ),
    (DisableFixedDNS = dflag);
}
function check_wizard_pppoe_new(check) {
  var cf = document.forms[0];
  if (0 == check_wizard_pppoe(check, cf.pppoe_servicename.value, "wiz"))
    return !1;
  if (
    ((cf.pppoe_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    cf.WANAssign[1].checked && 0 == checkipaddr(cf.pppoe_ipaddr.value))
  )
    return alert("$invalid_ip"), !1;
  if (1 == cf.DNSAssign[1].checked) {
    if (
      ((cf.pppoe_dnsaddr1.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      (cf.pppoe_dnsaddr2.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      "..." == cf.pppoe_dnsaddr1.value && (cf.pppoe_dnsaddr1.value = ""),
      "..." == cf.pppoe_dnsaddr2.value && (cf.pppoe_dnsaddr2.value = ""),
      !check_DNS(
        cf.pppoe_dnsaddr1.value,
        cf.pppoe_dnsaddr2.value,
        cf.WANAssign[1].checked,
        cf.pppoe_ipaddr.value
      ))
    )
      return !1;
    (cf.pppoe_dnsaddr1.value = address_parseInt(cf.pppoe_dnsaddr1.value)),
      (cf.pppoe_dnsaddr2.value = address_parseInt(cf.pppoe_dnsaddr2.value));
  }
  cf.pppoe_ipaddr.value = address_parseInt(cf.pppoe_ipaddr.value);
}
function check_welcome_pppoe() {
  var cf = document.forms[0];
  return (
    0 != check_wizard_pppoe(0, cf.pppoe_servername.value) &&
    ((cf.pppoe_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    !cf.WANAssign[1].checked ||
    (0 != checkipaddr(cf.pppoe_ipaddr.value) &&
      0 != is_sub_or_broad(cf.pppoe_ipaddr.value, lan_ip, lan_subnet))
      ? !(
          1 == cf.DNSAssign[1].checked &&
          ((cf.pppoe_dnsaddr1.value =
            cf.DAddr1.value +
            "." +
            cf.DAddr2.value +
            "." +
            cf.DAddr3.value +
            "." +
            cf.DAddr4.value),
          (cf.pppoe_dnsaddr2.value =
            cf.PDAddr1.value +
            "." +
            cf.PDAddr2.value +
            "." +
            cf.PDAddr3.value +
            "." +
            cf.PDAddr4.value),
          "..." == cf.pppoe_dnsaddr1.value && (cf.pppoe_dnsaddr1.value = ""),
          "..." == cf.pppoe_dnsaddr2.value && (cf.pppoe_dnsaddr2.value = ""),
          !check_DNS(
            cf.pppoe_dnsaddr1.value,
            cf.pppoe_dnsaddr2.value,
            cf.WANAssign[1].checked,
            cf.pppoe_ipaddr.value
          ))
        ) &&
        ((parent.pppoe_username = cf.pppoe_username.value),
        (parent.pppoe_passwd = cf.pppoe_passwd.value),
        (parent.pppoe_server = cf.pppoe_servername.value),
        (parent.pppoe_idle = cf.pppoe_idletime.value),
        cf.WANAssign[1].checked
          ? ((parent.pppoe_wan_assign = 1),
            (parent.pppoe_static_ip = cf.pppoe_ipaddr.value))
          : ((parent.pppoe_wan_assign = 0), (parent.pppoe_static_ip = "")),
        1 == cf.DNSAssign[1].checked
          ? ((parent.pppoe_dns_assign = 1),
            (parent.pppoe_dns1.value = cf.pppoe_dnsaddr1.value),
            (parent.pppoe_dns2.value = cf.pppoe_dnsaddr2.value))
          : ((parent.pppoe_dns_assign = 0),
            (parent.pppoe_dns1.value = ""),
            (parent.pppoe_dns2.value = "")),
        (parent.welcome_wan_type = 3),
        !0)
      : (alert("$invalid_ip"), !1))
  );
}
function RU_pppoe_user_info() {
  var cf = document.forms[0];
  if ("" == cf.pppoe_username.value) return alert(login_name_null), !1;
  for (i = 0; i < cf.pppoe_username.value.length; i++)
    if (0 == isValidChar(cf.pppoe_username.value.charCodeAt(i)))
      return alert(loginname_not_allowed), !1;
  for (i = 0; i < cf.pppoe_passwd.value.length; i++)
    if (0 == isValidChar(cf.pppoe_passwd.value.charCodeAt(i)))
      return alert(password_not_allowed), !1;
  for (i = 0; i < cf.pppoe_servername.value.length; i++)
    if (0 == isValidChar(cf.pppoe_servername.value.charCodeAt(i)))
      return alert(servname_not_allowed), !1;
  (parent.pppoe_username = cf.pppoe_username.value),
    (parent.pppoe_password = cf.pppoe_passwd.value),
    (parent.pppoe_server = cf.pppoe_servername.value),
    (parent.welcome_wan_type = 3),
    "8" == parent.isp_type
      ? ((cf.basic_type.value = "0"),
        (cf.ppp_login_type.value = "0"),
        (cf.welcome_wan_type.value = "3"),
        (cf.dual_access.value = "1"),
        (cf.pppoe_dual_assign.value = 0),
        (cf.conflict_wanlan.value = 0),
        (cf.pppoe_dual_ipaddr.value = ""),
        (cf.pppoe_dual_subnet.value = ""),
        (cf.pppoe_dnsaddr1.value = parent.static_dns1),
        (cf.pppoe_dnsaddr2.value = parent.static_dns2),
        "" != cf.pppoe_dnsaddr1.value || "" != cf.pppoe_dnsaddr2.value
          ? (cf.DNSAssign.value = "1")
          : (cf.DNSAssign.value = "0"),
        (cf.WANAssign.value = "Dynamic"),
        (cf.pppoe_dod.value = "0"),
        (cf.pppoe_servername.value = parent.pppoe_server),
        cf.submit())
      : "18" == parent.isp_type
      ? ((cf.basic_type.value = "0"),
        (cf.ppp_login_type.value = "0"),
        (cf.welcome_wan_type.value = "3"),
        (cf.dual_access.value = "0"),
        (cf.pppoe_dual_assign.value = 0),
        (cf.conflict_wanlan.value = 0),
        (cf.pppoe_dual_ipaddr.value = ""),
        (cf.pppoe_dual_subnet.value = ""),
        (cf.DNSAssign.value = "0"),
        (cf.WANAssign.value = "Dynamic"),
        (cf.pppoe_dod.value = "0"),
        (cf.pppoe_servername.value = parent.pppoe_server),
        cf.submit())
      : "7" == parent.isp_type || "17" == parent.isp_type
      ? (location.href = "RU_isp_spoof.htm")
      : "5" == parent.isp_type || "6" == parent.isp_type
      ? (location.href = "RU_isp_pppoe_static.htm")
      : "88" == parent.isp_type
      ? (location.href = "RU_isp_pppoe_static.htm")
      : (location.href = "RU_manual_pppoe2.htm");
}
function RU_check_pppoe() {
  var wan_assign_flag,
    cf = document.forms[0];
  if (
    ((cf.pppoe_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    1 == cf.WANAssign[0].checked)
  )
    (cf.pppoe_ipaddr.value = ""), (parent.pppoe_wan_assign = "0");
  else {
    if (
      0 == checkipaddr(cf.pppoe_ipaddr.value) ||
      0 == is_sub_or_broad(cf.pppoe_ipaddr.value, lan_ip, lan_subnet)
    )
      return alert(invalid_myip), !1;
    1 == isSameSubNet(cf.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pppoe_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1),
      (parent.pppoe_wan_assign = "1");
  }
  if (1 == cf.DNSAssign[1].checked) {
    if (
      ((cf.pppoe_dnsaddr1.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      (cf.pppoe_dnsaddr2.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      "..." == cf.pppoe_dnsaddr1.value && (cf.pppoe_dnsaddr1.value = ""),
      "..." == cf.pppoe_dnsaddr2.value && (cf.pppoe_dnsaddr2.value = ""),
      (wan_assign_flag = "0" != parent.pppoe_wan_assign),
      !check_RU_DNS(
        cf.pppoe_dnsaddr1.value,
        cf.pppoe_dnsaddr2.value,
        wan_assign_flag,
        parent.pppoe_static_ip
      ))
    )
      return !1;
  } else (cf.pppoe_dnsaddr1.value = ""), (cf.pppoe_dnsaddr2.value = "");
  (parent.pppoe_static_ip = cf.pppoe_ipaddr.value),
    (parent.pppoe_dns1 = cf.pppoe_dnsaddr1.value),
    (parent.pppoe_dns2 = cf.pppoe_dnsaddr2.value),
    (location.href = "RU_manu_local_resources.htm");
}
function setdualIP(cf) {
  var dflag = cf.DualAssign[0].checked;
  setDisabled(
    dflag,
    cf.Duethr1,
    cf.Duethr2,
    cf.Duethr3,
    cf.Duethr4,
    cf.DuMask1,
    cf.DuMask2,
    cf.DuMask3,
    cf.DuMask4
  ),
    (DisableFixedIP = dflag);
}
function RU_check_pppoe_dual() {
  var cf = document.forms[0];
  if (
    ((cf.pppoe_dual_ipaddr.value =
      cf.Duethr1.value +
      "." +
      cf.Duethr2.value +
      "." +
      cf.Duethr3.value +
      "." +
      cf.Duethr4.value),
    (cf.pppoe_dual_subnet.value =
      cf.DuMask1.value +
      "." +
      cf.DuMask2.value +
      "." +
      cf.DuMask3.value +
      "." +
      cf.DuMask4.value),
    (cf.conflict_wanlan.value = 0),
    1 == cf.DualAssign[1].checked)
  ) {
    if (
      ((cf.pppoe_dual_assign.value = 1),
      0 == checkipaddr(cf.pppoe_dual_ipaddr.value) ||
        0 ==
          is_sub_or_broad(
            cf.pppoe_dual_ipaddr.value,
            cf.pppoe_dual_ipaddr.value,
            cf.pppoe_dual_subnet.value
          ))
    )
      return alert(invalid_myip), !1;
    if (0 == checksubnet(cf.pppoe_dual_subnet.value))
      return alert(invalid_mask), !1;
    (cf.pppoe_dual_assign.value = 1),
      1 ==
        isSameSubNet(
          cf.pppoe_dual_ipaddr.value,
          lan_subnet,
          lan_ip,
          lan_subnet
        ) && (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pppoe_dual_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1),
      alert(attention_static_ip);
  } else
    (cf.pppoe_dual_assign.value = 0),
      (cf.pppoe_dual_ipaddr.value = ""),
      (cf.pppoe_dual_subnet.value = "");
  (parent.conflict_wanlan = cf.conflict_wanlan.value),
    (parent.pppoe_dual_assign = cf.pppoe_dual_assign.value),
    (parent.pppoe_eth_ip = cf.pppoe_dual_ipaddr.value),
    (parent.pppoe_eth_netmask = cf.pppoe_dual_subnet.value),
    (location.href = "RU_manual_spoof.htm");
}
function check_orange_pppoe(form, check) {
  if (
    (1 == form.auto_conn_24hr.checked
      ? (form.hidden_auto_conn_flag.value = 1)
      : (form.hidden_auto_conn_flag.value = 0),
    (form.hidden_conn_time_num.value = form.auto_conn_time.selectedIndex),
    0 == check_wizard_pppoe(check, "", "bas"))
  )
    return !1;
  if (
    ((form.hidden_pppoe_idle_time.value = form.pppoe_idletime.value),
    (form.hid_pppoe_dod.value = form.pppoe_dod.value),
    1 == form.WANAssign[1].checked)
  ) {
    if (
      ((form.pppoe_ipaddr.value =
        form.WPethr1.value +
        "." +
        form.WPethr2.value +
        "." +
        form.WPethr3.value +
        "." +
        form.WPethr4.value),
      0 == checkipaddr(form.pppoe_ipaddr.value) ||
        0 == is_sub_or_broad(form.pppoe_ipaddr.value, lan_ip, lan_subnet))
    )
      return alert("$invalid_ip"), !1;
    1 ==
      isSameSubNet(form.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (form.conflict_wanlan.value = 1),
      1 == isSameIp(form.pppoe_ipaddr.value, lan_ip) &&
        (form.conflict_wanlan.value = 1);
  }
  if (
    1 == form.DNSAssign[1].checked &&
    ((form.pppoe_dnsaddr1.value =
      form.DAddr1.value +
      "." +
      form.DAddr2.value +
      "." +
      form.DAddr3.value +
      "." +
      form.DAddr4.value),
    (form.pppoe_dnsaddr2.value =
      form.PDAddr1.value +
      "." +
      form.PDAddr2.value +
      "." +
      form.PDAddr3.value +
      "." +
      form.PDAddr4.value),
    (form.pppoe_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    "..." == form.pppoe_dnsaddr1.value
      ? (form.pppoe_dnsaddr1.value = "")
      : (form.pppoe_dnsaddr1.value = address_parseInt(
          form.pppoe_dnsaddr1.value
        )),
    "..." == form.pppoe_dnsaddr2.value
      ? (form.pppoe_dnsaddr2.value = "")
      : (form.pppoe_dnsaddr2.value = address_parseInt(
          form.pppoe_dnsaddr2.value
        )),
    !check_DNS(
      form.pppoe_dnsaddr1.value,
      form.pppoe_dnsaddr2.value,
      form.WANAssign[1].checked,
      form.pppoe_ipaddr.value
    ))
  )
    return !1;
  if (
    ((form.hid_mtu_value.value = wan_mtu_now),
    (form.pppoe_ipaddr.value = address_parseInt(form.pppoe_ipaddr.value)),
    "orange_pppoe" != old_wan_type
      ? ((form.change_wan_type.value = 0), mtu_change(wanproto_type))
      : "1" == old_pppoe_wan_assign
      ? old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
        ? (form.change_wan_type.value = 0)
        : form.WANAssign[0].checked
        ? (form.change_wan_type.value = 0)
        : (form.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign &&
        (old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
          ? (form.change_wan_type.value = 0)
          : (form.change_wan_type.value = 1)),
    form.MACAssign[2].checked)
  ) {
    if (
      ((the_mac = form.Spoofmac.value),
      -1 == the_mac.indexOf(":") && "12" == the_mac.length)
    ) {
      var tmp_mac =
        the_mac.substr(0, 2) +
        ":" +
        the_mac.substr(2, 2) +
        ":" +
        the_mac.substr(4, 2) +
        ":" +
        the_mac.substr(6, 2) +
        ":" +
        the_mac.substr(8, 2) +
        ":" +
        the_mac.substr(10, 2);
      form.Spoofmac.value = tmp_mac;
    } else if (6 == the_mac.split("-").length) {
      tmp_mac = the_mac.replace(/-/g, ":");
      form.Spoofmac.value = tmp_mac;
    }
    if (0 == maccheck_multicast(form.Spoofmac.value)) return !1;
  }
  if (
    ((form.hid_enable_vpn.value = vpn_enable),
    "1" != old_endis_ddns && "1" == vpn_enable)
  ) {
    if (1 != confirm("$no_change_static_ip"))
      return (form.hid_enable_vpn.value = "1"), !1;
    form.hid_enable_vpn.value = "0";
  }
  return (
    (0 != parent.enable_vlan_pppoe_support ||
      "1" != vlan_iptv_enable ||
      0 != confirm("$vlan_pppoe_support_query")) &&
    (("1" != form.pppoe_dod.value && "2" != form.pppoe_dod.value) ||
      ("1" != readycloud_enable &&
        "1" != vpn_enable &&
        "1" != upnp_enableMedia &&
        1 != parent.geniecloud_flag) ||
      0 != confirm("$ppp_dial_on_demand_query")) &&
    (1 == form.orange_enable.checked
      ? (form.hidden_enable_orange.value = "1")
      : (form.hidden_enable_orange.value = "0"),
    form.submit(),
    !0)
  );
}
function check_orange_dhcp(form, check) {
  if (
    !(
      (1 == getTop(window).support_singapore_isp_flag &&
        "SingTel Singapore DHCP" == form.login_type.value) ||
      (1 == getTop(window).support_malaysia_isp_flag &&
        "Unifi Malaysia DHCP" == form.login_type.value) ||
      (1 == getTop(window).support_malaysia_isp_flag &&
        "Maxis Malaysia DHCP" == form.login_type.value)
    )
  ) {
    if ("" == form.orange_username.value) return alert("$login_name_null"), !1;
    for (i = 0; i < form.orange_username.value.length; i++)
      if (0 == isValidChar(form.orange_username.value.charCodeAt(i)))
        return alert("$loginname_not_allowed"), !1;
  }
  if (1 == form.WANAssign[1].checked) {
    if (
      ((form.pppoe_ipaddr.value =
        form.WPethr1.value +
        "." +
        form.WPethr2.value +
        "." +
        form.WPethr3.value +
        "." +
        form.WPethr4.value),
      0 == checkipaddr(form.pppoe_ipaddr.value) ||
        0 == is_sub_or_broad(form.pppoe_ipaddr.value, lan_ip, lan_subnet))
    )
      return alert("$invalid_ip"), !1;
    1 ==
      isSameSubNet(form.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (form.conflict_wanlan.value = 1),
      1 == isSameIp(form.pppoe_ipaddr.value, lan_ip) &&
        (form.conflict_wanlan.value = 1);
  }
  if (
    1 == form.DNSAssign[1].checked &&
    ((form.pppoe_dnsaddr1.value =
      form.DAddr1.value +
      "." +
      form.DAddr2.value +
      "." +
      form.DAddr3.value +
      "." +
      form.DAddr4.value),
    (form.pppoe_dnsaddr2.value =
      form.PDAddr1.value +
      "." +
      form.PDAddr2.value +
      "." +
      form.PDAddr3.value +
      "." +
      form.PDAddr4.value),
    (form.pppoe_ipaddr.value =
      form.WPethr1.value +
      "." +
      form.WPethr2.value +
      "." +
      form.WPethr3.value +
      "." +
      form.WPethr4.value),
    "..." == form.pppoe_dnsaddr1.value
      ? (form.pppoe_dnsaddr1.value = "")
      : (form.pppoe_dnsaddr1.value = address_parseInt(
          form.pppoe_dnsaddr1.value
        )),
    "..." == form.pppoe_dnsaddr2.value
      ? (form.pppoe_dnsaddr2.value = "")
      : (form.pppoe_dnsaddr2.value = address_parseInt(
          form.pppoe_dnsaddr2.value
        )),
    !check_DNS(
      form.pppoe_dnsaddr1.value,
      form.pppoe_dnsaddr2.value,
      form.WANAssign[1].checked,
      form.pppoe_ipaddr.value
    ))
  )
    return !1;
  if (
    ((form.hid_mtu_value.value = wan_mtu_now),
    (form.pppoe_ipaddr.value = address_parseInt(form.pppoe_ipaddr.value)),
    "orange_dhcp" != old_wan_type
      ? ((form.change_wan_type.value = 0), mtu_change(wanproto_type))
      : "1" == old_pppoe_wan_assign
      ? old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
        ? (form.change_wan_type.value = 0)
        : form.WANAssign[0].checked
        ? (form.change_wan_type.value = 0)
        : (form.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign &&
        (old_wan_ip != form.pppoe_ipaddr.value && form.WANAssign[1].checked
          ? (form.change_wan_type.value = 0)
          : (form.change_wan_type.value = 1)),
    form.MACAssign[2].checked)
  ) {
    if (
      ((the_mac = form.Spoofmac.value),
      -1 == the_mac.indexOf(":") && "12" == the_mac.length)
    ) {
      var tmp_mac =
        the_mac.substr(0, 2) +
        ":" +
        the_mac.substr(2, 2) +
        ":" +
        the_mac.substr(4, 2) +
        ":" +
        the_mac.substr(6, 2) +
        ":" +
        the_mac.substr(8, 2) +
        ":" +
        the_mac.substr(10, 2);
      form.Spoofmac.value = tmp_mac;
    } else if (6 == the_mac.split("-").length) {
      tmp_mac = the_mac.replace(/-/g, ":");
      form.Spoofmac.value = tmp_mac;
    }
    if (0 == maccheck_multicast(form.Spoofmac.value)) return !1;
  }
  if (
    ((form.hid_enable_vpn.value = vpn_enable),
    "1" != old_endis_ddns && "1" == vpn_enable)
  ) {
    if (1 != confirm("$no_change_static_ip"))
      return (form.hid_enable_vpn.value = "1"), !1;
    form.hid_enable_vpn.value = "0";
  }
  return (
    1 == form.orange_enable.checked
      ? (form.hidden_enable_orange.value = "1")
      : (form.hidden_enable_orange.value = "0"),
    form.submit(),
    !0
  );
}
