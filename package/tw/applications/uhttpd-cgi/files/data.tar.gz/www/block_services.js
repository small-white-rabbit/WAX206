var disable = !1,
  serv_array = [
    ["0", "", "", "", "0"],
    ["2", "1", "65535", "Any", "1"],
    ["0", "1", "65535", "Any(TCP)", "1"],
    ["1", "1", "65535", "Any(UDP)", "1"],
    //["0", "5190", "5190", "AIM", "1"],
    //["1", "47624", "47624", "Age-of-Empire", "1"],
    //["0", "179", "179", "BGP", "1"],
    ["1", "68", "68", "BOOTP-CLIENT", "1"],
    ["1", "67", "67", "BOOTP-SERVER", "1"],
    //["2", "7648", "24032", "CU-SEEME", "1"],
    ["2", "53", "53", "DNS", "1"],
    //["0", "79", "79", "FINGER", "1"],
    ["0", "20", "21", "FTP", "1"],
    ["0", "1720", "1720", "H.323", "1"],
    ["0", "80", "80", "HTTP", "1"],
    ["0", "443", "443", "HTTPS", "1"],
    //["0", "23566", "23566", "ICUII", "1"],
    //["0", "113", "113", "IDENT", "1"],
    ["0", "6670", "6670", "IP_Phone", "1"],
    ["2", "6667", "6667", "IRC", "1"],
    //["0", "1720", "1720", "NetMeeting", "1"],
    ["1", "2049", "2049", "NFS", "1"],
    ["0", "119", "119", "News", "1"],
    //["2", "27960", "27960", "QuakeII/III", "1"],
    ["0", "512", "512", "RCMD", "1"],
    //["2", "6970", "7170", "Real-Audio", "1"],
    ["0", "514", "514", "REXEC", "1"],
    ["0", "513", "513", "RLOGIN", "1"],
    ["0", "107", "107", "RTELNET", "1"],
    ["2", "554", "554", "RTSP", "1"],
    ["0", "115", "115", "SFTP", "1"],
    ["0", "25", "25", "SMTP", "1"],
    ["2", "161", "161", "SNMP", "1"],
    ["2", "162", "162", "SNMP-TRAPS", "1"],
    ["0", "1521", "1521", "SQL-NET", "1"],
    ["2", "22", "22", "SSH", "1"],
    //["1", "1558", "1558", "STRMWORKS", "1"],
    //["1", "49", "49", "TACACS", "1"],
    ["0", "23", "23", "Telnet", "1"],
    ["1", "69", "69", "TFTP", "1"],
    //["0", "7000", "7000", "VDOLIVE", "1"],
    ["1", "500", "500", "VPN-IPSEC", "1"],
    ["1", "1701", "1701", "VPN-L2TP", "1"],
    ["0", "1723", "1723", "VPN-PPTP", "1"],
  ];
function pi(val) {
  return parseInt(val, 10);
}
function chg_by_service(is_load, cf) {
  var s = cf.service_type.selectedIndex,
    len = cf.service_type.options.length;
  s < 0 && (s = cf.service_type.selectedIndex = 0),
    (s == len - 1 && 1 == is_load) ||
      ((disable = 1 == pi(serv_array[s][4])),
      (cf.protocol.selectedIndex = pi(serv_array[s][0])),
      (cf.portstart.value = serv_array[s][1]),
      (cf.portend.value = serv_array[s][2]),
      (cf.userdefined.value = serv_array[s][3]),
      (cf.protocol.disabled = disable),
      (cf.portstart.disabled = disable),
      (cf.portend.disabled = disable),
      (cf.userdefined.disabled = disable));
}
function change_radio(check, cf) {
  lan_ip.split(".");
  var subnet_array = lan_subnet.split(".");
  0 == check
    ? (255 != parseInt(subnet_array[0], 10) && (cf.f_pcip1.disabled = !1),
      255 != parseInt(subnet_array[1], 10) && (cf.f_pcip2.disabled = !1),
      255 != parseInt(subnet_array[2], 10) && (cf.f_pcip3.disabled = !1),
      255 != parseInt(subnet_array[3], 10) && (cf.f_pcip4.disabled = !1),
      (cf.f_startip1.disabled = !0),
      (cf.f_startip2.disabled = !0),
      (cf.f_startip3.disabled = !0),
      (cf.f_startip4.disabled = !0),
      (cf.f_endip1.disabled = !0),
      (cf.f_endip2.disabled = !0),
      (cf.f_endip3.disabled = !0),
      (cf.f_endip4.disabled = !0))
    : 1 == check
    ? (255 != parseInt(subnet_array[0], 10) &&
        ((cf.f_startip1.disabled = !1), (cf.f_endip1.disabled = !1)),
      255 != parseInt(subnet_array[1], 10) &&
        ((cf.f_startip2.disabled = !1), (cf.f_endip2.disabled = !1)),
      255 != parseInt(subnet_array[2], 10) &&
        ((cf.f_startip3.disabled = !1), (cf.f_endip3.disabled = !1)),
      255 != parseInt(subnet_array[3], 10) &&
        ((cf.f_startip4.disabled = !1), (cf.f_endip4.disabled = !1)),
      (cf.f_pcip1.disabled = !0),
      (cf.f_pcip2.disabled = !0),
      (cf.f_pcip3.disabled = !0),
      (cf.f_pcip4.disabled = !0))
    : ((cf.f_pcip1.disabled = !0),
      (cf.f_pcip2.disabled = !0),
      (cf.f_pcip3.disabled = !0),
      (cf.f_pcip4.disabled = !0),
      (cf.f_startip1.disabled = !0),
      (cf.f_startip2.disabled = !0),
      (cf.f_startip3.disabled = !0),
      (cf.f_startip4.disabled = !0),
      (cf.f_endip1.disabled = !0),
      (cf.f_endip2.disabled = !0),
      (cf.f_endip3.disabled = !0),
      (cf.f_endip4.disabled = !0));
}
function check_block_services_add(cf, flag) {
  if (
    (1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      "0" != enable_multipppoe_serv &&
      (array_num = session2_array_num),
    "add" == flag && 20 == array_num)
  )
    return alert("$blockser_length_20"), !1;
  if ("" == cf.portstart.value || "" == cf.portend.value)
    return alert("$invalid_port"), !1;
  for (txt = cf.portstart.value, i = 0; i < txt.length; i++)
    if (((c = txt.charAt(i)), "0123456789".indexOf(c, 0) < 0))
      return alert("$invalid_start_port"), !1;
  for (txt = cf.portend.value, i = 0; i < txt.length; i++)
    if (((c = txt.charAt(i)), "0123456789".indexOf(c, 0) < 0))
      return alert("$invalid_end_port"), !1;
  if (
    parseInt(cf.portstart.value, 10) < 1 ||
    parseInt(cf.portstart.value, 10) > 65535
  )
    return alert("$invalid_start_port"), !1;
  if (
    parseInt(cf.portend.value, 10) < 1 ||
    parseInt(cf.portend.value, 10) > 65535
  )
    return alert("$invalid_end_port"), !1;
  if (parseInt(cf.portend.value, 10) < parseInt(cf.portstart.value, 10))
    return alert("$end_port_greater"), !1;
  if (((txt = cf.userdefined.value), "" == txt))
    return alert("$invalid_user_type"), !1;
  for (i = 0; i < txt.length; i++)
    if (0 == isValidChar_space(txt.charCodeAt(i)))
      return alert("$invalid_user_type"), !1;
  if (
    ((cf.hidden_userdefined.value = cf.userdefined.value),
    (cf.hidden_protocol.value = cf.protocol.value),
    (cf.only_ip.value =
      cf.f_pcip1.value +
      "." +
      cf.f_pcip2.value +
      "." +
      cf.f_pcip3.value +
      "." +
      cf.f_pcip4.value),
    (cf.iprange_start.value =
      cf.f_startip1.value +
      "." +
      cf.f_startip2.value +
      "." +
      cf.f_startip3.value +
      "." +
      cf.f_startip4.value),
    (cf.iprange_end.value =
      cf.f_endip1.value +
      "." +
      cf.f_endip2.value +
      "." +
      cf.f_endip3.value +
      "." +
      cf.f_endip4.value),
    1 == cf.iptype[0].checked)
  ) {
    if (
      0 == checkipaddr(cf.only_ip.value) ||
      0 == is_sub_or_broad(cf.only_ip.value, lan_ip, lan_subnet)
    )
      return alert("$invalid_ip"), !1;
    if (1 == isSameIp(cf.only_ip.value, lan_ip))
      return alert("$unusable_ip_addr"), !1;
    if (0 == isSameSubNet(cf.only_ip.value, lan_subnet, lan_ip, lan_subnet))
      return alert("$diff_lan_this_subnet"), !1;
    cf.iplist.value = address_parseInt(cf.only_ip.value);
  } else if (1 == cf.iptype[1].checked) {
    if (
      0 == checkipaddr(cf.iprange_start.value) ||
      0 == is_sub_or_broad(cf.iprange_start.value, lan_ip, lan_subnet)
    )
      return alert("$invalid_ip"), !1;
    if (
      0 == checkipaddr(cf.iprange_end.value) ||
      0 == is_sub_or_broad(cf.iprange_end.value, lan_ip, lan_subnet)
    )
      return alert("$invalid_ip"), !1;
    if (0 == cp_ip2(cf.iprange_start.value, cf.iprange_end.value))
      return alert("$invalid_ip_rang"), !1;
    if (
      0 == isSameSubNet(cf.iprange_start.value, lan_subnet, lan_ip, lan_subnet)
    )
      return alert("$diff_lan_ipstart_subnet"), !1;
    if (0 == isSameSubNet(cf.iprange_end.value, lan_subnet, lan_ip, lan_subnet))
      return alert("$diff_lan_ipend_subnet"), !1;
    if (isIncludeInvIp(lan_ip, cf.iprange_start.value, cf.iprange_end.value))
      return alert("$invalid_ip"), !1;
    cf.iplist.value =
      address_parseInt(cf.iprange_start.value) +
      "-" +
      address_parseInt(cf.iprange_end.value);
  } else cf.iplist.value = "all";
  for (
    cf.portstart.value = port_range_interception(cf.portstart.value),
      cf.portend.value = port_range_interception(cf.portend.value),
      cf.hidden_portstart.value = cf.portstart.value,
      cf.hidden_portend.value = cf.portend.value,
      i = 1;
    i <= array_num;
    i++
  ) {
    if (
      1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      "0" != enable_multipppoe_serv
    )
      var str = eval("session2_block_servicesArray" + i).split(" ");
    else
      var str = eval("block_servicesArray" + i).split(" ");
	
    var each_info = $$.map(str, function(val) {
    	return htmlDecode(val);
    });
	
    if ("edit" == flag) {
      if (
        cf.iplist.value == each_info[6] &&
        i != select_edit
      )
        if ("User_Defined" != cf.service_type.value) {
          if (
            cf.service_type.value == each_info[0] ||
            cf.userdefined.value == each_info[4]
          )
            return alert("$service_type_dup"), !1;
        } else if (
          cf.userdefined.value == each_info[4] &&
          cf.protocol.value == each_info[1] &&
          cf.hidden_portstart.value == each_info[2] &&
          cf.hidden_portend.value == each_info[3]
        )
          return alert("$service_type_dup"), !1;
    } else if (cf.iplist.value == each_info[6])
      if ("User_Defined" != cf.service_type.value) {
        if (
          cf.service_type.value == each_info[0] ||
          cf.userdefined.value == each_info[4]
        )
          return alert("$service_type_dup"), !1;
      } else if (
        cf.userdefined.value == each_info[4] &&
        cf.protocol.value == each_info[1] &&
        cf.hidden_portstart.value == each_info[2] &&
        cf.hidden_portend.value == each_info[3]
      )
        return alert("$service_type_dup"), !1;
  }
  return (
    1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      ("0" == enable_multipppoe_serv
        ? (cf.hid_session.value = "session1")
        : (cf.hid_session.value = "session2")),
    cf.submit(),
    !0
  );
}
function check_block_services_edit(cf) {
  if (
    (1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      1 == cf.session[1].checked &&
      (array_num = session2_array_num),
    0 == array_num)
  )
    return (location.href = "edit_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.ruleSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.ruleSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? ((location.href = "edit_fail.htm"), !1)
    : ((cf.select_edit.value = select_num),
      (cf.submit_flag.value = "block_services_editnum"),
      (cf.anticsrf.value = block_services_editnum_token),
      (cf.action = "/apply.cgi?/BKS_service_edit.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function check_block_services_del(cf) {
  if (
    (1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      1 == cf.session[1].checked &&
      (array_num = session2_array_num),
    0 == array_num)
  )
    return (location.href = "del_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.ruleSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.ruleSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? ((location.href = "del_fail.htm"), !1)
    : ((cf.select_del.value = select_num),
      (cf.submit_flag.value = "block_services_del"),
      (cf.anticsrf.value = block_services_del_token),
      cf.submit(),
      !0);
}
function check_block_services_apply(cf) {
  cf.submit_flag.value = "block_services_apply";
  cf.anticsrf.value = block_services_apply_token;
  cf.submit()
  return true;
}
function add_block_services(cf) {
  cf.submit_flag.value = "block_services_session";
  cf.anticsrf.value = block_services_session_token;
  cf.action = "/apply.cgi?/BKS_service_add.htm timestamp=" + ts;
  cf.submit();
  return true
}
