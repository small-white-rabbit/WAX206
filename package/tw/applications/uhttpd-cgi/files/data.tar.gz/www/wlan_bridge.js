if (1 == getTop(window).an_router_flag)
  var Africa = 1,
    Asia = 2,
    Australia = 3,
    Canada = 4,
    China = 5,
    Europe = 6,
    India = 7,
    Israel = 8,
    Japan = 9,
    Korea = 10,
    Malaysia = 11,
    Mexico = 12,
    Middle_East_Algeria_Syria_Yemen = 13,
    Middle_East_Iran_Lebanon_Qatar = 14,
    Middle_East_Turkey_Egypt_Tunisia_Kuwait = 15,
    Middle_East_Saudi_Arabia = 16,
    Middle_East_United_Arab_Emirates = 17,
    Middle_East = -1,
    Russia = 18,
    Singapore = 19,
    South_America = 20,
    Taiwan = 21,
    United_States = 22;
else
  (Africa = 1),
    (Asia = 2),
    (Australia = 3),
    (Canada = -1),
    (China = -1),
    (Europe = 4),
    (India = -1),
    (Israel = 5),
    (Japan = 6),
    (Korea = 7),
    (Malaysia = -1),
    (Mexico = 9),
    (Middle_East_Algeria_Syria_Yemen = -1),
    (Middle_East_Iran_Lebanon_Qatar = -1),
    (Middle_East_Turkey_Egypt_Tunisia_Kuwait = -1),
    (Middle_East_Saudi_Arabia = -1),
    (Middle_East_United_Arab_Emirates = -1),
    (Middle_East = 10),
    (Russia = 11),
    (Singapore = -1),
    (South_America = 12),
    (Taiwan = -1),
    (United_States = 8);
function getObj(name) {
  return document.getElementById
    ? document.getElementById(name)
    : document.all
    ? document.all[name]
    : document.layers
    ? document.layers[name]
    : void 0;
}
function changekeylen(form) {
  1 == form.wepenc.options[0].selected
    ? ((form.KEY1.size = form.KEY2.size = form.KEY3.size = form.KEY4.size = 12),
      (form.KEY1.value = wep_64_key1),
      (form.KEY2.value = wep_64_key2),
      (form.KEY3.value = wep_64_key3),
      (form.KEY4.value = wep_64_key4))
    : ((form.KEY1.size = form.KEY2.size = form.KEY3.size = form.KEY4.size = 28),
      (form.KEY1.value = wep_128_key1),
      (form.KEY2.value = wep_128_key2),
      (form.KEY3.value = wep_128_key3),
      (form.KEY4.value = wep_128_key4)),
    (form.generate_flag.value = 0);
}
function changekeylen_a(form) {
  1 == form.wepenc_an.options[0].selected
    ? ((form.KEY1_an.size = form.KEY2_an.size = form.KEY3_an.size = form.KEY4_an.size = 12),
      (form.KEY1_an.value = wep_64_key1_a),
      (form.KEY2_an.value = wep_64_key2_a),
      (form.KEY3_an.value = wep_64_key3_a),
      (form.KEY4_an.value = wep_64_key4_a))
    : ((form.KEY1_an.size = form.KEY2_an.size = form.KEY3_an.size = form.KEY4_an.size = 28),
      (form.KEY1_an.value = wep_128_key1_a),
      (form.KEY2_an.value = wep_128_key2_a),
      (form.KEY3_an.value = wep_128_key3_a),
      (form.KEY4_an.value = wep_128_key4_a)),
    (form.generate_flag.value = 0);
}
function opmode_disabled() {
  (document.getElementById("opmode_all").style.display = "none"),
    (document.getElementById("opmode_54").style.display = "");
}
function setSecurity(num) {
  var form = document.forms[0];
  if (
    ((form.wpa1_press_flag.value = 0),
    (form.wpa2_press_flag.value = 0),
    (form.wpas_press_flag.value = 0),
    2 == num)
  ) {
    (getObj("view").innerHTML = str_wep), changekeylen(form);
    var keyno = wl_get_keyno,
      keylength = wl_get_keylength;
    parseInt(keyno) > 0 && (form.wep_key_no[parseInt(keyno) - 1].checked = !0),
      (form.KEY1.value = wl_key1),
      (form.KEY2.value = wl_key2),
      (form.KEY3.value = wl_key3),
      (form.KEY4.value = wl_key4),
      (form.old_length.value = keylength);
  } else
    3 == num
      ? (getObj("view").innerHTML = str_wpa)
      : 4 == num
      ? (getObj("view").innerHTML = str_wpa2)
      : 5 == num
      ? (getObj("view").innerHTML = str_wpas)
      : 6 == num
      ? ((getObj("view").innerHTML = str_wpae),
        (form.wpae_mode.value = get_wpae_mode),
        "" != get_radiusSerIp &&
          "0.0.0.0" != get_radiusSerIp &&
          ((radiusIPArray = get_radiusSerIp.split(".")),
          (form.radiusIPAddr1.value = radiusIPArray[0]),
          (form.radiusIPAddr2.value = radiusIPArray[1]),
          (form.radiusIPAddr3.value = radiusIPArray[2]),
          (form.radiusIPAddr4.value = radiusIPArray[3])),
        (form.textWpaeRadiusPort.value = get_radiusPort))
      : (getObj("view").innerHTML = str_none);
}
function opmode_an_disabled() {
  (document.getElementById("opmode_an_all").style.display = "none"),
    (document.getElementById("opmode_an_54").style.display = "");
}
function opmode_an_abled() {
  (document.getElementById("opmode_an_all").style.display = ""),
    (document.getElementById("opmode_an_54").style.display = "none");
}
function setSecurity_an(num) {
  var form = document.forms[0];
  if (
    ((form.wla_wpa1_press_flag.value = 0),
    (form.wla_wpa2_press_flag.value = 0),
    (form.wla_wpas_press_flag.value = 0),
    2 == num)
  ) {
    (getObj("view_a").innerHTML = str_wep_an), changekeylen_a(form);
    var keyno = wla_get_keyno,
      keylength = wla_get_keylength;
    parseInt(keyno) > 0 &&
      (form.wep_key_no_an[parseInt(keyno) - 1].checked = !0),
      (form.KEY1_an.value = wla_key1),
      (form.KEY2_an.value = wla_key2),
      (form.KEY3_an.value = wla_key3),
      (form.KEY4_an.value = wla_key4),
      (form.old_length_a.value = keylength);
  } else
    3 == num
      ? (getObj("view_a").innerHTML = str_wpa_an)
      : 4 == num
      ? (getObj("view_a").innerHTML = str_wpa2_an)
      : 5 == num
      ? (getObj("view_a").innerHTML = str_wpas_an)
      : 6 == num
      ? ((getObj("view_a").innerHTML = str_wpae_an),
        (form.wpae_mode_an.value = get_wpae_mode_a),
        "" != get_radiusSerIp_a &&
          "0.0.0.0" != get_radiusSerIp_a &&
          ((radiusIPArray = get_radiusSerIp_a.split(".")),
          (form.radiusIPAddr1_an.value = radiusIPArray[0]),
          (form.radiusIPAddr2_an.value = radiusIPArray[1]),
          (form.radiusIPAddr3_an.value = radiusIPArray[2]),
          (form.radiusIPAddr4_an.value = radiusIPArray[3])),
        (form.textWpaeRadiusPort_an.value = get_radiusPort_a))
      : (getObj("view_a").innerHTML = str_none_an);
}
function wl_sectype_change() {
  1 == document.forms[0].opmode.options[0].selected
    ? (document.getElementById("wep_54").style.display = "")
    : (document.getElementById("wep_54").style.display = "none");
}
function wl_54_sectype_change() {
  document.forms[0];
  (document.getElementById("wep_54").style.display = ""),
    (document.getElementById("wpa_psk_54").style.display = "");
}
function wla_sectype_change() {
  "1" == document.forms[0].opmode_an.value
    ? (document.getElementById("wep_an_54").style.display = "")
    : (document.getElementById("wep_an_54").style.display = "none");
}
function wla_54_sectype_change() {
  document.forms[0];
  (document.getElementById("wep_an_54").style.display = ""),
    (document.getElementById("wpa_psk_an_54").style.display = "");
}
function wpaemode() {
  document.forms[0];
  (document.getElementById("opmode_all").style.display = ""),
    (document.getElementById("opmode_54").style.display = "none"),
    wl_sectype_change();
}
function wpaemode_an() {
  document.forms[0];
  (document.getElementById("opmode_an_all").style.display = ""),
    (document.getElementById("opmode_an_54").style.display = "none"),
    wla_sectype_change();
}
function check_dfs() {
  var channel_info,
    cf = document.forms[0],
    each_info = dfs_info.split(":"),
    channel = cf.w_channel_an,
    ch_index = channel.selectedIndex,
    ch_name = channel.options[ch_index].text,
    ch_value = channel.options[ch_index].value;
  if (-1 == ch_name.indexOf("(DFS)")) return !0;
  for (i = 0; i < each_info.length; i++) {
    var sec = (channel_info = each_info[i].split(" "))[3] % 60,
      min = parseInt(channel_info[3] / 60);
    if (ch_value == channel_info[0])
      return (
        alert("$using_dfs_1" + min + "$using_dfs_2" + sec + "$using_dfs_3"), !1
      );
  }
  return 0 != confirm("$select_dfs");
}
function chgCh(from) {
  if (2 == from) {
    document.forms[0];
    setChannel();
  } else setwlan_mode(), setChannel();
}
function setwlan_mode() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var currentMode = cf.opmode.selectedIndex;
  index == Africa ||
  index == Israel ||
  index == Middle_East_Turkey_Egypt_Tunisia_Kuwait ||
  index == Middle_East_Saudi_Arabia
    ? ((cf.opmode.options.length = 2),
      (cf.opmode.options[0].text = wlan_mode_54),
      (cf.opmode.options[1].text = wlan_mode_130),
      (cf.opmode.options[0].value = "1"),
      (cf.opmode.options[1].value = "2"),
      (cf.opmode.selectedIndex = currentMode <= 1 ? currentMode : 1))
    : ((cf.opmode.options.length = 3),
      (cf.opmode.options[0].text = wlan_mode_54),
      (cf.opmode.options[1].text = wlan_mode_130),
      (cf.opmode.options[2].text = wlan_mode_300),
      (cf.opmode.options[0].value = "1"),
      (cf.opmode.options[1].value = "2"),
      (cf.opmode.options[2].value = "3"),
      (cf.opmode.selectedIndex = currentMode));
}
function setChannel() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var endChannel,
    chIndex = cf.w_channel.selectedIndex;
  cf.opmode.selectedIndex;
  (endChannel = FinishChannel[index]),
    14 == FinishChannel[index] && 0 != cf.opmode.selectedIndex
      ? (cf.w_channel.options.length = endChannel - StartChannel[index])
      : (cf.w_channel.options.length = endChannel - StartChannel[index] + 2),
    (cf.w_channel.options[0].text = "$auto_mark"),
    (cf.w_channel.options[0].value = 0);
  for (var i = StartChannel[index]; i <= endChannel; i++)
    (14 == i && 0 != cf.opmode.selectedIndex) ||
      ((cf.w_channel.options[i - StartChannel[index] + 1].value = i),
      (cf.w_channel.options[i - StartChannel[index] + 1].text =
        i < 10 ? "0" + i : i));
  cf.w_channel.selectedIndex =
    chIndex > -1 && chIndex < cf.w_channel.options.length ? chIndex : 0;
}
function setBChannel() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var endChannel,
    chIndex = cf.w_channel.selectedIndex;
  cf.opmode.selectedIndex;
  (endChannel = FinishChannelB[index]),
    14 == FinishChannelB[index] && 0 != cf.opmode.selectedIndex
      ? (cf.w_channel.options.length = endChannel - StartChannelB[index])
      : (cf.w_channel.options.length = endChannel - StartChannelB[index] + 2),
    (cf.w_channel.options[0].text = "$auto_mark"),
    (cf.w_channel.options[0].value = 0);
  for (var i = StartChannelB[index]; i <= endChannel; i++)
    (14 == i && 0 != cf.opmode.selectedIndex) ||
      ((cf.w_channel.options[i - StartChannelB[index] + 1].value = i),
      (cf.w_channel.options[i - StartChannelB[index] + 1].text =
        i < 10 ? "0" + i : i));
  cf.w_channel.selectedIndex =
    chIndex > -1 && chIndex < cf.w_channel.options.length ? chIndex : 0;
}
function chgChA(from) {
  var cf = document.forms[0];
  2 == from
    ? setAChannel(cf.w_channel_an)
    : (setAwlan_mode(), setAChannel(cf.w_channel_an));
}
function setAwlan_mode() {
  1 == ac_router_flag ? setACwlan_mode() : setANwlan_mode();
}
function setACwlan_mode() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var currentMode = cf.opmode_an.selectedIndex;
  index == Africa ||
  index == Israel ||
  index == Middle_East_Turkey_Egypt_Tunisia_Kuwait ||
  index == Middle_East_Saudi_Arabia
    ? ((cf.opmode_an.options.length = 1),
      (cf.opmode_an.options[0].text = wlan_mode_192),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.selectedIndex = currentMode <= 0 ? currentMode : 0),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : index == Middle_East_Algeria_Syria_Yemen
    ? ((cf.w_channel_an.selectedIndex = 0),
      (cf.w_channel_an.disabled = !0),
      (cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = wlan_mode_192),
      (cf.opmode_an.options[1].text = wlan_mode_400),
      (cf.opmode_an.options[2].text = wlan_mode_867),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.options[2].value = "9"),
      (cf.opmode_an.disabled = !0))
    : index == Korea || index == Russia
    ? ((cf.opmode_an.options.length = 2),
      (cf.opmode_an.options[0].text = wlan_mode_192),
      (cf.opmode_an.options[1].text = wlan_mode_400),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.selectedIndex = currentMode <= 1 ? currentMode : 0),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : ((cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = wlan_mode_192),
      (cf.opmode_an.options[1].text = wlan_mode_400),
      (cf.opmode_an.options[2].text = wlan_mode_867),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.options[2].value = "9"),
      (cf.opmode_an.selectedIndex = currentMode),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1));
}
function setANwlan_mode() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var currentMode = cf.opmode_an.selectedIndex;
  index == Africa ||
  index == Israel ||
  index == Middle_East_Turkey_Egypt_Tunisia_Kuwait ||
  index == Middle_East_Saudi_Arabia
    ? ((cf.opmode_an.options.length = 2),
      (cf.opmode_an.options[0].text = wlan_mode_54),
      (cf.opmode_an.options[1].text = wlan_mode_130),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.selectedIndex = currentMode <= 1 ? currentMode : 1),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : index == Middle_East_Algeria_Syria_Yemen
    ? ((cf.w_channel_an.selectedIndex = 0),
      (cf.w_channel_an.disabled = !0),
      (cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = wlan_mode_54),
      (cf.opmode_an.options[1].text = wlan_mode_130),
      (cf.opmode_an.options[2].text = wlan_mode_300),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.options[2].value = "3"),
      (cf.opmode_an.disabled = !0))
    : (1 == ac_router_flag
        ? ((cf.opmode_an.options.length = 4),
          (cf.opmode_an.options[3].text = wlan_mode_867),
          (cf.opmode_an.options[3].value = "9"))
        : (cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = wlan_mode_54),
      (cf.opmode_an.options[1].text = wlan_mode_130),
      (cf.opmode_an.options[2].text = wlan_mode_300),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.options[2].value = "3"),
      (cf.opmode_an.selectedIndex = currentMode),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1));
}
function setAChannel(channel) {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex,
    option_array = document.getElementById("select_channel_an").options,
    select_region = parseInt(index, 10) + 1;
  parseInt(wl_get_countryA, 10);
  index = select_region;
  var endChannel,
    chIndex = channel.selectedIndex,
    chValue = channel.options[chIndex].value,
    currentMode = cf.opmode_an.value;
  if (1 == dfs_channel_router_flag) {
    var AChannel = new Array(
      0,
      36,
      40,
      44,
      48,
      52,
      56,
      60,
      64,
      100,
      104,
      108,
      112,
      116,
      120,
      124,
      128,
      132,
      136,
      140,
      149,
      153,
      157,
      161,
      165
    );
    if (
      ((channel.options[0].text = "$auto_mark"),
      (channel.options[0].value = 0),
      index == Korea)
    ) {
      for (
        endChannel = 16, channel.options.length = 21, i = 1;
        i <= endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          i > 4
            ? (channel.options[i].text = AChannel[i] + "(DFS)")
            : (channel.options[i].text = AChannel[i]);
      (channel.options[17].value = channel.options[17].text = 149),
        (channel.options[18].value = channel.options[18].text = 153),
        (channel.options[19].value = channel.options[19].text = 157),
        (channel.options[20].value = channel.options[20].text = 161);
    } else if (index == Africa) {
      for (
        endChannel = 13, channel.options.length = 16, i = 1;
        i <= endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          i > 4
            ? (channel.options[i].text = AChannel[i] + "(DFS)")
            : (channel.options[i].text = AChannel[i]);
      (channel.options[14].value = 136),
        (channel.options[14].text = "136(DFS)"),
        (channel.options[15].value = 140),
        (channel.options[15].text = "140(DFS)");
    } else if (index == Asia || index == South_America)
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = AChannel.length, i = 1;
          i < AChannel.length;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            i > 4 && i < 20
              ? (channel.options[i].text = AChannel[i] + "(DFS)")
              : (channel.options[i].text = AChannel[i]);
      else {
        for (
          channel.options.length = 23, i = 1;
          i <= channel.options.length - 4;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            i > 4
              ? (channel.options[i].text = AChannel[i] + "(DFS)")
              : (channel.options[i].text = AChannel[i]);
        (channel.options[19].value = channel.options[19].text = 149),
          (channel.options[20].value = channel.options[20].text = 153),
          (channel.options[21].value = channel.options[21].text = 157),
          (channel.options[22].value = channel.options[22].text = 161);
      }
    else if (index == Australia)
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = 22, i = 1;
          i < channel.options.length;
          i++
        )
          i > 13 ? (j = i + 3) : (j = i),
            (channel.options[i].value = AChannel[j]),
            i > 4 && i < 17
              ? (channel.options[i].text = AChannel[j] + "(DFS)")
              : (channel.options[i].text = AChannel[j]);
      else {
        for (
          channel.options.length = 19, i = 1;
          i < channel.options.length - 6;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            i > 4
              ? (channel.options[i].text = AChannel[i] + "(DFS)")
              : (channel.options[i].text = AChannel[i]);
        (channel.options[13].value = 132),
          (channel.options[13].text = "132(DFS)"),
          (channel.options[14].value = 136),
          (channel.options[14].text = "136(DFS)"),
          (channel.options[15].value = channel.options[15].text = 149),
          (channel.options[16].value = channel.options[16].text = 153),
          (channel.options[17].value = channel.options[17].text = 157),
          (channel.options[18].value = channel.options[18].text = 161);
      }
    else if (index == Canada || index == United_States)
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = 21, i = 1;
          i < channel.options.length;
          i++
        )
          i > 13 ? (j = i + 4) : (j = i),
            (channel.options[i].value = AChannel[j]),
            i > 4 && i < 16
              ? (channel.options[i].text = AChannel[j] + "(DFS)")
              : (channel.options[i].text = AChannel[j]);
      else {
        for (
          channel.options.length = 17, i = 1;
          i < channel.options.length - 4;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            i > 4
              ? (channel.options[i].text = AChannel[i] + "(DFS)")
              : (channel.options[i].text = AChannel[i]);
        (channel.options[13].value = channel.options[13].text = 149),
          (channel.options[14].value = channel.options[14].text = 153),
          (channel.options[15].value = channel.options[15].text = 157),
          (channel.options[16].value = channel.options[16].text = 161);
      }
    else if (
      index == India ||
      index == Mexico ||
      index == Malaysia ||
      index == Middle_East_Saudi_Arabia ||
      index == Singapore
    )
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = 14, i = 1;
          i < channel.options.length;
          i++
        )
          i > 8 ? (j = i + 11) : (j = i),
            (channel.options[i].value = AChannel[j]),
            i > 4 && i < 9
              ? (channel.options[i].text = AChannel[j] + "(DFS)")
              : (channel.options[i].text = AChannel[j]);
      else
        (channel.options.length = 13),
          (channel.options[1].value = channel.options[1].text = 36),
          (channel.options[2].value = channel.options[2].text = 40),
          (channel.options[3].value = channel.options[3].text = 44),
          (channel.options[4].value = channel.options[4].text = 48),
          (channel.options[5].value = 52),
          (channel.options[5].text = "52(DFS)"),
          (channel.options[6].value = 56),
          (channel.options[6].text = "56(DFS)"),
          (channel.options[7].value = 60),
          (channel.options[7].text = "60(DFS)"),
          (channel.options[8].value = 64),
          (channel.options[8].text = "64(DFS)"),
          (channel.options[9].value = channel.options[9].text = 149),
          (channel.options[10].value = channel.options[10].text = 153),
          (channel.options[11].value = channel.options[11].text = 157),
          (channel.options[12].value = channel.options[12].text = 161);
    else if (index == China || index == Middle_East_Iran_Lebanon_Qatar)
      1 == currentMode || 2 == currentMode || 7 == currentMode
        ? ((channel.options.length = 6),
          (channel.options[1].value = channel.options[1].text = 149),
          (channel.options[2].value = channel.options[2].text = 153),
          (channel.options[3].value = channel.options[3].text = 157),
          (channel.options[4].value = channel.options[4].text = 161),
          (channel.options[5].value = channel.options[5].text = 165))
        : ((channel.options.length = 5),
          (channel.options[1].value = channel.options[1].text = 149),
          (channel.options[2].value = channel.options[2].text = 153),
          (channel.options[3].value = channel.options[3].text = 157),
          (channel.options[4].value = channel.options[4].text = 161));
    else if (
      index == Europe ||
      index == Japan ||
      index == Middle_East_United_Arab_Emirates
    )
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = 20, i = 1;
          i < channel.options.length;
          i++
        )
          (j = i),
            (channel.options[i].value = AChannel[j]),
            i > 4
              ? (channel.options[i].text = AChannel[j] + "(DFS)")
              : (channel.options[i].text = AChannel[j]);
      else
        for (
          channel.options.length = 19, i = 1;
          i < channel.options.length;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            i > 4
              ? (channel.options[i].text = AChannel[i] + "(DFS)")
              : (channel.options[i].text = AChannel[i]);
    else if (
      index == Israel ||
      index == Middle_East_Turkey_Egypt_Tunisia_Kuwait
    )
      for (channel.options.length = 9, i = 1; i < channel.options.length; i++)
        (j = i),
          (channel.options[i].value = AChannel[j]),
          i > 4
            ? (channel.options[i].text = AChannel[j] + "(DFS)")
            : (channel.options[i].text = AChannel[j]);
    else if (index == Russia)
      for (
        endChannel = 5, channel.options.length = 5, i = 1;
        i < endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          (channel.options[i].text = AChannel[i]);
    else if (index == Taiwan)
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          channel.options.length = 20, i = 1;
          i < channel.options.length;
          i++
        )
          (j = i + 5),
            (channel.options[i].value = AChannel[j]),
            i > 3 && i < 15
              ? (channel.options[i].text = AChannel[j] + "(DFS)")
              : (channel.options[i].text = AChannel[j]);
      else
        (channel.options.length = 17),
          (channel.options[1].value = channel.options[1].text = 60),
          (channel.options[2].value = channel.options[2].text = 64),
          (channel.options[3].value = 100),
          (channel.options[3].text = "100(DFS)"),
          (channel.options[4].value = 104),
          (channel.options[4].text = "104(DFS)"),
          (channel.options[5].value = 108),
          (channel.options[5].text = "108(DFS)"),
          (channel.options[6].value = 112),
          (channel.options[6].text = "112(DFS)"),
          (channel.options[7].value = 116),
          (channel.options[7].text = "116(DFS)"),
          (channel.options[8].value = 120),
          (channel.options[8].text = "120(DFS)"),
          (channel.options[9].value = 124),
          (channel.options[9].text = "124(DFS)"),
          (channel.options[10].value = 128),
          (channel.options[10].text = "128(DFS)"),
          (channel.options[11].value = 132),
          (channel.options[11].text = "132(DFS)"),
          (channel.options[12].value = 136),
          (channel.options[12].text = "136(DFS)"),
          (channel.options[13].value = channel.options[13].text = 149),
          (channel.options[14].value = channel.options[14].text = 153),
          (channel.options[15].value = channel.options[15].text = 157),
          (channel.options[16].value = channel.options[16].text = 161);
  } else {
    AChannel = new Array(36, 40, 44, 48, 149, 153, 157, 161, 165);
    var BChannel = new Array(
      36,
      40,
      44,
      48,
      52,
      56,
      60,
      64,
      100,
      104,
      108,
      112,
      116,
      120,
      124,
      128,
      132,
      136,
      140,
      149,
      153,
      157,
      161,
      165
    );
    if (
      index == Asia ||
      index == Australia ||
      index == Canada ||
      index == India ||
      index == Malaysia ||
      index == Mexico ||
      index == Singapore ||
      index == South_America ||
      index == United_States
    )
      if (1 == currentMode || 2 == currentMode || 7 == currentMode)
        for (
          endChannel = 9, channel.options.length = 9, i = 0;
          i < endChannel;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            (channel.options[i].text = AChannel[i]);
      else
        for (
          endChannel = 8, channel.options.length = 8, i = 0;
          i < channel.options.length;
          i++
        )
          (channel.options[i].value = AChannel[i]),
            (channel.options[i].text = AChannel[i]);
    else if (index == Korea)
      for (
        endChannel = 8, channel.options.length = 8, i = 0;
        i < endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          (channel.options[i].text = AChannel[i]);
    else if (index == China || index == Middle_East_Iran_Lebanon_Qatar)
      1 == currentMode || 2 == currentMode || 7 == currentMode
        ? ((channel.options.length = 5),
          (channel.options[0].value = channel.options[0].text = 149),
          (channel.options[1].value = channel.options[1].text = 153),
          (channel.options[2].value = channel.options[2].text = 157),
          (channel.options[3].value = channel.options[3].text = 161),
          (channel.options[4].value = channel.options[4].text = 165))
        : ((channel.options.length = 4),
          (channel.options[0].value = channel.options[0].text = 149),
          (channel.options[1].value = channel.options[1].text = 153),
          (channel.options[2].value = channel.options[2].text = 157),
          (channel.options[3].value = channel.options[3].text = 161));
    else if (index == Middle_East_Saudi_Arabia)
      for (
        endChannel = 9, channel.options.length = 9, i = 0;
        i < endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          (channel.options[i].text = AChannel[i]);
    else if (index == Taiwan)
      1 == currentMode || 2 == currentMode || 7 == currentMode
        ? ((channel.options.length = 8),
          (channel.options[0].value = channel.options[0].text = 56),
          (channel.options[1].value = channel.options[1].text = 60),
          (channel.options[2].value = channel.options[2].text = 64),
          (channel.options[3].value = channel.options[3].text = 149),
          (channel.options[4].value = channel.options[4].text = 153),
          (channel.options[5].value = channel.options[5].text = 157),
          (channel.options[6].value = channel.options[6].text = 161),
          (channel.options[7].value = channel.options[7].text = 165))
        : 9 == currentMode
        ? ((channel.options.length = 4),
          (channel.options[0].value = channel.options[0].text = 149),
          (channel.options[1].value = channel.options[1].text = 153),
          (channel.options[2].value = channel.options[2].text = 157),
          (channel.options[3].value = channel.options[3].text = 161))
        : ((channel.options.length = 6),
          (channel.options[0].value = channel.options[0].text = 60),
          (channel.options[1].value = channel.options[1].text = 64),
          (channel.options[2].value = channel.options[2].text = 149),
          (channel.options[3].value = channel.options[3].text = 153),
          (channel.options[4].value = channel.options[4].text = 157),
          (channel.options[5].value = channel.options[5].text = 161));
    else
      for (
        endChannel = 4, channel.options.length = 4, i = 0;
        i < endChannel;
        i++
      )
        (channel.options[i].value = AChannel[i]),
          (channel.options[i].text = AChannel[i]);
    if (1 == dfs_channel2_router_flag)
      if (index == Europe)
        if (1 == currentMode || 2 == currentMode || 7 == currentMode) {
          for (endChannel = 19, channel.options.length = 19, i = 0; i < 4; i++)
            (channel.options[i].value = BChannel[i]),
              (channel.options[i].text = BChannel[i]);
          for (i = 4; i < endChannel; i++)
            (channel.options[i].value = BChannel[i]),
              (channel.options[i].text = BChannel[i] + "(DFS)");
        } else
          for (
            channel.options.length = 18, i = 0;
            i < channel.options.length;
            i++
          )
            (channel.options[i].value = BChannel[i]),
              i > 3
                ? (channel.options[i].text = BChannel[i] + "(DFS)")
                : (channel.options[i].text = BChannel[i]);
      else if (index == Australia)
        if (1 == currentMode || 2 == currentMode || 7 == currentMode) {
          for (endChannel = 12, channel.options.length = 21, i = 0; i < 4; i++)
            (channel.options[i].value = BChannel[i]),
              (channel.options[i].text = BChannel[i]);
          for (i = 4; i < endChannel; i++)
            (channel.options[i].value = BChannel[i]),
              (channel.options[i].text = BChannel[i] + "(DFS)");
          (channel.options[12].value = 116),
            (channel.options[13].value = 132),
            (channel.options[14].value = 136),
            (channel.options[15].value = 140),
            (channel.options[12].text = 116 + "(DFS)"),
            (channel.options[13].text = 132 + "(DFS)"),
            (channel.options[14].text = 136 + "(DFS)"),
            (channel.options[15].text = 140 + "(DFS)"),
            (channel.options[16].value = channel.options[16].text = 149),
            (channel.options[17].value = channel.options[17].text = 153),
            (channel.options[18].value = channel.options[18].text = 157),
            (channel.options[19].value = channel.options[19].text = 161),
            (channel.options[20].value = channel.options[20].text = 165);
        } else {
          for (
            channel.options.length = 18, i = 0;
            i < channel.options.length - 6;
            i++
          )
            (channel.options[i].value = BChannel[i]),
              i > 3
                ? (channel.options[i].text = BChannel[i] + "(DFS)")
                : (channel.options[i].text = BChannel[i]);
          (channel.options[12].value = 132),
            (channel.options[12].text = "132(DFS)"),
            (channel.options[13].value = 136),
            (channel.options[13].text = "136(DFS)"),
            (channel.options[14].value = channel.options[14].text = 149),
            (channel.options[15].value = channel.options[15].text = 153),
            (channel.options[16].value = channel.options[16].text = 157),
            (channel.options[17].value = channel.options[17].text = 161);
        }
  }
  var find_value = 0;
  for (i = 0; i < option_array.length; i++)
    if (option_array[i].value == chValue) {
      (find_value = 1), (channel.selectedIndex = i);
      break;
    }
  if (0 == find_value)
    for (i = 0; i < option_array.length; i++)
      if (option_array[i].value == wla_get_channel) {
        (find_value = 1), (channel.selectedIndex = i);
        break;
      }
  0 == find_value && (channel.selectedIndex = 0);
}
function check_wlan() {
  var cf = document.forms[0],
    ssid_bgn = document.forms[0].ssid.value,
    ssid_an = document.forms[0].ssid_an.value;
  document.forms[0].wla1ssid.value, document.forms[0].wlg1ssid.value;
  if (((cf.wl_ssid.value = ssid_bgn), 0 == cf.bridge_sec_type.selectedIndex)) {
    if ("" == ssid_bgn) return alert("$ssid_null"), !1;
    for (i = 0; i < ssid_bgn.length; i++)
      if (0 == isValidChar_space(ssid_bgn.charCodeAt(i)))
        return alert("$ssid_not_allowed"), !1;
    if (
      ((cf.hid_bridge_sec_type.value = 24), 1 == cf.security_type[1].checked)
    ) {
      if (0 == checkwep(cf)) return !1;
      cf.wl_hidden_sec_type.value = 2;
    } else if (1 == cf.security_type[2].checked) {
      if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
      (cf.wl_hidden_sec_type.value = 3),
        (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
    } else if (1 == cf.security_type[3].checked) {
      if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
      (cf.wl_hidden_sec_type.value = 4),
        (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
    } else if (1 == cf.security_type[4].checked) {
      if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
      (cf.wl_hidden_sec_type.value = 5),
        (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
    } else if (1 == cf.security_type[5].checked) {
      if (
        ((radiusServerIP =
          cf.radiusIPAddr1.value +
          "." +
          cf.radiusIPAddr2.value +
          "." +
          cf.radiusIPAddr3.value +
          "." +
          cf.radiusIPAddr4.value),
        "" == radiusServerIP || 0 == checkipaddr(radiusServerIP))
      )
        return alert("$invalid_ip"), !1;
      if (1 == isSameIp(lanIP, radiusServerIP)) return alert("$invalid_ip"), !1;
      if (1 == isSameIp(wanIP, radiusServerIP))
        return alert("$conflicted_with_wanip"), !1;
      if (
        ((cf.radiusServerIP.value = radiusServerIP),
        (radiusPort = parseInt(cf.textWpaeRadiusPort.value, 10)),
        isNaN(radiusPort) || radiusPort < 1 || radiusPort > 65535)
      )
        return alert("$radiusPort65535"), !1;
      if (
        ((cf.textWpaeRadiusPort.value = radiusPort),
        "" == cf.textWpaeRadiusSecret.value)
      )
        return alert("$radiusSecret128"), !1;
      if (cf.textWpaeRadiusSecret.length > 128)
        return alert("$radiusSecret128"), !1;
      for (i = 0; i < cf.textWpaeRadiusSecret.value.length; i++)
        if (0 == isValidChar(cf.textWpaeRadiusSecret.value.charCodeAt(i)))
          return alert("$radiusSecret128"), cf.textWpaeRadiusSecret.focus(), !1;
      (cf.hidden_WpaeRadiusSecret.value = cf.textWpaeRadiusSecret.value),
        (cf.wl_hidden_sec_type.value = 6),
        (cf.textWpaeRadiusPort.value = port_range_interception(
          cf.textWpaeRadiusPort.value
        ));
    } else cf.wl_hidden_sec_type.value = 1;
  } else if (((cf.hid_bridge_sec_type.value = 5), 1 == an_router_flag)) {
    if (((cf.wla_ssid.value = ssid_an), "" == ssid_an))
      return alert("$ssid_null"), !1;
    for (i = 0; i < ssid_bgn.length; i++)
      if (0 == isValidChar_space(ssid_an.charCodeAt(i)))
        return alert("$ssid_not_allowed"), !1;
    if (1 == cf.security_type_an[1].checked) {
      if (0 == checkwep_a(cf)) return !1;
      cf.wla_hidden_sec_type.value = 2;
    } else if (1 == cf.security_type_an[2].checked) {
      if (0 == checkpsk(cf.passphrase_an, cf.wla_sec_wpaphrase_len)) return !1;
      (cf.wla_hidden_sec_type.value = 3),
        (cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value);
    } else if (1 == cf.security_type_an[3].checked) {
      if (0 == checkpsk(cf.passphrase_an, cf.wla_sec_wpaphrase_len)) return !1;
      (cf.wla_hidden_sec_type.value = 4),
        (cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value);
    } else if (1 == cf.security_type_an[4].checked) {
      if (0 == checkpsk(cf.passphrase_an, cf.wla_sec_wpaphrase_len)) return !1;
      (cf.wla_hidden_sec_type.value = 5),
        (cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value);
    } else if (1 == cf.security_type_an[5].checked) {
      if (
        ((radiusServerIP =
          cf.radiusIPAddr1_an.value +
          "." +
          cf.radiusIPAddr2_an.value +
          "." +
          cf.radiusIPAddr3_an.value +
          "." +
          cf.radiusIPAddr4_an.value),
        "" == radiusServerIP || 0 == checkipaddr(radiusServerIP))
      )
        return alert("$invalid_ip"), !1;
      if (1 == isSameIp(lanIP, radiusServerIP)) return alert("$invalid_ip"), !1;
      if (1 == isSameIp(wanIP, radiusServerIP))
        return alert("$conflicted_with_wanip"), !1;
      if (
        ((cf.radiusServerIP_a.value = radiusServerIP),
        (radiusPort = parseInt(cf.textWpaeRadiusPort_an.value, 10)),
        isNaN(radiusPort) || radiusPort < 1 || radiusPort > 65535)
      )
        return alert("$radiusPort65535"), !1;
      if (
        ((cf.textWpaeRadiusPort_an.value = radiusPort),
        "" == cf.textWpaeRadiusSecret_an.value)
      )
        return alert("$radiusSecret128"), !1;
      if (cf.textWpaeRadiusSecret_an.length > 128)
        return alert("$radiusSecret128"), !1;
      for (i = 0; i < cf.textWpaeRadiusSecret_an.value.length; i++)
        if (0 == isValidChar(cf.textWpaeRadiusSecret_an.value.charCodeAt(i)))
          return (
            alert("$radiusSecret128"), cf.textWpaeRadiusSecret_an.focus(), !1
          );
      (cf.hidden_WpaeRadiusSecret_a.value = cf.textWpaeRadiusSecret_an.value),
        (cf.textWpaeRadiusPort_an.value = port_range_interception(
          cf.textWpaeRadiusPort_an.value
        )),
        (cf.wla_hidden_sec_type.value = 6);
    } else cf.wla_hidden_sec_type.value = 1;
  }
  (opener.opener_apply_click = 1), cf.submit();
}
