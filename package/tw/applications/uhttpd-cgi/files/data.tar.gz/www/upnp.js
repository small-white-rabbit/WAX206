function click_upnp(time, timelive) {
  1 == document.forms[0].UpnP.checked
    ? ((document.forms[0].AdverTime.disabled = !1),
      (document.forms[0].TimeToLive.disabled = !1),
      "" == time
        ? (document.forms[0].AdverTime.value = "")
        : ((time_value = parseInt(time)),
          (time_value /= 60),
          (document.forms[0].AdverTime.value = time_value)),
      (document.forms[0].TimeToLive.value = timelive))
    : ((document.forms[0].AdverTime.disabled = !0),
      (document.forms[0].TimeToLive.disabled = !0),
      "" == time
        ? (document.forms[0].AdverTime.value = "")
        : ((time_value = parseInt(time)),
          (time_value /= 60),
          (document.forms[0].AdverTime.value = time_value)),
      (document.forms[0].TimeToLive.value = timelive)),
    (document.forms[0].hidden_advertime.value = time_value),
    (document.forms[0].hidden_timetolive.value = parseInt(timelive, 10));
}
function checkupnp() {
  if (
    (1 == document.forms[0].UpnP.checked
      ? (document.forms[0].upnp_onoff.value = 1)
      : (document.forms[0].upnp_onoff.value = 0),
    1 == document.forms[0].UpnP.checked)
  ) {
    if (
      !(
        document.forms[0].AdverTime.value <= 1440 &&
        document.forms[0].AdverTime.value >= 1
      )
    )
      return alert("$upnp_AdverTime_1_1440"), !1;
    if (
      ((document.forms[0].TimeToLive.value = parseInt(
        document.forms[0].TimeToLive.value,
        10
      )),
      !(
        document.forms[0].TimeToLive.value <= 255 &&
        document.forms[0].TimeToLive.value >= 1
      ))
    )
      return alert("$upnp_TimeToLive_1_255"), !1;
    var second_time = 60 * parseInt(document.forms[0].AdverTime.value, 10);
    document.forms[0].changetime.value = second_time;
  }
  return (
    (document.forms[0].hidden_advertime.value =
      document.forms[0].changetime.value),
    document.forms[0].submit(),
    !0
  );
}
