function BlockAllClickCheck(cf) {
  1 == getTop(window).enable_ap_flag || "1" == enable_extender_flag
    ? ((cf.checkboxNameAll.disabled = !0),
      (cf.checkboxNameMon.disabled = !0),
      (cf.checkboxNameTue.disabled = !0),
      (cf.checkboxNameWed.disabled = !0),
      (cf.checkboxNameThu.disabled = !0),
      (cf.checkboxNameFri.disabled = !0),
      (cf.checkboxNameSat.disabled = !0),
      (cf.checkboxNameSun.disabled = !0))
    : cf.checkboxNameAll.checked
    ? ((cf.checkboxNameMon.checked = !0),
      (cf.checkboxNameTue.checked = !0),
      (cf.checkboxNameWed.checked = !0),
      (cf.checkboxNameThu.checked = !0),
      (cf.checkboxNameFri.checked = !0),
      (cf.checkboxNameSat.checked = !0),
      (cf.checkboxNameSun.checked = !0),
      (cf.checkboxNameMon.disabled = !0),
      (cf.checkboxNameTue.disabled = !0),
      (cf.checkboxNameWed.disabled = !0),
      (cf.checkboxNameThu.disabled = !0),
      (cf.checkboxNameFri.disabled = !0),
      (cf.checkboxNameSat.disabled = !0),
      (cf.checkboxNameSun.disabled = !0))
    : ((cf.checkboxNameMon.disabled = !1),
      (cf.checkboxNameTue.disabled = !1),
      (cf.checkboxNameWed.disabled = !1),
      (cf.checkboxNameThu.disabled = !1),
      (cf.checkboxNameFri.disabled = !1),
      (cf.checkboxNameSat.disabled = !1),
      (cf.checkboxNameSun.disabled = !1)),
    BlockPeriodClick(cf);
}
function BlockPeriodClick(cf) {
  1 == getTop(window).enable_ap_flag || "1" == enable_extender_flag
    ? ((cf.checkboxNamehours.disabled = !0),
      (cf.start_hour.disabled = !0),
      (cf.start_minute.disabled = !0),
      (cf.end_hour.disabled = !0),
      (cf.end_minute.disabled = !0))
    : 1 == cf.checkboxNamehours.checked
    ? ((cf.start_hour.disabled = !0),
      (cf.start_minute.disabled = !0),
      (cf.end_hour.disabled = !0),
      (cf.end_minute.disabled = !0),
      (TimePeriodDisabled = !0),
      ClearData1())
    : ((cf.start_hour.disabled = !1),
      (cf.start_minute.disabled = !1),
      (cf.end_hour.disabled = !1),
      (cf.end_minute.disabled = !1),
      (TimePeriodDisabled = !1));
}
function ClearData1() {
  var cf = document.forms[0];
  (cf.start_hour.value = "0"),
    (cf.start_minute.value = "0"),
    (cf.end_hour.value = "24"),
    (cf.end_minute.value = "0");
}
function check_schedule_apply(cf) {
  var tmp_all_day,
    day_str = "";
  if (
    ((cf = document.forms[0]).checkboxNameAll.checked
      ? (day_str = "everyday")
      : (cf.checkboxNameSun.checked && (day_str += "0,"),
        cf.checkboxNameMon.checked && (day_str += "1,"),
        cf.checkboxNameTue.checked && (day_str += "2,"),
        cf.checkboxNameWed.checked && (day_str += "3,"),
        cf.checkboxNameThu.checked && (day_str += "4,"),
        cf.checkboxNameFri.checked && (day_str += "5,"),
        cf.checkboxNameSat.checked && (day_str += "6,")),
    (cf.days_to_block.value = day_str),
    "" == day_str)
  )
    return alert("$invalid_day"), !1;
  if (1 == cf.checkboxNamehours.checked) tmp_all_day = 1;
  else {
    if (
      ((tmp_all_day = 0),
      cf.start_hour.value == cf.end_hour.value &&
        cf.start_minute.value == cf.end_minute.value)
    )
      return alert("$invalid_time"), !1;
    if (
      !(
        _isNumeric(cf.start_hour.value) &&
        _isNumeric(cf.end_hour.value) &&
        _isNumeric(cf.start_minute.value) &&
        _isNumeric(cf.end_minute.value)
      )
    )
      return alert("$invalid_time"), !1;
    if (
      cf.start_hour.value < 0 ||
      cf.start_hour.value > 23 ||
      cf.end_hour.value < 0 ||
      cf.end_hour.value > 23 ||
      cf.start_minute.value < 0 ||
      cf.start_minute.value > 59 ||
      cf.end_minute.value < 0 ||
      cf.end_minute.value > 59
    ) {
      if (
        !(
          ("24" == cf.start_hour.value && "0" == cf.start_minute.value) ||
          ("24" == cf.start_hour.value && "00" == cf.start_minute.value) ||
          ("24" == cf.end_hour.value && "0" == cf.end_minute.value) ||
          ("24" == cf.end_hour.value && "00" == cf.end_minute.value)
        )
      )
        return alert("$invalid_time"), !1;
      if (
        cf.start_hour.value < 0 ||
        cf.start_hour.value > 23 ||
        cf.start_minute.value < 0 ||
        cf.start_minute.value > 59
      )
        return alert("$invalid_time"), !1;
    }
    if ("" == cf.start_hour.value || "" == cf.end_hour.value)
      return alert("$invalid_time"), !1;
    "" != cf.start_hour.value &&
      "" != cf.end_hour.value &&
      ("" == cf.start_minute.value && (cf.start_minute.value = 0),
      "" == cf.end_minute.value && (cf.end_minute.value = 0)),
      (start_time = cf.start_hour.value + ":" + cf.start_minute.value),
      (end_time = cf.end_hour.value + ":" + cf.end_minute.value),
      (cf.start_block_time.value = start_time),
      (cf.end_block_time.value = end_time);
  }
  if (1 == tmp_all_day)
    (cf.start_block_time.value = "0:0"), (cf.end_block_time.value = "24:0");
  else {
    var start_time = cf.start_block_time.value.split(":"),
      end_time = cf.end_block_time.value.split(":");
    (cf.start_block_time.value = start_time[0] + ":" + start_time[1]),
      (cf.end_block_time.value = end_time[0] + ":" + end_time[1]);
  }
  return (cf.hidden_all_day.value = tmp_all_day), cf.submit(), !0;
}
