var device_name_null = "$device_name_null",
  device_name_error = "$device_name_error",
  device_name_dup = "$device_name_dup",
  mac_dup = "$mac_dup";
function check_wlacl_add(cf, flag) {
  if (64 == array_num) return alert("$acl_length_64"), !1;
  if ("" == cf.device.value) return alert(device_name_null), !1;
  for (i = 0; i < cf.device.value.length; i++)
    if (0 == isValidChar(cf.device.value.charCodeAt(i)))
      return alert(device_name_error), !1;
  for (i = 1; i <= array_num; i++) {
    var str = eval("wlaclArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if ("add" == flag) {
      if (each_info[0] == cf.device.value) return alert(device_name_dup), !1;
    } else if (each_info[0] == cf.device.value && i != select_edit)
      return alert(device_name_dup), !1;
  }
  if (12 == cf.adr.value.length && -1 == cf.adr.value.indexOf(":")) {
    var mac = cf.adr.value;
    cf.adr.value =
      mac.substr(0, 2) +
      ":" +
      mac.substr(2, 2) +
      ":" +
      mac.substr(4, 2) +
      ":" +
      mac.substr(6, 2) +
      ":" +
      mac.substr(8, 2) +
      ":" +
      mac.substr(10, 2);
  } else if (6 == cf.adr.value.split("-").length) {
    var tmp_mac = cf.adr.value.replace(/-/g, ":");
    cf.adr.value = tmp_mac;
  }
  if (0 == maccheck(cf.adr.value)) return !1;
  for (i = 1; i <= array_num; i++) {
    var str = eval("wlaclArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if ("add" == flag) {
      if (each_info[1].toLowerCase() == cf.adr.value.toLowerCase())
        return alert(mac_dup), !1;
    } else if (
      each_info[1].toLowerCase() == cf.adr.value.toLowerCase() &&
      i != select_edit
    )
      return alert(mac_dup), !1;
  }
  return !0;
}
function check_wlacl_edit(cf, flag) {
  if ("" == cf.device.value) return alert(device_name_null), !1;
  for (i = 0; i < cf.device.value.length; i++)
    if (0 == isValidChar(cf.device.value.charCodeAt(i)))
      return alert(device_name_error), !1;
  for (i = 1; i <= array_num; i++) {
    var str = eval("wlaclArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if ("add" == flag) {
      if (each_info[0] == cf.device.value) return alert(device_name_dup), !1;
    } else if (each_info[0] == cf.device.value && i != select_edit)
      return alert(device_name_dup), !1;
  }
  if (12 == cf.adr.value.length && -1 == cf.adr.value.indexOf(":")) {
    var mac = cf.adr.value;
    cf.adr.value =
      mac.substr(0, 2) +
      ":" +
      mac.substr(2, 2) +
      ":" +
      mac.substr(4, 2) +
      ":" +
      mac.substr(6, 2) +
      ":" +
      mac.substr(8, 2) +
      ":" +
      mac.substr(10, 2);
  } else if (6 == cf.adr.value.split("-").length) {
    var tmp_mac = cf.adr.value.replace(/-/g, ":");
    cf.adr.value = tmp_mac;
  }
  if (0 == maccheck(cf.adr.value)) return !1;
  for (i = 1; i <= array_num; i++) {
    var str = eval("wlaclArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if ("add" == flag) {
      if (each_info[1].toLowerCase() == cf.adr.value.toLowerCase())
        return alert(mac_dup), !1;
    } else if (
      each_info[1].toLowerCase() == cf.adr.value.toLowerCase() &&
      i != select_edit
    )
      return alert(mac_dup), !1;
  }
  return !0;
}
function check_wlacl_editnum(cf) {
  if (0 == array_num) return alert("$port_edit"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.MacSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.MacSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_edit"), !1)
    : ((cf.select_edit.value = select_num),
      (cf.submit_flag.value = "wlacl_editnum"),
      (cf.anticsrf.value = wlacl_editnum_token),
      (cf.action = "/apply.cgi?/WLG_acl_edit.htm timestamp=" + ts),
      !0);
}
function check_wlacl_del(cf) {
  if (0 == array_num) return alert("$port_del"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.MacSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.MacSelect[i].checked && (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_del"), !1)
    : !(
        1 == cf.accessLimit.checked &&
        1 == array_num &&
        ((1 == parent.an_router_flag && "1" == endis_wla_radio) ||
          "1" == endis_wl_radio) &&
        !confirm("$wps_warning4")
      ) &&
        ((cf.select_del.value = select_num),
        (cf.submit_flag.value = "wlacl_del"),
        (cf.anticsrf.value = wlacl_del_token),
        !0);
}
function check_wlacl_apply(cf) {
  return (
    1 == cf.accessLimit.checked
      ? (cf.wl_access_ctrl_on.value = 1)
      : (cf.wl_access_ctrl_on.value = 0),
    1 != cf.wl_access_ctrl_on.value ||
      0 != array_num ||
      ((1 != parent.an_router_flag || "1" != endis_wla_radio) &&
        "1" != endis_wl_radio) ||
      confirm("$wps_warning4")
  );
}
function mac_data_select(num) {
  var cf = document.forms[0];
  "&lt;$unknown_mark&gt;" == sta_name_array[num]
    ? (cf.device.value = "")
    : (cf.device.value = sta_name_array[num]
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")),
    (cf.adr.value = sta_mac_array[num].toUpperCase());
}
