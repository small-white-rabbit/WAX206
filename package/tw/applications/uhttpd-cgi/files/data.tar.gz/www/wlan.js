var sync_passwd,
  Africa = 0,
  Asia = 1,
  Australia = 2,
  Canada = 3,
  China = 11,
  Europe = 4,
  India = 12,
  Israel = 5,
  Japan = 6,
  Korea = 7,
  Malaysia = 13,
  Mexico = 8,
  Middle_East_Algeria_Syria_Yemen = 14,
  Middle_East_Iran_Lebanon_Qatar = 15,
  Middle_East_Turkey_Egypt_Tunisia_Kuwait = 16,
  Middle_East_Saudi_Arabia = 17,
  Middle_East_United_Arab_Emirates = 18,
  Middle_East = 22,
  Russia = 19,
  Singapore = 20,
  South_America = 9,
  Taiwan = 21,
  United_States = 10,
  qca_region_arr = new Array(
    "za",
    "none",
    "au",
    "ca",
    "eu",
    "il",
    "jp",
    "kr",
    "mx",
    "none",
    "us",
    "cn",
    "none",
    "my",
    "none",
    "none",
    "tr",
    "sa",
    "ae",
    "ru",
    "sg",
    "tw",
    "hk",
    "vn",
    "nz",
    ""
  );
function change_password_display(ele) {
  $$(ele).parents(".tdright").find(".input1").prop("outerHTML");
  var replaceInput,
    pwd = $$(ele).parents(".tdright").find(".input1"),
    pwd_value = $$(ele).parents(".tdright").find(".input1").val();
  "password" == pwd.attr("type")
    ? ((replaceInput = $$(ele)
        .parents(".tdright")
        .find(".input1")
        .prop("outerHTML")
        .replace("password", "text")),
      $$(ele).attr("src", "image/pwd_display_eye.png"))
    : ((replaceInput = $$(ele)
        .parents(".tdright")
        .find(".input1")
        .prop("outerHTML")
        .replace("text", "password")),
      $$(ele).attr("src", "image/pwd_close_eye.png")),
    pwd.replaceWith(replaceInput),
    $$(ele).parents(".tdright").find(".input1").val(pwd_value);
}
function Change_ax_opmode(cf) {
  if (
    "1" == getTop(window).use_orbi_style_flag &&
    1 == getTop(window).support_ax_flag && 
    0 == getTop(window).not_support_2g_ax_flag
  ) {
    1 != hide_mode_suffix &&
      ((suffix1 = " (11g)"),
      (suffix2 = " (11ax, HT20, 1024-QAM)"),
      (suffix3 = " (11ax, HT40, 1024-QAM)"));
    for (var j = cf.opmode.options.length; j > 0; j--)
      1 == cf.enable_ax.checked
        ? (cf.opmode.options[j - 1].text =
            window["wlan_mode_" + j] + window["suffix" + j])
        : (cf.opmode.options[j - 1].text =
            window["wlan_mode_" + (j + 3)] +
            window["suffix" + j].replace(/ax/, "ng"));
    1 == cf.enable_ax.checked
      ? ((document.getElementById("ofdma_tr").style.display = ""),
        "1" == enable_ofdma_2g
          ? (cf.ofdma_2g.checked = !0)
          : (cf.ofdma_2g.checked = !1),
        "1" == enable_ofdma_5g
          ? (cf.ofdma_5g.checked = !0)
          : (cf.ofdma_5g.checked = !1))
      : ((cf.opmode.options[0].value = "1"),
        (cf.opmode.options[1].value = "2"),
        (cf.opmode.options[2].value = "3"),
        (document.getElementById("ofdma_tr").style.display = "none"));
    var i = cf.opmode_an.options.length;
    for (
      1 != hide_mode_suffix &&
      ((suffix1 = " (11ax, HT20, 1024-QAM)"),
      (suffix2 = " (11ax, HT40, 1024-QAM)"),
      (suffix3 = " (80MHz) (11ax, HT80, 1024-QAM)"),
      (suffix4 = " (160MHz) (11ax, HT160, 1024-QAM)"));
      i > 0;
      i--
    )
      1 == cf.enable_ax.checked
        ? (cf.opmode_an.options[i - 1].text =
            window["an_wlan_mode_" + i] + window["suffix" + i])
        : (cf.opmode_an.options[i - 1].text =
            window["an_wlan_mode_" + (i + 4)] +
            window["suffix" + i].replace(/ax/, "ac"));
    1 == cf.enable_ax.checked
      ? (rewrite_list_value(cf, "opmode"), rewrite_list_value(cf, "opmode_an"))
      : (rewrite_list_value_to_original(cf, "opmode"),
        rewrite_list_value_to_original(cf, "opmode_an"));
  }
  else if (
    "1" == getTop(window).use_orbi_style_flag &&
    1 == getTop(window).support_ax_flag && 
    1 == getTop(window).not_support_2g_ax_flag
  ) {
    1 != hide_mode_suffix &&
      ((suffix1 = " (11g)"),
      (suffix2 = " (11ng, HT20, 256-QAM)"),
      (suffix3 = " (11ng, HT40, 256-QAM)"));
    for (var j = cf.opmode.options.length; j > 0; j--)
      1 == cf.enable_ax.checked
        ? (cf.opmode.options[j - 1].text =
            window["wlan_mode_" + j] + window["suffix" + j])
        : (cf.opmode.options[j - 1].text =
            window["wlan_mode_" + (j + 3)] +
            window["suffix" + j].replace(/ax/, "ng"));
    1 == cf.enable_ax.checked
      ? ((document.getElementById("ofdma_tr").style.display = ""),
        "1" == enable_ofdma_2g
          ? (cf.ofdma_2g.checked = !0)
          : (cf.ofdma_2g.checked = !1),
        "1" == enable_ofdma_5g
          ? (cf.ofdma_5g.checked = !0)
          : (cf.ofdma_5g.checked = !1))
      : ((cf.opmode.options[0].value = "1"),
        (cf.opmode.options[1].value = "2"),
        (cf.opmode.options[2].value = "3"),
        (document.getElementById("ofdma_tr").style.display = "none"));
    $$("#ofdma_tr td:eq(0)").hide();
    var i = cf.opmode_an.options.length;
    for (
      1 != hide_mode_suffix &&
      ((suffix1 = " (11ax, HT20, 1024-QAM)"),
      (suffix2 = " (11ax, HT40, 1024-QAM)"),
      (suffix3 = " (80MHz) (11ax, HT80, 1024-QAM)"),
      (suffix4 = " (160MHz) (11ax, HT160, 1024-QAM)"));
      i > 0;
      i--
    )
      1 == cf.enable_ax.checked
        ? (cf.opmode_an.options[i - 1].text =
            window["an_wlan_mode_" + i] + window["suffix" + i])
        : (cf.opmode_an.options[i - 1].text =
            window["an_wlan_mode_" + (i + 4)] +
            window["suffix" + i].replace(/ax/, "ac"));
    1 == cf.enable_ax.checked
      ? (rewrite_list_value(cf, "opmode"), rewrite_list_value(cf, "opmode_an"))
      : (rewrite_list_value_to_original(cf, "opmode"),
        rewrite_list_value_to_original(cf, "opmode_an"));
  }
}
function getObj(name) {
  return document.getElementById
    ? document.getElementById(name)
    : document.all
    ? document.all[name]
    : document.layers
    ? document.layers[name]
    : void 0;
}
function changekeylen(form) {
  1 == form.wepenc.options[0].selected
    ? ((form.KEY1.size = form.KEY2.size = form.KEY3.size = form.KEY4.size = 18),
      (form.KEY1.value = wep_64_key1),
      (form.KEY2.value = wep_64_key2),
      (form.KEY3.value = wep_64_key3),
      (form.KEY4.value = wep_64_key4))
    : ((form.KEY1.size = form.KEY2.size = form.KEY3.size = form.KEY4.size = 34),
      (form.KEY1.value = wep_128_key1),
      (form.KEY2.value = wep_128_key2),
      (form.KEY3.value = wep_128_key3),
      (form.KEY4.value = wep_128_key4));
}
function opmode_disabled() {
  (document.getElementById("opmode_all").style.display = "none"),
    (document.getElementById("opmode_54").style.display = "");
}
function opmode_abled() {
  (document.getElementById("opmode_all").style.display = ""),
    (document.getElementById("opmode_54").style.display = "none");
}
function setSecurity(num) {
  var form = document.forms[0];
  if (
    ((form.wpa1_press_flag.value = 0),
    (form.wpa2_press_flag.value = 0),
    (form.wpas_press_flag.value = 0),
    $$("#none").css("display", "none"),
    $$("#wpae").css("display", "none"),
    $$("#wep").css("display", "none"),
    $$("#passphrase_div").css("display", "block"),
    $$("#wpaPwdPhrExtText").html("$sec_863_or_64h"),
    $$("#passphrase").attr("maxlength", 64),
    (4 == num || 5 == num || 8 == num) &&
      (document.getElementById("passphrase") &&
        (sync_passwd = document.getElementById("passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wl_sectype))
  ) {
    if (
      0 ==
      confirm(
        "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
      )
    )
      return (
        ($$(form.security_type).val(securityValMapStr(wl_sectype))),
        setSecurity(wl_sectype)
      );
    sync_passwd = "";
  }
  if (2 == num) {
    $$("#wep").css("display", "block"),
      $$("#passphrase_div").css("display", "none"),
      changekeylen(form);
    var keyno = wl_get_keyno;
    wl_get_keylength;
    parseInt(keyno) > 0 && (form.wep_key_no[parseInt(keyno) - 1].checked = !0),
      (form.KEY1.value = wl_key1),
      (form.KEY2.value = wl_key2),
      (form.KEY3.value = wl_key3),
      (form.KEY4.value = wl_key4);
  } else
    4 == num
      ? ($$("#passphrase").val(wl_wpa2_psk),
        (document.forms[0].wpa2_press_flag.value = "1"),
        "1" == have_wpa3_flag
          ? $$("#sec_title").html("(WPA2-Personal)")
          : $$("#sec_title").html("(WPA2-PSK)"))
      : 5 == num
      ? ($$("#passphrase").val(wl_wpas_psk),
        (document.forms[0].wpas_press_flag.value = "1"),
        "1" == have_wpa3_flag
          ? $$("#sec_title").html("(WPA-Personal + WPA2-Personal)")
          : $$("#sec_title").html("(WPA-PSK + WPA2-PSK)"))
      : 6 == num
      ? ($$("#wpae").css("display", "block"),
        $$("#passphrase_div").css("display", "none"),
        (form.wpae_mode.value = get_wpae_mode),
        "" != get_radiusSerIp &&
          "0.0.0.0" != get_radiusSerIp &&
          ((radiusIPArray = get_radiusSerIp.split(".")),
          (form.radiusIPAddr1.value = radiusIPArray[0]),
          (form.radiusIPAddr2.value = radiusIPArray[1]),
          (form.radiusIPAddr3.value = radiusIPArray[2]),
          (form.radiusIPAddr4.value = radiusIPArray[3])),
        (form.textWpaeRadiusPort.value = get_radiusPort))
      : 7 == num
      ? ($$("#passphrase").val(wl_wpa3_sae_psk),
        (document.forms[0].wpa3_sae_press_flag.value = "1"),
        $$("#sec_title").html("(WPA3-Personal)"),
        $$("#wpaPwdPhrExtText").html("$sec_8_63char"),
        $$("#passphrase").attr("maxlength", 64))
      : 8 == num
      ? ($$("#passphrase").val(wl_wpa2_psk),
        (document.forms[0].wpa2_press_flag.value = "1"),
        $$("#sec_title").html("(WPA2-Personal + WPA3-Personal)"))
      : ($$("#none").css("display", "block"),
        $$("#wpae").css("display", "none"),
        $$("#passphrase_div").css("display", "none"),
        $$("#wep").css("display", "none"));
}
function opmode_an_disabled() {
  (document.getElementById("opmode_an_all").style.display = "none"),
    (document.getElementById("opmode_an_54").style.display = "");
}
function opmode_an_abled() {
  (document.getElementById("opmode_an_all").style.display = ""),
    (document.getElementById("opmode_an_54").style.display = "none");
}
function w2_setSecurity(num) {
  if (
    (((form = document.forms[0]).wpa1_press_flag_w2.value = 0),
    (form.wpa2_press_flag_w2.value = 0),
    (form.wpas_press_flag_w2.value = 0),
    $$("#w2_none").css("display", "none"),
    $$("#w2_wpae").css("display", "none"),
    $$("#wep_w2").css("display", "none"),
    $$("#w2_passphrase_div").css("display", "block"),
    $$("#w2_wpaPwdPhrExtText").html("$sec_863_or_64h"),
    $$("#w2_passphrase").attr("maxlength", 64),
    2 == num)
  ) {
    var form;
    $$("#wep_w2").css("display", "block"),
      $$("#w2_passphrase_div").css("display", "none"),
      changekeylen((form = document.forms[0]));
    var keyno = wlg_get_keyno;
    wlg_get_keylength;
    parseInt(keyno) > 0 &&
      (form.wep_key_no_guest[parseInt(keyno) - 1].checked = !0),
      (form.KEY1.value = wlg_key1),
      (form.KEY2.value = wlg_key2),
      (form.KEY3.value = wlg_key3),
      (form.KEY4.value = wlg_key4);
  } else if (4 == num) {
    if (
      ($$("#w2_passphrase").val(wlg1_wpa2_psk),
      document.getElementById("w2_passphrase") &&
        (sync_passwd = document.getElementById("w2_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w2).val(securityValMapStr(wlg_sectype))),
          w2_setSecurity(wlg_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpa2_press_flag_w2.value = "1"),
      "1" == have_wpa3_flag
        ? $$("#w2_sec_title").html("(WPA2-Personal)")
        : $$("#w2_sec_title").html("(WPA2-PSK)");
  } else if (5 == num) {
    if (
      ($$("#w2_passphrase").val(wlg1_wpas_psk),
      document.getElementById("w2_passphrase") &&
        (sync_passwd = document.getElementById("w2_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w2).val(securityValMapStr(wlg_sectype))),
          w2_setSecurity(wlg_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpas_press_flag_w2.value = "1"),
      "1" == have_wpa3_flag
        ? $$("#w2_sec_title").html("(WPA-Personal + WPA2-Personal)")
        : $$("#w2_sec_title").html("(WPA-PSK + WPA2-PSK)");
  } else if (6 == num)
    $$("#w2_wpae").css("display", "block"),
      $$("#w2_passphrase_div").css("display", "none"),
      (form.wpae_mode_w2.value = wlg_get_wpae_mode),
      "" != wlg_get_radiusSerIp &&
        "0.0.0.0" != wlg_get_radiusSerIp &&
        ((radiusIPArray = wlg_get_radiusSerIp.split(".")),
        (form.radiusIPAddr1_w2.value = radiusIPArray[0]),
        (form.radiusIPAddr2_w2.value = radiusIPArray[1]),
        (form.radiusIPAddr3_w2.value = radiusIPArray[2]),
        (form.radiusIPAddr4_w2.value = radiusIPArray[3])),
      (form.textWpaeRadiusPort_w2.value = wlg_get_radiusPort);
  else if (7 == num)
    $$("#w2_passphrase").val(wlg1_wpa3_sae_psk),
      (document.forms[0].wpa3_sae_press_flag_w2.value = "1"),
      $$("#w2_sec_title").html("(WPA3-Personal)"),
      $$("#w2_wpaPwdPhrExtText").html("$sec_8_63char"),
      $$("#w2_passphrase").attr("maxlength", 64);
  else if (8 == num) {
    if (
      ($$("#w2_passphrase").val(wlg1_wpa2_psk),
      document.getElementById("w2_passphrase") &&
        (sync_passwd = document.getElementById("w2_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w2).val(securityValMapStr(wlg_sectype))),
          w2_setSecurity(wlg_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpa2_press_flag_w2.value = "1"),
      $$("#w2_sec_title").html("(WPA2-Personal + WPA3-Personal)");
  } else
    $$("#w2_none").css("display", "block"),
      $$("#w2_wpae").css("display", "none"),
      $$("#w2_passphrase_div").css("display", "none"),
      $$("#wep_w2").css("display", "none");
}
function w3_setSecurity(num) {
  if (
    (((form = document.forms[0]).wpa1_press_flag_w3.value = 0),
    (form.wpa2_press_flag_w3.value = 0),
    (form.wpas_press_flag_w3.value = 0),
    $$("#w3_none").css("display", "none"),
    $$("#w3_wpae").css("display", "none"),
    $$("#wep_w3").css("display", "none"),
    $$("#w3_passphrase_div").css("display", "block"),
    $$("#w3_wpaPwdPhrExtText").html("$sec_863_or_64h"),
    $$("#w3_passphrase").attr("maxlength", 64),
    2 == num)
  ) {
    var form;
    $$("#wep_w3").css("display", "block"),
      $$("#w3_passphrase_div").css("display", "none"),
      changekeylen((form = document.forms[0]));
    var keyno = wlg2_get_keyno;
    wlg2_get_keylength;
    parseInt(keyno) > 0 &&
      (form.wep_key_no_w3[parseInt(keyno) - 1].checked = !0),
      (form.KEY1.value = wlg2_key1),
      (form.KEY2.value = wlg2_key2),
      (form.KEY3.value = wlg2_key3),
      (form.KEY4.value = wlg2_key4);
  } else if (4 == num) {
    if (
      ($$("#w3_passphrase").val(wlg2_wpa2_psk),
      document.getElementById("w3_passphrase") &&
        (sync_passwd = document.getElementById("w3_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg2_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w3).val(securityValMapStr(wlg2_sectype))),
          w3_setSecurity(wlg2_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpa2_press_flag_w3.value = "1"),
      "1" == have_wpa3_flag
        ? $$("#w3_sec_title").html("(WPA2-Personal)")
        : $$("#w3_sec_title").html("(WPA2-PSK)");
  } else if (5 == num) {
    if (
      ($$("#w3_passphrase").val(wlg2_wpas_psk),
      document.getElementById("w3_passphrase") &&
        (sync_passwd = document.getElementById("w3_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg2_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w3).val(securityValMapStr(wlg2_sectype))),
          w3_setSecurity(wlg2_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpas_press_flag_w3.value = "1"),
      "1" == have_wpa3_flag
        ? $$("#w3_sec_title").html("(WPA-Personal + WPA2-Personal)")
        : $$("#w3_sec_title").html("(WPA-PSK + WPA2-PSK)");
  } else if (6 == num)
    $$("#w3_wpae").css("display", "block"),
      $$("#w3_passphrase_div").css("display", "none"),
      (form.wpae_mode_w3.value = wlg2_get_wpae_mode),
      "" != wlg2_get_radiusSerIp &&
        "0.0.0.0" != wlg2_get_radiusSerIp &&
        ((radiusIPArray = wlg2_get_radiusSerIp.split(".")),
        (form.radiusIPAddr1_w3.value = radiusIPArray[0]),
        (form.radiusIPAddr2_w3.value = radiusIPArray[1]),
        (form.radiusIPAddr3_w3.value = radiusIPArray[2]),
        (form.radiusIPAddr4_w3.value = radiusIPArray[3])),
      (form.textWpaeRadiusPort_w3.value = wlg2_get_radiusPort);
  else if (7 == num)
    $$("#w3_passphrase").val(wlg2_wpa3_sae_psk),
      (document.forms[0].wpa3_sae_press_flag_w3.value = "1"),
      $$("#w3_sec_title").html("(WPA3-Personal)"),
      $$("#w3_wpaPwdPhrExtText").html("$sec_8_63char"),
      $$("#w3_passphrase").attr("maxlength", 64);
  else if (8 == num) {
    if (
      ($$("#w3_passphrase").val(wlg2_wpa2_psk),
      document.getElementById("w3_passphrase") &&
        (sync_passwd = document.getElementById("w3_passphrase").value),
      null != sync_passwd && sync_passwd.length > 64 && num != wlg2_sectype)
    ) {
      if (
        0 ==
        confirm(
          "Your WPA3-Personal password length is more than 64 characters. The other security options support a password that is less than 64 characters only. If you want to change the security option, you must change your password to be less than 64 characters. Click the OK button if you want to change your password. Click the Cancel button if you don't want to make any changes."
        )
      )
        return (
          ($$(form.security_type_w3).val(securityValMapStr(wlg2_sectype))),
          w3_setSecurity(wlg2_sectype)
        );
      sync_passwd = "";
    }
    (document.forms[0].wpa2_press_flag_w3.value = "1"),
      $$("#w3_sec_title").html("(WPA2-Personal + WPA3-Personal)");
  } else
    $$("#w3_none").css("display", "block"),
      $$("#w3_wpae").css("display", "none"),
      $$("#w3_passphrase_div").css("display", "none"),
      $$("#wep_w3").css("display", "none");
}
function check_dfs() {
  var channel_info,
    cf = document.forms[0],
    each_info = dfs_info.split(":"),
    currentMode = convert_value_to_original(cf, "opmode_an"),
    index = convert_value_to_original(cf, "WRegion"),
    ch_index = (channel = cf.w_channel_an).selectedIndex,
    ch_name = channel.options[ch_index].text,
    ch_value = channel.options[ch_index].value,
    ht160_enabled =
      1 == getTop(window).support_ht160_flag &&
      "1" == enable_ht160 &&
      (10 == index ||
        4 == index ||
        ("1" == getTop(window).use_orbi_style_flag &&
          (20 == index || 22 == index || 23 == index))) &&
      1 != currentMode &&
      2 != currentMode &&
      7 != currentMode &&
      8 != currentMode;
  if (-1 == ch_name.indexOf("(DFS)") && !ht160_enabled) return !0;
  if (1 == getTop(window).dfs_radar_detect_flag) {
    var tmp_array;
    if (ht160_enabled) {
      if (null == dfs_radar_160) return !0;
      tmp_array = dfs_radar_160;
    } else if (1 == currentMode || 2 == currentMode || 7 == currentMode) {
      if (null == dfs_radar_20) return !0;
      tmp_array = dfs_radar_20;
    } else if (9 == currentMode) {
      if (null == dfs_radar_80) return !0;
      tmp_array = dfs_radar_80;
    } else {
      if (null == dfs_radar_40) return !0;
      tmp_array = dfs_radar_40;
    }
    for (var i = 0; i < tmp_array.length - 1; i++) {
      var channel = tmp_array[i].channel,
        min = tmp_array[i].expire / 60,
        sec = tmp_array[i].expire % 60;
      if (channel == ch_value)
        return (
          alert(
            "$using_dfs_1" +
              min.toFixed(0) +
              "$using_dfs_2" +
              sec +
              "$using_dfs_3"
          ),
          !1
        );
    }
  } else
    for (i = 0; i < each_info.length; i++) {
      (sec = (channel_info = each_info[i].split(" "))[3] % 60),
        (min = parseInt(channel_info[3] / 60));
      if (5e3 + 5 * parseInt(ch_value, 10) == parseInt(channel_info[0], 10))
        return (
          alert("$using_dfs_1" + min + "$using_dfs_2" + sec + "$using_dfs_3"),
          !1
        );
    }
  return -1 == ch_name.indexOf("(DFS)") || 0 != confirm("$select_dfs");
}
function check_dfs_sec() {
  var channel_info,
    cf = document.forms[0],
    each_info = dfs_info.split(":"),
    currentMode = convert_value_to_original(cf, "opmode_an"),
    index = convert_value_to_original(cf, "WRegion");
  if ("none" == document.getElementById("sec_channel_tr").style.display)
    return !0;
  var ch_index = (channel = cf.w_channel_an_sec).selectedIndex,
    ch_name = channel.options[ch_index].text,
    ch_value = channel.options[ch_index].value,
    ht160_enabled =
      1 == getTop(window).support_ht160_flag &&
      "1" == enable_ht160 &&
      (10 == index || 4 == index) &&
      1 != currentMode &&
      2 != currentMode &&
      7 != currentMode &&
      8 != currentMode;
  if (-1 == ch_name.indexOf("(DFS)") && !ht160_enabled) return !0;
  if (
    1 == getTop(window).support_second_dfs &&
    10 == index &&
    -1 !=
      cf.w_channel_an.options[cf.w_channel_an.selectedIndex].text.indexOf(
        "(DFS)"
      ) &&
    -1 != ch_name.indexOf("(DFS)")
  )
    return (
      alert(
        "It is not allow to select both primary and secondary channel to DFS channel !!!"
      ),
      !1
    );
  if (1 == getTop(window).dfs_radar_detect_flag) {
    var tmp_array;
    if (ht160_enabled) {
      if (null == dfs_radar_160) return !0;
      tmp_array = dfs_radar_160;
    } else if (1 == currentMode || 2 == currentMode || 7 == currentMode) {
      if (null == dfs_radar_20) return !0;
      tmp_array = dfs_radar_20;
    } else if (9 == currentMode) {
      if (null == dfs_radar_80) return !0;
      tmp_array = dfs_radar_80;
    } else {
      if (null == dfs_radar_40) return !0;
      tmp_array = dfs_radar_40;
    }
    for (var i = 0; i < tmp_array.length - 1; i++) {
      var channel = tmp_array[i].channel,
        min = tmp_array[i].expire / 60,
        sec = tmp_array[i].expire % 60;
      if (channel == ch_value)
        return (
          alert(
            "$using_dfs_1" +
              min.toFixed(0) +
              "$using_dfs_2" +
              sec +
              "$using_dfs_3"
          ),
          !1
        );
    }
  } else
    for (i = 0; i < each_info.length; i++) {
      (sec = (channel_info = each_info[i].split(" "))[3] % 60),
        (min = parseInt(channel_info[3] / 60));
      if (5e3 + 5 * parseInt(ch_value, 10) == parseInt(channel_info[0], 10))
        return (
          alert("$using_dfs_1" + min + "$using_dfs_2" + sec + "$using_dfs_3"),
          !1
        );
    }
  return -1 == ch_name.indexOf("(DFS)") || 0 != confirm("$select_dfs");
}
function setChannel() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var endChannel,
    chIndex = cf.w_channel.selectedIndex;
  cf.opmode.selectedIndex;
  (endChannel = FinishChannel[index]),
    14 == FinishChannel[index] && 0 != cf.opmode.selectedIndex
      ? (cf.w_channel.options.length = endChannel - StartChannel[index])
      : (cf.w_channel.options.length = endChannel - StartChannel[index] + 2),
    (cf.w_channel.options[0].text = "$auto_mark"),
    (cf.w_channel.options[0].value = 0);
  for (var i = StartChannel[index]; i <= endChannel; i++)
    (14 == i && 0 != cf.opmode.selectedIndex) ||
      ((cf.w_channel.options[i - StartChannel[index] + 1].value = i),
      (cf.w_channel.options[i - StartChannel[index] + 1].text =
        i < 10 ? "0" + i : i));
  cf.w_channel.selectedIndex =
    chIndex > -1 && chIndex < cf.w_channel.options.length ? chIndex : 0;
}
function setBChannel() {
  var cf = document.forms[0],
    index = cf.WRegion.selectedIndex;
  index = parseInt(index) + 1;
  var endChannel,
    chIndex = cf.w_channel.selectedIndex;
  cf.opmode.selectedIndex;
  (endChannel = FinishChannelB[index]),
    14 == FinishChannelB[index] && 0 != cf.opmode.selectedIndex
      ? (cf.w_channel.options.length = endChannel - StartChannelB[index])
      : (cf.w_channel.options.length = endChannel - StartChannelB[index] + 2),
    (cf.w_channel.options[0].text = "$auto_mark"),
    (cf.w_channel.options[0].value = 0);
  for (var i = StartChannelB[index]; i <= endChannel; i++)
    (14 == i && 0 != cf.opmode.selectedIndex) ||
      ((cf.w_channel.options[i - StartChannelB[index] + 1].value = i),
      (cf.w_channel.options[i - StartChannelB[index] + 1].text =
        i < 10 ? "0" + i : i));
  cf.w_channel.selectedIndex =
    chIndex > -1 && chIndex < cf.w_channel.options.length ? chIndex : 0;
}
function chgChA(from) {
  var cf = document.forms[0];
  setAChannel(cf.w_channel_an);
}
function setAwlan_mode() {
  1 == ac_router_flag ? setACwlan_mode() : setANwlan_mode();
}
function setACwlan_mode() {
  var cf = document.forms[0],
    index = convert_value_to_original(cf, "WRegion"),
    currentMode = cf.opmode_an.selectedIndex;
  index == Africa ||
  index == Israel ||
  index == Middle_East_Turkey_Egypt_Tunisia_Kuwait ||
  index == Middle_East_Saudi_Arabia
    ? ((cf.opmode_an.options.length = 1),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.selectedIndex = currentMode <= 0 ? currentMode : 0),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : index == Middle_East_Algeria_Syria_Yemen
    ? ((cf.w_channel_an.selectedIndex = 0),
      (cf.w_channel_an.disabled = !0),
      (cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[2].text = an_wlan_mode_3),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.options[2].value = "9"),
      (cf.opmode_an.disabled = !0))
    : index == Russia
    ? ((cf.opmode_an.options.length = 2),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.selectedIndex = currentMode > 1 ? 1 : currentMode),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : ((cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[2].text = an_wlan_mode_3),
      (cf.opmode_an.options[0].value = "7"),
      (cf.opmode_an.options[1].value = "8"),
      (cf.opmode_an.options[2].value = "9"),
      "1" != getTop(window).use_orbi_style_flag ||
      "undefined" == typeof an_wlan_mode_4 ||
      "" == an_wlan_mode_4 ||
      (2 != index &&
        4 != index &&
        6 != index &&
        10 != index &&
        11 != index &&
        21 != index &&
        20 != index &&
        22 != index &&
        23 != index)
        ? (cf.opmode_an.selectedIndex = currentMode > 2 ? 1 : currentMode)
        : ((cf.opmode_an.options.length = 4),
          (cf.opmode_an.options[3].text = an_wlan_mode_4),
          (cf.opmode_an.options[3].value = "10"),
          (cf.opmode_an.selectedIndex = currentMode)),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1));
}
function setANwlan_mode() {
  var cf = document.forms[0],
    index = convert_value_to_original(cf, "WRegion"),
    currentMode = cf.opmode_an.selectedIndex;
  index == Africa ||
  index == Israel ||
  index == Middle_East_Turkey_Egypt_Tunisia_Kuwait ||
  index == Middle_East_Saudi_Arabia
    ? ((cf.opmode_an.options.length = 2),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.selectedIndex = currentMode <= 1 ? currentMode : 1),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1))
    : index == Middle_East_Algeria_Syria_Yemen
    ? ((cf.w_channel_an.selectedIndex = 0),
      (cf.w_channel_an.disabled = !0),
      (cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[2].text = an_wlan_mode_3),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.options[2].value = "3"),
      (cf.opmode_an.disabled = !0))
    : ((cf.opmode_an.options.length = 3),
      (cf.opmode_an.options[0].text = an_wlan_mode_1),
      (cf.opmode_an.options[1].text = an_wlan_mode_2),
      (cf.opmode_an.options[2].text = an_wlan_mode_3),
      (cf.opmode_an.options[0].value = "1"),
      (cf.opmode_an.options[1].value = "2"),
      (cf.opmode_an.options[2].value = "3"),
      (cf.opmode_an.selectedIndex = currentMode),
      (cf.w_channel_an.disabled = !1),
      (cf.opmode_an.disabled = !1));
}
function remove_all_5g_dfs_channel() {
  for (
    var target = document.getElementById("wireless_channel_an"), i = 0;
    i < target.options.length;
    i++
  )
    if (-1 != target.options[i].text.indexOf("(DFS)")) {
      var opts = target.options;
      (opts = Array.prototype.slice.apply(opts).slice(i)),
        target.removeChild(opts[0]),
        i--;
    }
}
function setAChannel(channel) {
  var val,
    cf = document.forms[0],
    index = convert_value_to_original(cf, "WRegion"),
    currentMode = convert_value_to_original(cf, "opmode_an"),
    option_array = document.getElementById("wireless_channel_an").options,
    chValue = channel.value,
    find_value = 0,
    j = 0,
    tmp_array = ht40_array[index],
    secChannel = document.getElementById("w_channel_an_sec"),
    secChannelTr = document.getElementById("sec_channel_tr"),
    secValue = secChannel.value;
  for (
    secChannelTr.style.display = "none",
      ((0 != getTop(window).support_second_dfs || "1" != enable_ht160) &&
        "1" != getTop(window).use_orbi_style_flag) ||
      9 != currentMode ||
      (10 != index && 21 != index)
        ? "1" != getTop(window).use_orbi_style_flag &&
          "1" == enable_ht160 &&
          11 == index
          ? (tmp_array = ht160_array11)
          : 1 == currentMode || 2 == currentMode || 7 == currentMode
          ? ((tmp_array = ht20_array[index]),
            "1" != getTop(window).use_orbi_style_flag ||
              (10 != index && 21 != index) ||
              (tmp_array = ht20_array10))
          : 9 == currentMode
          ? ((tmp_array = ht80_array[index]),
            "1" != getTop(window).use_orbi_style_flag &&
              (4 == index ||
                (1 == getTop(window).support_second_dfs && 10 == index)) &&
              "1" === enable_ht160 &&
              (secChannelTr.style.display = ""))
          : "1" != getTop(window).use_orbi_style_flag ||
            10 != currentMode ||
            (2 != index && 11 != index)
          ? "1" != getTop(window).use_orbi_style_flag ||
            10 != currentMode ||
            (4 != index && 6 != index && 10 != index && 21 != index)
            ? "1" != getTop(window).use_orbi_style_flag ||
              10 != currentMode ||
              (20 != index && 22 != index && 23 != index)
              ? "1" != getTop(window).use_orbi_style_flag ||
                (10 != index && 21 != index) ||
                (tmp_array = ht40_array10)
              : (tmp_array = ht160_array23)
            : (tmp_array = ht160_array4)
          : (tmp_array = ht160_array2)
        : (tmp_array = ht160_array10),
      channel.options.length = tmp_array.length + 1,
      1 == dfs_channel_router_flag &&
        1 == parent.auto_5g_chennel_flag &&
        ((channel.options[j].value = 0),
        (channel.options[j].text = "$auto_mark"),
        j++),
      i = 0;
    i < tmp_array.length;
    i++
  )
    if (
      (0 == hidden_dfs_channel &&
        (1 == dfs_channel_router_flag ||
          (1 == dfs_canada_router_flag && 3 == index) ||
          (1 == dfs_australia_router_flag && 2 == index) ||
          (1 == dfs_europe_router_flag && 4 == index) ||
          (dfs_japan_router_flag && 6 == index) ||
          10 == index)) ||
      22 == index ||
      23 == index ||
      (dfs_russia_router_flag && 19 == index) ||
      (12 == index && 11 != index)
    )
      if (tmp_array[i].indexOf("(DFS)") > -1) {
        if (
          "1" != getTop(window).use_orbi_style_flag &&
          2 == index &&
          "1" == enable_ht160
        )
          continue;
        (val = tmp_array[i].split("(DFS)")[0]),
          (channel.options[j].value = val),
          (channel.options[j].text = tmp_array[i]),
          j++;
      } else
        (channel.options[j].value = channel.options[j].text = tmp_array[i]),
          j++;
    else {
      if (tmp_array[i].indexOf("(DFS)") > -1) continue;
      (channel.options[j].value = channel.options[j].text = tmp_array[i]), j++;
    }
  for (channel.options.length = j, i = 0; i < option_array.length; i++)
    if (option_array[i].value == chValue) {
      (find_value = 1), (channel.selectedIndex = i);
      break;
    }
  if (0 == find_value)
    for (i = 0; i < option_array.length; i++)
      if (option_array[i].value == wla_get_channel) {
        (find_value = 1), (channel.selectedIndex = i);
        break;
      }
  if (
    (0 == find_value && (channel.selectedIndex = 0),
    "none" !== secChannelTr.style.display)
  ) {
    (secChannel.innerHTML = channel.innerHTML),
      not_conflict_ht80(channel),
      4 == index && not_conflict_eu_sec(channel);
    for (
      var secOpts = secChannel.options, secFind = !1, i = 0;
      i < secOpts.length;
      i++
    )
      if (secOpts[i].value == secValue) {
        (secFind = !0), (secChannel.selectedIndex = i);
        break;
      }
    if (!1 === secFind)
      for (i = 0; i < secOpts.length; i++)
        if (secOpts[i].value === get_sec_channel) {
          (secFind = !0), (secChannel.selectedIndex = i);
          break;
        }
    !1 === secFind && (secChannel.selectedIndex = 0);
  }
  ((1 == getTop(window).remove_5g_dfs_flag &&
    2 != index &&
    4 != index &&
    6 != index &&
    10 != index &&
    11 != index &&
    21 != index &&
    20 != index &&
    22 != index &&
    23 != index) ||
    ("1" != getTop(window).use_orbi_style_flag && 23 == index)) &&
    remove_all_5g_dfs_channel();
}
function not_conflict_ht80(source) {
  var id =
      "wireless_channel_an" === source.id
        ? "w_channel_an_sec"
        : "wireless_channel_an",
    target = document.getElementById(id),
    firstIndex = source.selectedIndex,
    end = 4 * (Math.floor(firstIndex / 4) + 1),
    start = end - 4,
    opts = target.options;
  opts = Array.prototype.slice.apply(opts).slice(start, end);
  for (var i = 0; i < opts.length; i++) target.removeChild(opts[i]);
}
function not_conflict_eu_sec(source) {
  var id =
      "wireless_channel_an" === source.id
        ? "w_channel_an_sec"
        : "wireless_channel_an",
    target = document.getElementById(id),
    firstIndex = source.selectedIndex,
    part = Math.floor(firstIndex / 4);
  if (1 == part) {
    var opts = target.options;
    opts = Array.prototype.slice.apply(opts).slice(4, 12);
    for (var i = 0; i < opts.length; i++) target.removeChild(opts[i]);
  }
  if (2 == part || 3 == part) {
    opts = target.options;
    opts = Array.prototype.slice.apply(opts).slice(4, 8);
    for (i = 0; i < opts.length; i++) target.removeChild(opts[i]);
  }
}
($$.initChannels = function () {
  $$.getJSON("channel_info.json", function (json) {
    ($$.channel_info = json),
      $$.channel_info &&
        $$.channel_info.current_info &&
        ((channel = $$.channel_info.current_info.wl0),
        (channel_a = $$.channel_info.current_info.wl1),
        $$.setChannel("wl0", channel),
        $$.setChannel("wl1", channel_a));
  });
}),
  ($$.setChannel = function (wifix, chValue) {
    var cf = document.forms[0];
    1 == channel_json
      ? "wl0" == wifix
        ? $$.setChannelList(
            "wireless_channel",
            $$("#wireless_region").val(),
            "wl0",
            convert_value_to_original(cf, "opmode"),
            chValue
          )
        : "wl1" == wifix &&
          $$.setChannelList(
            "wireless_channel_an",
            $$("#wireless_region").val(),
            "wl1",
            convert_value_to_original(cf, "opmode_an"),
            chValue
          )
      : (chgChA(1), setBChannel());
  }),
  ($$.setChannelList = function (channel_id, region_code, wlx, mode, chValue) {
    region_code = convert_value_to_original(document.forms[0], "WRegion");
    new Array(2, 11, 4, 6, 10, 21, 20, 22, 23);
    var regionx = "region-" + region_code,
      htx = "HT20";
    $$.channel_info ||
      $$.getJSON("channel_info.json", function (json) {
        ($$.channel_info = json),
          (channel = $$.channel_info.current_info.wl0),
          (channel_a = $$.channel_info.current_info.wl1),
          $$.setChannelList(channel_id, region_code, wlx, mode, chValue);
      }),
      "wl0" != wlx
        ? ((htx =
            1 == mode || 2 == mode || 7 == mode
              ? "HT20"
              : 9 == mode
              ? "HT80"
              : "HT40"),
          10 == mode && (htx = "HT160"))
        : ("573" != mode && "500" != mode) || (htx = "HT40");
    var channel_list = $$.channel_info[regionx][wlx][htx];
    (channel_list = (channel_list || "").replace(/\ /g, "").split(",")),
      (chValue = chValue || $$("#" + channel_id).val());
    var channel = document.getElementById(channel_id);
    channel.options.length = channel_list.length + 1;
    var i,
      num = 0,
      find_value = 0;
    for (i = 0; i < channel_list.length; i++) {
      var ch = channel_list[i] || "",
        val = parseInt((ch || "").split("(DFS)")[0]),
        text = ch;

      if (($$.inArray(region_code, hidden_list_dfs_region) > -1) && (ch.indexOf("(DFS)") > -1)) {
        continue;
      }
      if (hidden_dfs_channel && (ch.indexOf("(DFS)") > -1)) {
        continue;
      }

      (text = 0 == val ? "Auto" : val < 10 ? "0" + val : text),
        isNaN(val) ||
          (val == chValue && (find_value = num),
          (channel.options[num].value = val),
          (channel.options[num].text = text),
          num++);
    }
    (channel.options.length = num),
      num > 0
        ? $$("#" + channel_id).prop("disabled", !1)
        : $$("#" + channel_id).prop("disabled", !0),
      (channel.selectedIndex = find_value),
      (channel.value = channel.options[find_value]
        ? channel.options[find_value].value
        : "");
  });
var haven_alert_tkip = 0,
  tag3 = 0;
function check_basic_wlan() {
  var cf = document.forms[0],
    ssid_bgn = document.forms[0].ssid.value,
    haven_wpe = 0;
  (haven_alert_tkip = 0), (tag3 = 0);
  var wlg1_ssid = document.forms[0].w2_ssid.value,
    wlg2_ssid = document.forms[0].w3_ssid.value;
  if ("" == ssid_bgn) return alert("$ssid_null"), !1;
  if (ssid_bgn == wlg1_ssid || ssid_bgn == wlg2_ssid || wlg1_ssid == wlg2_ssid)
    return alert("$ssid_not_allowed_same"), !1;
  for (i = 0; i < ssid_bgn.length; i++)
    if (0 == isValidChar_space(ssid_bgn.charCodeAt(i)))
      return alert("$ssid_not_allowed"), !1;
  if (
    ((cf.wl_ssid.value = ssid_bgn),
    1 == cf.ssid_bc.checked
      ? (cf.wl_enable_ssid_broadcast.value = "1")
      : (cf.wl_enable_ssid_broadcast.value = "0"),
    (cf.wl_apply_flag.value = "1"),
    "WEP" == $$(cf.security_type).val())
  ) {
    if (0 == checkwep(cf)) return !1;
    cf.wl_hidden_sec_type.value = 2;
  } else if ("WPA-PSK" == $$(cf.security_type).val()) {
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
    (cf.wl_hidden_sec_type.value = 3),
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
  } else if ("WPA2-PSK" == $$(cf.security_type).val()) {
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
    (cf.wl_hidden_sec_type.value = 4),
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
  } else if ("AUTO-PSK" == $$(cf.security_type).val()) {
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
    (cf.wl_hidden_sec_type.value = 5),
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
  } else if ("WPA-Enterprise" == $$(cf.security_type).val()) {
    if (
      ((radiusServerIP =
        cf.radiusIPAddr1.value +
        "." +
        cf.radiusIPAddr2.value +
        "." +
        cf.radiusIPAddr3.value +
        "." +
        cf.radiusIPAddr4.value),
      "" == radiusServerIP || 0 == checkipaddr(radiusServerIP))
    )
      return alert("$invalid_ip"), !1;
    if (
      0 == isSameSubNet(radiusServerIP, lanSubnet, lanIP, lanSubnet) &&
      0 == isSameSubNet(radiusServerIP, wanSubnet, wanIP, wanSubnet)
    )
      return alert("$diff_LanWan_subnet"), !1;
    if (1 == isSameIp(lanIP, radiusServerIP)) return alert("$invalid_ip"), !1;
    if (1 == isSameIp(wanIP, radiusServerIP))
      return alert("$conflicted_with_wanip"), !1;
    if (
      ((cf.radiusServerIP.value = radiusServerIP),
      (radiusPort = parseInt(cf.textWpaeRadiusPort.value, 10)),
      isNaN(radiusPort) || radiusPort < 1 || radiusPort > 65535)
    )
      return alert("$radiusPort65535"), !1;
    if (
      ((cf.textWpaeRadiusPort.value = radiusPort),
      "" == cf.textWpaeRadiusSecret.value)
    )
      return alert("$radiusSecret64"), !1;
    if (cf.textWpaeRadiusSecret.value.length > 64)
      return alert("$radiusSecret64"), !1;
    for (i = 0; i < cf.textWpaeRadiusSecret.value.length; i++)
      if (0 == isValidChar(cf.textWpaeRadiusSecret.value.charCodeAt(i)))
        return alert("$radiusSecret64"), cf.textWpaeRadiusSecret.focus(), !1;
    (cf.hidden_WpaeRadiusSecret.value = cf.textWpaeRadiusSecret.value),
      (cf.wl_hidden_sec_type.value = 6),
      (cf.textWpaeRadiusPort.value = port_range_interception(
        cf.textWpaeRadiusPort.value
      ));
  } else if ("WPA3-PSK" == $$(cf.security_type).val()) {
    if (0 == checkWpa3SAEPWD(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
    (cf.wl_hidden_sec_type.value = 7),
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
  } else if ("AUTO-WPA3-PSK" == $$(cf.security_type).val()) {
    if (0 == checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)) return !1;
    (cf.wl_hidden_sec_type.value = 8),
      (cf.wl_hidden_wpa_psk.value = cf.passphrase.value);
  } else cf.wl_hidden_sec_type.value = 1;

  if ("2" == wl_simple_mode || "3" == wl_simple_mode)
    if ("WEP" == $$(cf.security_type).val() || "WPA-PSK" == $$(cf.security_type).val()) {
      if (!haven_alert_tkip) {
        if (0 == confirm("$wlan_tkip_300_150")) return !1;
        haven_alert_tkip = 1;
      }
    } else if ("WPA2-PSK" == $$(cf.security_type).val()) {
      if (1 == guest_mode_flag) {
        if ((1, 0 == confirm("$guest_tkip_300_150"))) return !1;
      } else if (
        2 == guest_mode_flag &&
        (1, 0 == confirm("$guest_tkip_aes_300_150"))
      )
        return !1;
    } else if ("AUTO-PSK" == $$(cf.security_type).val()) {
      if (((tag3 = 1), 0 == confirm("$wlan_tkip_aes_300_150"))) return !1;
    } else if ("WPA-Enterprise" == $$(cf.security_type).val()) {
      if ("WPAE-TKIPAES" == cf.wpae_mode.value) {
        if (((tag3 = 1), 0 == confirm("$wlan_tkip_aes_300_150"))) return !1;
      } else if (1 == guest_mode_flag) {
        if ((1, 0 == confirm("$guest_tkip_300_150"))) return !1;
      } else if (
        2 == guest_mode_flag &&
        (1, 0 == confirm("$guest_tkip_aes_300_150"))
      )
        return !1;
    } else if (1 == guest_mode_flag && (1, 0 == confirm("$guest_tkip_300_150")))
      return !1;
  if (
    ("WEP" == $$(cf.security_type).val() &&
      (1 == an_router_flag
        ? "1" == wla_mode && 54 == an_mode1_value
          ? alert("$wep_just_one_ssid_an")
          : 1 == guest_router_flag && alert("$wep_just_one_ssid" + " (2.4GHz).")
        : 1 == guest_router_flag && alert("$wep_just_one_ssid")),
    1 == endis_wl_radio && 0 == cf.ssid_bc.checked)
  ) {
    if (!confirm("$wps_warning1")) return !1;
    haven_wpe = 1;
  }
  return (
    !!(
      1 != endis_wl_radio ||
      ("2" != cf.wl_hidden_sec_type.value &&
        "3" != cf.wl_hidden_sec_type.value) ||
      0 != haven_wpe ||
      confirm("$wps_warning2")
    ) &&
    !("1" == cf.wl_hidden_sec_type.value && !confirm("$wps_warning3")) &&
    !(
      1 == endis_wl_radio &&
      "6" == cf.wl_hidden_sec_type.value &&
      0 == haven_wpe &&
      !confirm("$wpae_or_wps")
    ) &&
    !(
      1 == endis_wl_radio &&
      "7" == cf.wl_hidden_sec_type.value &&
      0 == haven_wpe &&
      !confirm("$wpa3_or_wps")
    ) &&
    0 != check_wlan_guest("bgn") &&
    0 != check_wlan_guest_w3("bgn") &&
    (cf.submit(), !0)
  );
}
function check_wlan() {
  var cf = document.forms[0];
  if (cf.w_channel_an.options.length > 0) {
    if (0 == check_dfs()) return !1;
    var WRegion_value = convert_value_to_original(cf, "WRegion");
    if (
      (4 == WRegion_value ||
        (1 == getTop(window).support_second_dfs && 10 == WRegion_value)) &&
      "1" === enable_ht160 &&
      0 == check_dfs_sec()
    )
      return !1;
  }
  if (
    ((cf.wl_apply_flag.value = "1"),
    (cf.wl_WRegion.value = convert_value_to_original(cf, "WRegion")),
    (cf.qca_wireless_region.value =
      qca_region_arr[parseInt(cf.wl_WRegion.value)]),
    1 == wds_endis_fun && 0 == cf.w_channel.selectedIndex)
  )
    return alert("$wds_auto_channel"), !1;
  (cf.wl_hidden_wlan_channel.value = cf.w_channel.value),
    1 == cf.enable_coexistence.checked
      ? (cf.hid_enable_coexist.value = "0")
      : (cf.hid_enable_coexist.value = "1");
  var opmode_value = convert_value_to_original(cf, "opmode");
  if (((cf.wl_hidden_wlan_mode.value = opmode_value), 1 == an_router_flag)) {
    (cf.wla_hidden_wlan_channel.value = cf.w_channel_an.value),
      "none" !== document.getElementById("sec_channel_tr").style.display &&
        (cf.wla_hidden_sec_channel.value = cf.w_channel_an_sec.value);
    var channel_select_index = cf.w_channel_an.selectedIndex;
    cf.w_channel_an.options.length > 0 &&
      -1 != cf.w_channel_an.options[channel_select_index].text.indexOf("DFS") &&
      (cf.wla_hidden_sel_dfs.value = "1");
    var opmode_an_value = convert_value_to_original(cf, "opmode_an");
    (cf.wla_hidden_wlan_mode.value = opmode_an_value),
      parent.an_mode3_value > 150 &&
        1 != wla_disablecoext &&
        "1" != opmode_an_value &&
        "2" != opmode_an_value &&
        1 != flad_op &&
        alert(an_msg);
    cf.w_channel_an.value, cf.wl_WRegion.value;
  }
  var flad_op = !1;
  return (
    parent.bgn_mode3_value > 150 &&
      1 == cf.enable_coexistence.checked &&
      "1" != opmode_value &&
      "2" != opmode_value &&
      ((flad_op = !0), alert(msg)),
    1 == cf.enable_ax.checked
      ? (cf.hid_wla_ax.value = "1")
      : (cf.hid_wla_ax.value = "0"),
    1 == cf.enable_ax.checked &&
      (1 == cf.ofdma_2g.checked
        ? (cf.hid_ofdma_2g.value = "1")
        : (cf.hid_ofdma_2g.value = "0"),
      1 == cf.ofdma_5g.checked
        ? (cf.hid_ofdma_5g.value = "1")
        : (cf.hid_ofdma_5g.value = "0")),
    "1" == smart_connect_flag &&
      cf.enable_smart_connect.checked &&
      (cf.hid_enable_smart_connect.value = "1"),
    !0
  );
}
function check_wlan_guest(type) {
  var cf = document.forms[0],
    ssid = document.forms[0].w2_ssid.value;
  cf.ssid_w2.value = ssid;
  var wl_ssid = document.forms[0].ssid.value;
  if ("" == ssid) return alert("$ssid_null"), !1;
  if (ssid == wl_ssid) return alert("$ssid_not_allowed_same"), !1;
  for (i = 0; i < ssid.length; i++)
    if (0 == isValidChar_space(ssid.charCodeAt(i)))
      return alert(ssid + "$ssid_not_allowed"), !1;
  if (
    (1 == cf.enable_ssid_bc_w2.checked
      ? (cf.wlg1_enable_ssid_broadcast.value = 1)
      : (cf.wlg1_enable_ssid_broadcast.value = 0),
    "2" == wireless_sectype && "WEP" == $$(cf.security_type_w2).val())
  )
    return (
      1 == parent.an_router_flag
        ? "1" == wl_simple_mode_an && 54 == an_mode1_value
          ? alert("$wep_just_one_ssid_an")
          : alert("$wep_just_one_ssid" + " (2.4GHz).")
        : alert("$wep_just_one_ssid"),
      !1
    );
  if ("WEP" == $$(cf.security_type_w2).val())
    (cf.hidden_sec_type.value = 2),
      1 == parent.an_router_flag
        ? "1" == wl_simple_mode_an && 54 == an_mode1_value
          ? alert("$wep_just_one_ssid_an")
          : alert("$wep_just_one_ssid" + " (2.4GHz).")
        : alert("$wep_just_one_ssid");
  else if ("WPA2-PSK" == $$(cf.security_type_w2).val()) {
    if (0 == checkpsk(cf.w2_passphrase, cf.sec_wpaphrase_len_w2)) return !1;
    (cf.hidden_sec_type.value = 4),
      (cf.hidden_wpa_psk.value = cf.w2_passphrase.value);
  } else if ("AUTO-PSK" == $$(cf.security_type_w2).val()) {
    if (0 == checkpsk(cf.w2_passphrase, cf.sec_wpaphrase_len_w2)) return !1;
    if ("1" != wl_simple_mode && 0 == tag3) {
      if (0 == confirm("$wlan_tkip_aes_300_150")) return !1;
      tag3 = 1;
    }
    (cf.hidden_sec_type.value = 5),
      (cf.hidden_wpa_psk.value = cf.w2_passphrase.value);
  } else if ("WPA-Enterprise" == $$(cf.security_type_w2).val()) {
    if ("WPAE-TKIP" == cf.wpae_mode_w2.value) {
      if ("1" != wl_simple_mode && !haven_alert_tkip) {
        if (0 == confirm("$wlan_tkip_300_150")) return !1;
        haven_alert_tkip = 1;
      }
    } else if ("WPAE-TKIPAES" == cf.wpae_mode_w2.value) {
      if ("1" != wl_simple_mode && 0 == tag3) {
        if (0 == confirm("$wlan_tkip_aes_300_150")) return !1;
        tag3 = 1;
      }
      cf.textWpaeRadiusPort_w2.value = port_range_interception(
        cf.textWpaeRadiusPort_w2.value
      );
    }
    if (
      ((radiusServerIP =
        cf.radiusIPAddr1_w2.value +
        "." +
        cf.radiusIPAddr2_w2.value +
        "." +
        cf.radiusIPAddr3_w2.value +
        "." +
        cf.radiusIPAddr4_w2.value),
      "" == radiusServerIP || 0 == checkipaddr(radiusServerIP))
    )
      return alert("$invalid_ip"), !1;
    if (
      0 == isSameSubNet(radiusServerIP, lanSubnet, lanIP, lanSubnet) &&
      0 == isSameSubNet(radiusServerIP, wanSubnet, wanIP, wanSubnet)
    )
      return alert("$invalid_ip"), !1;
    if (1 == isSameIp(lanIP, radiusServerIP)) return alert("$invalid_ip"), !1;
    if (1 == isSameIp(wanIP, radiusServerIP))
      return alert("$conflicted_with_wanip"), !1;
    if (
      ((cf.radiusServerIP_w2.value = radiusServerIP),
      (radiusPort = parseInt(cf.textWpaeRadiusPort_w2.value, 10)),
      isNaN(radiusPort) || radiusPort < 1 || radiusPort > 65535)
    )
      return alert("$radiusPort65535"), !1;
    if (
      ((cf.textWpaeRadiusPort_w2.value = radiusPort),
      "" == cf.w2_textWpaeRadiusSecret.value)
    )
      return alert("$radiusSecret64"), !1;
    if (cf.w2_textWpaeRadiusSecret.value.length > 64)
      return alert("$radiusSecret64"), !1;
    for (i = 0; i < cf.w2_textWpaeRadiusSecret.value.length; i++)
      if (0 == isValidChar(cf.w2_textWpaeRadiusSecret.value.charCodeAt(i)))
        return (
          alert("$radiusSecret64"), cf.w2_textWpaeRadiusSecret.focus(), !1
        );
    (cf.hidden_WpaeRadiusSecret_w2.value = cf.w2_textWpaeRadiusSecret.value),
      (cf.hidden_sec_type.value = 6);
  } else if ("WPA3-PSK" == $$(cf.security_type_w2).val()) {
    if (0 == checkWpa3SAEPWD(cf.w2_passphrase, cf.sec_wpaphrase_len_w2)) return !1;
    (cf.hidden_sec_type.value = 7),
      (cf.hidden_wpa_psk.value = cf.w2_passphrase.value);
  } else if ("AUTO-WPA3-PSK" == $$(cf.security_type_w2).val()) {
    if (0 == checkpsk(cf.w2_passphrase, cf.sec_wpaphrase_len_w2)) return !1;
    (cf.hidden_sec_type.value = 8),
      (cf.hidden_wpa_psk.value = cf.w2_passphrase.value);
  } else cf.hidden_sec_type.value = 1;
  1 == cf.Allow_to_wired2[0].checked
    ? (cf.hid_allow_to_wired2.value = "1")
    : (cf.hid_allow_to_wired2.value = "0");
}
function check_wlan_guest_w3(type) {
  var cf = document.forms[0],
    ssid = document.forms[0].w3_ssid.value;
  cf.ssid_w3.value = ssid;
  var wl_ssid = document.forms[0].ssid.value;
  if ("" == ssid) return alert("$ssid_null"), !1;
  if (ssid == wl_ssid) return alert("$ssid_not_allowed_same"), !1;
  for (i = 0; i < ssid.length; i++)
    if (0 == isValidChar_space(ssid.charCodeAt(i)))
      return alert(ssid + "$ssid_not_allowed"), !1;
  if (
    (1 == cf.enable_ssid_bc_w3.checked
      ? (cf.wlg2_enable_ssid_broadcast.value = 1)
      : (cf.wlg2_enable_ssid_broadcast.value = 0),
    "2" == wireless_sectype && "WEP" == $$(cf.security_type_w3).val())
  )
    return (
      1 == parent.an_router_flag
        ? "1" == wl_simple_mode_an && 54 == an_mode1_value
          ? alert("$wep_just_one_ssid_an")
          : alert("$wep_just_one_ssid" + " (2.4GHz).")
        : alert("$wep_just_one_ssid"),
      !1
    );
  if ("WEP" == $$(cf.security_type_w3).val())
    (cf.hidden_sec_type_w3.value = 2),
      1 == parent.an_router_flag
        ? "1" == wl_simple_mode_an && 54 == an_mode1_value
          ? alert("$wep_just_one_ssid_an")
          : alert("$wep_just_one_ssid" + " (2.4GHz).")
        : alert("$wep_just_one_ssid");
  else if ("WPA2-PSK" == $$(cf.security_type_w3).val()) {
    if (0 == checkpsk(cf.w3_passphrase, cf.sec_wpaphrase_len_w3)) return !1;
    (cf.hidden_sec_type_w3.value = 4),
      (cf.hidden_wpa_psk_w3.value = cf.w3_passphrase.value);
  } else if ("AUTO-PSK" == $$(cf.security_type_w3).val()) {
    if (0 == checkpsk(cf.w3_passphrase, cf.sec_wpaphrase_len_w3)) return !1;
    if (
      "1" != wl_simple_mode &&
      0 == tag3 &&
      0 == confirm("$wlan_tkip_aes_300_150")
    )
      return !1;
    (cf.hidden_sec_type_w3.value = 5),
      (cf.hidden_wpa_psk_w3.value = cf.w3_passphrase.value);
  } else if ("WPA-Enterprise" == $$(cf.security_type_w3).val()) {
    if ("WPAE-TKIP" == cf.wpae_mode_w3.value) {
      if ("1" != wl_simple_mode && !haven_alert_tkip) {
        if (0 == confirm("$wlan_tkip_300_150")) return !1;
        haven_alert_tkip = 1;
      }
    } else if ("WPAE-TKIPAES" == cf.wpae_mode_w3.value) {
      if (
        "1" != wl_simple_mode &&
        0 == tag3 &&
        0 == confirm("$wlan_tkip_aes_300_150")
      )
        return !1;
      cf.textWpaeRadiusPort_w3.value = port_range_interception(
        cf.textWpaeRadiusPort_w3.value
      );
    }
    if (
      ((radiusServerIP =
        cf.radiusIPAddr1_w3.value +
        "." +
        cf.radiusIPAddr2_w3.value +
        "." +
        cf.radiusIPAddr3_w3.value +
        "." +
        cf.radiusIPAddr4_w3.value),
      "" == radiusServerIP || 0 == checkipaddr(radiusServerIP))
    )
      return alert("$invalid_ip"), !1;
    if (
      0 == isSameSubNet(radiusServerIP, lanSubnet, lanIP, lanSubnet) &&
      0 == isSameSubNet(radiusServerIP, wanSubnet, wanIP, wanSubnet)
    )
      return alert("$invalid_ip"), !1;
    if (1 == isSameIp(lanIP, radiusServerIP)) return alert("$invalid_ip"), !1;
    if (1 == isSameIp(wanIP, radiusServerIP))
      return alert("$conflicted_with_wanip"), !1;
    if (
      ((cf.radiusServerIP_w3.value = radiusServerIP),
      (radiusPort = parseInt(cf.textWpaeRadiusPort_w3.value, 10)),
      isNaN(radiusPort) || radiusPort < 1 || radiusPort > 65535)
    )
      return alert("$radiusPort65535"), !1;
    if (
      ((cf.textWpaeRadiusPort_w3.value = radiusPort),
      "" == cf.w3_textWpaeRadiusSecret.value)
    )
      return alert("$radiusSecret64"), !1;
    if (cf.w3_textWpaeRadiusSecret.value.length > 64)
      return alert("$radiusSecret64"), !1;
    for (i = 0; i < cf.w3_textWpaeRadiusSecret.value.length; i++)
      if (0 == isValidChar(cf.w3_textWpaeRadiusSecret.value.charCodeAt(i)))
        return (
          alert("$radiusSecret64"), cf.w3_textWpaeRadiusSecret.focus(), !1
        );
    (cf.hidden_WpaeRadiusSecret_w3.value = cf.w3_textWpaeRadiusSecret.value),
      (cf.hidden_sec_type_w3.value = 6);
  } else if ("WPA3-PSK" == $$(cf.security_type_w3).val()) {
    if (0 == checkWpa3SAEPWD(cf.w3_passphrase, cf.sec_wpaphrase_len_w3)) return !1;
    (cf.hidden_sec_type_w3.value = 7),
      (cf.hidden_wpa_psk_w3.value = cf.w3_passphrase.value);
  } else if ("AUTO-WPA3-PSK" == $$(cf.security_type_w3).val()) {
    if (0 == checkpsk(cf.w3_passphrase, cf.sec_wpaphrase_len_w3)) return !1;
    (cf.hidden_sec_type_w3.value = 8),
      (cf.hidden_wpa_psk_w3.value = cf.w3_passphrase.value);
  } else cf.hidden_sec_type_w3.value = 1;
  1 == cf.Allow_to_wired3[0].checked
    ? (cf.hid_allow_to_wired3.value = "1")
    : (cf.hid_allow_to_wired3.value = "0");
}
var ht20_array = new Array(
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "136(DFS)",
      "140(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(""),
    new Array("149", "153", "157", "161", "165"),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52",
      "56",
      "60",
      "64",
      "132",
      "136",
      "140",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)",
      "149",
      "153",
      "157",
      "161",
      "165"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "140(DFS)"
    )
  ),
  ht40_array = new Array(
    new Array(""),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(""),
    new Array("149", "153", "157", "161"),
    new Array(""),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52",
      "56",
      "60",
      "64",
      "132",
      "136",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "132(DFS)",
      "136(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "132(DFS)",
      "136(DFS)"
    )
  ),
  ht80_array = new Array(
    new Array(""),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(""),
    new Array("149", "153", "157", "161"),
    new Array(""),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52",
      "56",
      "60",
      "64",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "149",
      "153",
      "157",
      "161"
    ),
    new Array(
      "36",
      "40",
      "44",
      "48",
      "52(DFS)",
      "56(DFS)",
      "60(DFS)",
      "64(DFS)",
      "100(DFS)",
      "104(DFS)",
      "108(DFS)",
      "112(DFS)",
      "116(DFS)",
      "120(DFS)",
      "124(DFS)",
      "128(DFS)"
    )
  ),
  ht20_array10 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "140(DFS)",
    "144(DFS)",
    "149",
    "153",
    "157",
    "161",
    "165"
  ),
  ht40_array10 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "140(DFS)",
    "144(DFS)",
    "149",
    "153",
    "157",
    "161"
  );
if ("1" == getTop(window).use_orbi_style_flag)
  var ht160_array10 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "140(DFS)",
    "144(DFS)",
    "149",
    "153",
    "157",
    "161"
  );
else
  ht160_array10 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "140(DFS)",
    "149",
    "153",
    "157",
    "161"
  );
var ht160_array11 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "149",
    "153",
    "157",
    "161"
  ),
  ht160_array2 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)"
  ),
  ht160_array4 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)"
  );
"1" == getTop(window).use_orbi_style_flag &&
  ((ht20_array[20] = ht20_array[22] = ht20_array[23] = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "140(DFS)",
    "149",
    "153",
    "157",
    "161",
    "165"
  )),
  (ht40_array[20] = ht40_array[22] = ht40_array[23] = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "132(DFS)",
    "136(DFS)",
    "149",
    "153",
    "157",
    "161"
  )),
  (ht80_array[20] = ht80_array[22] = ht80_array[23] = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)",
    "149",
    "153",
    "157",
    "161"
  )),
  (ht160_array23 = new Array(
    "36",
    "40",
    "44",
    "48",
    "52(DFS)",
    "56(DFS)",
    "60(DFS)",
    "64(DFS)",
    "100(DFS)",
    "104(DFS)",
    "108(DFS)",
    "112(DFS)",
    "116(DFS)",
    "120(DFS)",
    "124(DFS)",
    "128(DFS)"
  )));
