function check_static_ip_mask_gtw() {
  return (
    (form = document.forms[0]),
    (form.hid_bridge_ipaddr.value =
      form.SPethr1.value +
      "." +
      form.SPethr2.value +
      "." +
      form.SPethr3.value +
      "." +
      form.SPethr4.value),
    (form.hid_bridge_subnet.value =
      form.SMask1.value +
      "." +
      form.SMask2.value +
      "." +
      form.SMask3.value +
      "." +
      form.SMask4.value),
    (form.hid_bridge_gateway.value =
      form.SGateway1.value +
      "." +
      form.SGateway2.value +
      "." +
      form.SGateway3.value +
      "." +
      form.SGateway4.value),
    0 == checkipaddr(form.hid_bridge_ipaddr.value) ||
    0 ==
      is_sub_or_broad(
        form.hid_bridge_ipaddr.value,
        form.hid_bridge_ipaddr.value,
        form.hid_bridge_subnet.value
      )
      ? (alert("$invalid_ip"), !1)
      : 0 == checksubnet(form.hid_bridge_subnet.value, 0)
      ? (alert("$invalid_mask"), !1)
      : 0 == checkgateway(form.hid_bridge_gateway.value)
      ? (alert("$invalid_gateway"), !1)
      : 0 ==
        isGateway(
          form.hid_bridge_ipaddr.value,
          form.hid_bridge_subnet.value,
          form.hid_bridge_gateway.value
        )
      ? (alert("$invalid_gateway"), !1)
      : 1 ==
        isSameIp(form.hid_bridge_ipaddr.value, form.hid_bridge_gateway.value)
      ? (alert("$invalid_gateway"), !1)
      : 0 !=
          isSameSubNet(
            form.hid_bridge_ipaddr.value,
            form.hid_bridge_subnet.value,
            form.hid_bridge_gateway.value,
            form.hid_bridge_subnet.value
          ) || (alert("$same_subnet_ip_gtw"), !1)
  );
}
function check_static_dns(wan_assign) {
  var form = document.forms[0];
  return (
    (form.bridge_dnsaddr1.value =
      form.SDAddr1.value +
      "." +
      form.SDAddr2.value +
      "." +
      form.SDAddr3.value +
      "." +
      form.SDAddr4.value),
    (form.bridge_dnsaddr2.value =
      form.SPDAddr1.value +
      "." +
      form.SPDAddr2.value +
      "." +
      form.SPDAddr3.value +
      "." +
      form.SPDAddr4.value),
    (form.hid_bridge_ipaddr.value =
      form.SPethr1.value +
      "." +
      form.SPethr2.value +
      "." +
      form.SPethr3.value +
      "." +
      form.SPethr4.value),
    "..." == form.bridge_dnsaddr1.value && (form.bridge_dnsaddr1.value = ""),
    "..." == form.bridge_dnsaddr2.value && (form.bridge_dnsaddr2.value = ""),
    !!check_DNS(
      form.bridge_dnsaddr1.value,
      form.bridge_dnsaddr2.value,
      wan_assign,
      form.hid_bridge_ipaddr.value
    )
  );
}
function checkbridge(form) {
  if (0 == form.dyn_bridge_get_ip.checked) {
    if (0 == check_static_ip_mask_gtw()) return !1;
    form.hid_dyn_ip.value = "0";
  } else form.hid_dyn_ip.value = "1";
  if (0 == form.dyn_dns.checked) {
    if (0 == check_static_dns(1 == form.dyn_dns.checked)) return !1;
    form.hid_dyn_dns.value = "0";
  } else form.hid_dyn_dns.value = "1";
  form.submit();
}
