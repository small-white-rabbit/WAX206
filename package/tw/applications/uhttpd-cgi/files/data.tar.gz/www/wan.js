function checkwan() {
  var cf = document.forms[0];
  cf.hid_iptv_show_tag.value = have_bridge_iptv;
  var wan_mtu = parseInt(cf.wan_mtu.value, 10);
  if ("1" == basic_type) {
    if (isNaN(wan_mtu) || !(wan_mtu <= 1500 && wan_mtu >= 616))
      return alert("$a_mtu" + "1500"), !1;
  } else if ("0" == ppp_login_type || "3" == ppp_login_type) {
    if (isNaN(wan_mtu) || !(wan_mtu <= 1492 && wan_mtu >= 616))
      return alert("$a_mtu" + "1492"), !1;
  } else if ("1" == ppp_login_type) {
    if (isNaN(wan_mtu) || !(wan_mtu <= 1450 && wan_mtu >= 616))
      return alert("$a_mtu" + "1450"), !1;
  } else if (isNaN(wan_mtu) || !(wan_mtu <= 1500 && wan_mtu >= 616))
    return alert("$a_mtu" + "1500"), !1;
  if (
    ((cf.wan_mtu.value = wan_mtu),
    1 == cf.bri_lan1.checked
      ? (cf.hid_bri_lan1.value = 1)
      : (cf.hid_bri_lan1.value = 0),
    1 == cf.bri_lan2.checked
      ? (cf.hid_bri_lan2.value = 1)
      : (cf.hid_bri_lan2.value = 0),
    1 == cf.bri_lan3.checked
      ? (cf.hid_bri_lan3.value = 1)
      : (cf.hid_bri_lan3.value = 0),
    1 == cf.bri_lan4.checked
      ? (cf.hid_bri_lan4.value = 1)
      : (cf.hid_bri_lan4.value = 0),
    (cf.hid_iptv_mask.value =
      parseInt(cf.hid_bri_lan1.value) +
      parseInt(2 * cf.hid_bri_lan2.value) +
      parseInt(4 * cf.hid_bri_lan3.value) +
      parseInt(8 * cf.hid_bri_lan4.value) +
      parseInt(16 * bri_lan_tag5) +
      parseInt(32 * bri_lan_tag6)),
    1 == cf.brig_ssid1.checked
      ? (cf.hid_brig_ssid1.value = 1)
      : (cf.hid_brig_ssid1.value = 0),
    1 == cf.brig_ssid2.checked
      ? (cf.hid_brig_ssid2.value = 1)
      : (cf.hid_brig_ssid2.value = 0),
    1 == cf.brig_guest_ssid1.checked
      ? (cf.hid_brig_guest_ssid1.value = 1)
      : (cf.hid_brig_guest_ssid1.value = 0),
    1 == cf.brig_guest_ssid2.checked
      ? (cf.hid_brig_guest_ssid2.value = 1)
      : (cf.hid_brig_guest_ssid2.value = 0),
    0 == cf.disable_dos.checked
      ? (cf.spi_value.value = 1)
      : (cf.spi_value.value = 0),
    (cf.dmz_ip.value =
      cf.dmzip1.value +
      "." +
      cf.dmzip2.value +
      "." +
      cf.dmzip3.value +
      "." +
      cf.dmzip4.value),
    1 == cf.dmz_enable.checked)
  ) {
    if (
      ((cf.dmz_value.value = 1),
      0 == checkipaddr(cf.dmz_ip.value) ||
        0 == is_sub_or_broad(cf.dmz_ip.value, lan_ip, lan_mask))
    )
      return alert("$invalid_ip"), !1;
    if (
      ((cf.dmz_ip.value = address_parseInt(cf.dmz_ip.value)),
      1 == isSameIp(lan_ip, cf.dmz_ip.value))
    )
      return alert("$same_dmz_lan_ip"), !1;
    if (0 == isSameSubNet(cf.dmz_ip.value, lan_mask, lan_ip, lan_mask))
      return alert("$diff_lan_this_subnet"), !1;
  } else cf.dmz_value.value = 0;
  return (
    1 == cf.rspToPing.checked
      ? (cf.rspToPing_value.value = 1)
      : (cf.rspToPing_value.value = 0),
    1 == cf.disable_sipalg.checked
      ? (cf.sipalg_value.value = 1)
      : (cf.sipalg_value.value = 0),
    1 == have_igmp &&
      (1 == cf.disable_igmp.checked
        ? (cf.igmp_value.value = 0)
        : (cf.igmp_value.value = 1)),
    1 == have_bt_igmp &&
      (1 == cf.bt_igmp.checked
        ? (cf.bt_igmp_value.value = 1)
        : (cf.bt_igmp_value.value = 0)),
    cf.submit(),
    !0
  );
}
function checkdmzip() {
  var cf = document.forms[0];
  cf.dmz_enable.checked
    ? ((cf.dmzip1.disabled = !1),
      (cf.dmzip2.disabled = !1),
      (cf.dmzip3.disabled = !1),
      (cf.dmzip4.disabled = !1))
    : ((cf.dmzip1.disabled = !0),
      (cf.dmzip2.disabled = !0),
      (cf.dmzip3.disabled = !0),
      (cf.dmzip4.disabled = !0));
}
function change_bt_igmp_status() {
  var cf = document.forms[0];
  1 == cf.disable_igmp.checked &&
    ((cf.bt_igmp.disabled = !0), (cf.bt_igmp.checked = !1)),
    0 == cf.disable_igmp.checked && (cf.bt_igmp.disabled = !1);
}
