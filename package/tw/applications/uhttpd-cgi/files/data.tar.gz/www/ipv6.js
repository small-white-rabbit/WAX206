function show_ipv6_ip(ip) {
  var show_ip,
    cell_ip,
    pre_ip,
    suf_ip,
    length,
    cell_num,
    char_num,
    blank_num,
    i;
  if ((show_ip = ip.split("/")).length > 1) {
    if (parseInt(show_ip[1]) >= 128)
      return void document.write(
        "<u>" + show_ip[0] + "</u>" + "/" + show_ip[1]
      );
    for (
      length = Math.ceil(parseInt(show_ip[1]) / 4),
        cell_num = Math.floor(length / 4),
        char_num = length % 4,
        cell_ip = show_ip[0].split(":"),
        blank_num = -1,
        i = 0;
      i < cell_ip.length;
      i++
    )
      "" == cell_ip[i] && (blank_num = i);
    for (
      blank_length = 8 - cell_ip.length,
        cell_num > blank_num + blank_length
          ? (cell_num -= blank_length)
          : blank_num < cell_num &&
            cell_num <= blank_num + blank_length &&
            (cell_num = blank_num),
        char_num -= 4 - cell_ip[cell_num].length,
        pre_ip = "",
        i = 0;
      i < cell_num;
      i++
    )
      pre_ip = pre_ip + cell_ip[i] + ":";
    for (
      char_num > 0
        ? ((pre_ip += cell_ip[cell_num].substring(0, char_num)),
          (suf_ip = cell_ip[cell_num].substring(
            char_num,
            cell_ip[cell_num].length
          )))
        : (suf_ip = cell_ip[cell_num]),
        i = cell_num + 1;
      i < cell_ip.length;
      i++
    )
      suf_ip = suf_ip + ":" + cell_ip[i];
    for (i = pre_ip.length - 1; i >= 0 && ":" == pre_ip[i]; i--)
      suf_ip = ":" + suf_ip;
    (pre_ip = pre_ip.substring(0, i + 1)),
      document.write("<u>" + pre_ip + "</u>" + suf_ip + "/" + show_ip[1]);
  } else document.write(ip);
}
function ipv6_write_ip(ipv6_ip_addr) {
  if (
    ("" != ipv6_ip_addr && (ipv6_ip_addr = remove_space(ipv6_ip_addr)),
    "" == ipv6_ip_addr)
  )
    document.write(
      "<TR><TD nowrap>$spacebar" + "$ipv6_not_available</TD></TR>"
    );
  else {
    var i,
      each_ip = ipv6_ip_addr.split(" ");
    for (i = 0; i < each_ip.length; i++)
      document.write("<TR><TD nowrap>$spacebar"),
        show_ipv6_ip(each_ip[i]),
        document.write("</TD></TR>");
  }
}
function ipv6_write_dns(ipv6_ip_addr, pppoe_get_dns1, pppoe_get_dns2) {
  "" == ipv6_ip_addr
    ? document.write(
        "<TR><TD nowrap>$spacebar" + "$ipv6_not_available</TD></TR>"
      )
    : "" == pppoe_get_dns1 && "" == pppoe_get_dns2
    ? document.write(
        "<TR><TD nowrap>$spacebar" + "$ipv6_not_available</TD></TR>"
      )
    : ("" != pppoe_get_dns1 &&
        (document.write("<TR><TD nowrap>$spacebar"),
        document.write(pppoe_get_dns1),
        document.write("</TD></TR>")),
      "" != pppoe_get_dns2 &&
        (document.write("<TR><TD nowrap>$spacebar"),
        document.write(pppoe_get_dns2),
        document.write("</TD></TR>")));
}
function ipv6_load_common(cf) {
  "1" == ipv6_ip_assign
    ? (cf.IpAssign[0].checked = !0)
    : "0" == ipv6_ip_assign && (cf.IpAssign[1].checked = !0),
    "1" == ipv6_interface_type
      ? (cf.useInterfaceId.checked = !0)
      : (cf.useInterfaceId.checked = !1),
    set_interface();
  var interface_id_array = ipv6_interface_id.split(":");
  (cf.IPv6_interface_id1.value = interface_id_array[0]),
    (cf.IPv6_interface_id2.value = interface_id_array[1]),
    (cf.IPv6_interface_id3.value = interface_id_array[2]),
    (cf.IPv6_interface_id4.value = interface_id_array[3]),
    0 == ipv6_cone_fitering
      ? (cf.IPv6Filtering[0].checked = !0)
      : 1 == ipv6_cone_fitering && (cf.IPv6Filtering[1].checked = !0);
}
function ipv6_save_common(cf) {
  var i;
  if (
    (1 == cf.IpAssign[0].checked
      ? (cf.ipv6_hidden_ip_assign.value = "1")
      : (cf.ipv6_hidden_ip_assign.value = "0"),
    1 == cf.useInterfaceId.checked)
  )
    for (
      cf.ipv6_hidden_enable_interface.value = "1",
        cf.ipv6_hidden_interface_id.value = "",
        i = 1;
      i <= 4;
      i++
    ) {
      var interface_value = eval(
        'document.getElementsByName("IPv6_interface_id' + i + '")[0]'
      ).value;
      if (0 == check_ipv6_IP_address(interface_value))
        return alert("$ipv6_invalid_interface_id"), !1;
      if (("" == interface_value && (interface_value = "0"), i < 4))
        cf.ipv6_hidden_interface_id.value =
          cf.ipv6_hidden_interface_id.value + interface_value + ":";
      else if (4 == i) {
        if ("0" == interface_value)
          return alert("$ipv6_invalid_interface_id"), !1;
        cf.ipv6_hidden_interface_id.value =
          cf.ipv6_hidden_interface_id.value + interface_value;
      }
    }
  else cf.ipv6_hidden_enable_interface.value = "0";
  return (
    1 == cf.IPv6Filtering[0].checked
      ? (cf.ipv6_hidden_filtering.value = "0")
      : 1 == cf.IPv6Filtering[1].checked &&
        (cf.ipv6_hidden_filtering.value = "1"),
    !0
  );
}
function set_interface() {
  var cf = document.forms[0];
  1 == cf.useInterfaceId.checked
    ? ((cf.IPv6_interface_id1.disabled = !1),
      (cf.IPv6_interface_id2.disabled = !1),
      (cf.IPv6_interface_id3.disabled = !1),
      (cf.IPv6_interface_id4.disabled = !1))
    : 0 == cf.useInterfaceId.checked &&
      ((cf.IPv6_interface_id1.disabled = !0),
      (cf.IPv6_interface_id2.disabled = !0),
      (cf.IPv6_interface_id3.disabled = !0),
      (cf.IPv6_interface_id4.disabled = !0));
}
function check_ipv6_DNS_address(ipv6_dns_value) {
  var i;
  if ("" != ipv6_dns_value)
    for (i = 0; i < ipv6_dns_value.length; ) {
      if (
        !(
          (ipv6_dns_value.charAt(i) >= "0" &&
            ipv6_dns_value.charAt(i) <= "9") ||
          (ipv6_dns_value.charAt(i) >= "a" &&
            ipv6_dns_value.charAt(i) <= "f") ||
          (ipv6_dns_value.charAt(i) >= "A" && ipv6_dns_value.charAt(i) <= "F")
        )
      )
        return !1;
      i++;
    }
  return !0;
}
function check_ipv6_IP_address(ipv6_ip_value) {
  var i;
  if ("" != ipv6_ip_value)
    for (i = 0; i < ipv6_ip_value.length; ) {
      if (
        !(
          (ipv6_ip_value.charAt(i) >= "0" && ipv6_ip_value.charAt(i) <= "9") ||
          (ipv6_ip_value.charAt(i) >= "a" && ipv6_ip_value.charAt(i) <= "f") ||
          (ipv6_ip_value.charAt(i) >= "A" && ipv6_ip_value.charAt(i) <= "F")
        )
      )
        return !1;
      i++;
    }
  return !0;
}
function change_conn_type_name(conn_type) {
  return "Detecting..." == conn_type
    ? "$ipv6_detecting"
    : "6to4 Tunnel" == conn_type
    ? "$ipv6_6to4_tunnel"
    : "Pass Through" == conn_type
    ? "$ipv6_pass_through"
    : "Auto Config" == conn_type
    ? "$ipv6_auto_config"
    : "DHCP" == conn_type
    ? "$router_status_dhcp"
    : conn_type;
}
function setIPv6DNS(cf) {
  var dflag = cf.DNSAssign[0].checked;
  for (i = 1; i <= 8; i++)
    (eval('document.getElementsByName("PDAddr' + i + '")[0]').disabled = dflag),
      (eval(
        'document.getElementsByName("SDAddr' + i + '")[0]'
      ).disabled = dflag);
}
function check_addr_legality(value) {
  return (
    ("f" != value.charAt(0).toLowerCase() ||
      "f" != value.charAt(1).toLowerCase()) &&
    ":::::::1" != value &&
    "0:0:0:0:0:0:0:1" != value
  );
}
function checkIPv6DNS(cf) {
  if (cf.DNSAssign[1].checked) {
    (cf.ipv6_hidden_primary_dns.value = ""),
      (cf.ipv6_hidden_second_dns.value = "");
    var check_pri_dns = 1,
      check_sec_dns = 1,
      pri_dns = "",
      sec_dns = "";
    for (i = 1; i <= 8; i++)
      (pri_dns += eval('document.getElementsByName("PDAddr' + i + '")[0]')
        .value),
        (sec_dns += eval('document.getElementsByName("SDAddr' + i + '")[0]')
          .value);
    if (
      ("" == pri_dns && (check_pri_dns = 0),
      "" == sec_dns && (check_sec_dns = 0),
      0 == check_pri_dns && 0 == check_sec_dns)
    )
      return alert("$dns_must_specified"), !1;
    for (i = 1; i <= 8; i++) {
      if (check_pri_dns) {
        var pri_dns_value = eval(
          'document.getElementsByName("PDAddr' + i + '")[0]'
        ).value;
        if (0 == check_ipv6_DNS_address(pri_dns_value))
          return alert("$invalid_ipv6_primary_dns_hex"), !1;
        "" != pri_dns_value &&
          (pri_dns_value = parseInt(pri_dns_value, 16).toString(16)),
          (cf.ipv6_hidden_primary_dns.value =
            "" == pri_dns_value
              ? cf.ipv6_hidden_primary_dns.value + "0" + ":"
              : cf.ipv6_hidden_primary_dns.value + pri_dns_value + ":");
      }
      if (check_sec_dns) {
        var sec_dns_value = eval(
          'document.getElementsByName("SDAddr' + i + '")[0]'
        ).value;
        if (0 == check_ipv6_DNS_address(sec_dns_value))
          return alert("$invalid_ipv6_second_dns_hex"), !1;
        "" != sec_dns_value &&
          (sec_dns_value = parseInt(sec_dns_value, 16).toString(16)),
          (cf.ipv6_hidden_second_dns.value =
            "" == sec_dns_value
              ? cf.ipv6_hidden_second_dns.value + "0" + ":"
              : cf.ipv6_hidden_second_dns.value + sec_dns_value + ":");
      }
    }
    var str = cf.ipv6_hidden_primary_dns.value;
    if (
      ((cf.ipv6_hidden_primary_dns.value = str.substring(0, str.length - 1)),
      ":::::::" == cf.ipv6_hidden_primary_dns.value)
    )
      cf.ipv6_hidden_primary_dns.value = "";
    else if ("0:0:0:0:0:0:0:0" == cf.ipv6_hidden_primary_dns.value)
      return alert("$invalid_ipv6_primary_dns"), !1;
    if (
      "" != cf.ipv6_hidden_primary_dns.value &&
      0 == check_addr_legality(cf.ipv6_hidden_primary_dns.value)
    )
      return alert("$invalid_ipv6_primary_dns"), !1;
    if (
      ((str = cf.ipv6_hidden_second_dns.value),
      (cf.ipv6_hidden_second_dns.value = str.substring(0, str.length - 1)),
      ":::::::" == cf.ipv6_hidden_second_dns.value)
    )
      cf.ipv6_hidden_second_dns.value = "";
    else if ("0:0:0:0:0:0:0:0" == cf.ipv6_hidden_second_dns.value)
      return alert("$invalid_ipv6_second_dns"), !1;
    if ("" != cf.ipv6_hidden_second_dns.value) {
      if (0 == check_addr_legality(cf.ipv6_hidden_second_dns.value))
        return alert("$invalid_ipv6_second_dns"), !1;
      if (cf.ipv6_hidden_primary_dns.value == cf.ipv6_hidden_second_dns.value)
        return alert("$invalid_primary_second_dns"), !1;
    }
  }
}
function load_ipv6_dns(cf) {
  if (
    ("0" == get_dns_assign
      ? (cf.DNSAssign[0].checked = !0)
      : (cf.DNSAssign[1].checked = !0),
    setIPv6DNS(cf),
    "" != ipv6_get_dns1)
  ) {
    var ipv6_primary_dns = ipv6_get_dns1.split(":");
    for (i = 1; i <= ipv6_primary_dns.length; i++)
      "" == ipv6_primary_dns[i - 1]
        ? (eval('document.getElementsByName("PDAddr' + i + '")[0]').value = "0")
        : (eval('document.getElementsByName("PDAddr' + i + '")[0]').value =
            ipv6_primary_dns[i - 1]);
  }
  if ("" != ipv6_get_dns2) {
    var ipv6_second_dns = ipv6_get_dns2.split(":");
    for (i = 1; i <= ipv6_second_dns.length; i++)
      "" == ipv6_second_dns[i - 1]
        ? (eval('document.getElementsByName("SDAddr' + i + '")[0]').value = "0")
        : (eval('document.getElementsByName("SDAddr' + i + '")[0]').value =
            ipv6_second_dns[i - 1]);
  }
}
function load_mapt() {
  var i,
    cf = document.forms[0];
  "1" == enable_value
    ? (cf.cb_enable.checked = !0)
    : (cf.cb_enable.checked = !1),
    "1" == type_value
      ? (cf.rd_type[1].checked = !0)
      : (cf.rd_type[0].checked = !0);
  var ipv6_ip = local_ipv6.split(":");
  for (i = 0; i < ipv6_ip.length; i++)
    "" == ipv6_ip[i] && "" != local_ipv6
      ? (cf.tx_lol_ipv6[i].value = "0")
      : (cf.tx_lol_ipv6[i].value = ipv6_ip[i]);
  "" == local_ipv6_pre_len && "" != local_ipv6
    ? (cf.tx_lol_ipv6_prefix.value = "0")
    : (cf.tx_lol_ipv6_prefix.value = local_ipv6_pre_len);
  var ipv4_ip = local_ipv4.split(".");
  if (4 == ipv4_ip.length)
    for (i = 0; i < 4; i++) cf.tx_lol_ipv4[i].value = ipv4_ip[i];
  "" == local_ipv4_pre_len && "" != local_ipv4
    ? (cf.tx_lol_ipv4_prefix.value = "0")
    : (cf.tx_lol_ipv4_prefix.value = local_ipv4_pre_len),
    (cf.tx_lol_ea.value = local_ea);
  var r_ipv6 = remote_ipv6.split(":");
  for (i = 0; i < r_ipv6.length; i++)
    "" == r_ipv6[i] && "" != remote_ipv6
      ? (cf.tx_rmo_ipv6[i].value = "0")
      : (cf.tx_rmo_ipv6[i].value = r_ipv6[i]);
  "" == remote_ipv6_pre_len && "" != remote_ipv6
    ? (cf.tx_rmo_ipv6_prefix.value = "0")
    : (cf.tx_rmo_ipv6_prefix.value = remote_ipv6_pre_len),
    (cf.psidoffset.value = loc_psidoffset);
}
function check_ipv6_ip(iptxt, ipvalue) {
  for (var ip = "", i = 0; i < iptxt.length; i++) {
    for (var oneip = iptxt[i].value, j = 0; j < oneip.length; j++)
      if (0 == isValidHex(oneip.charAt(j))) return !1;
    "" != oneip && (oneip = parseInt(oneip, 16).toString(16)),
      (ip = "" == oneip ? ip + "0" + ":" : ip + oneip + ":");
  }
  return (ipvalue.value = ip.substring(0, ip.length - 1)), !0;
}
function check_mapt(cf) {
  if (
    (1 == cf.cb_enable.checked
      ? (cf.hid_cb_enable.value = "1")
      : (cf.hid_cb_enable.value = "0"),
    1 == cf.rd_type[1].checked)
  ) {
    if (!check_ipv6_ip(cf.tx_lol_ipv6, cf.hid_tx_lol_ipv6))
      return alert("$invalid_loc_ipv6_addr"), !1;
    if (
      ((cf.hid_tx_lol_ipv4.value =
        cf.tx_lol_ipv4[0].value +
        "." +
        cf.tx_lol_ipv4[1].value +
        "." +
        cf.tx_lol_ipv4[2].value +
        "." +
        cf.tx_lol_ipv4[3].value),
      0 == checkipaddr(cf.hid_tx_lol_ipv4.value))
    )
      return alert("$invalid_loc_ipv4_addr"), !1;
    if (!check_ipv6_ip(cf.tx_rmo_ipv6, cf.hid_tx_rmo_ipv6))
      return alert("$invalid_remote_ipv6_addr"), !1;
  }
  return !0;
}
function abbr_ipv6(ip) {
  for (
    var ip_array = ip.split(":"), start = -1, end = -1, abbr = "", i = 0;
    i < ip_array.length;
    i++
  )
    if ("0" == ip_array[i]) -1 == start ? (start = i) : (end = i);
    else {
      if (end - start > 0) break;
      (start = -1), (end = -1);
    }
  if (end - start > 0) {
    for (i = 0; i < start; i++) abbr += ip_array[i] + ":";
    abbr += 0 == start ? "::" : ":";
    for (i = end + 1; i < ip_array.length; i++)
      i != ip_array.length - 1
        ? (abbr += ip_array[i] + ":")
        : (abbr += ip_array[i]);
  } else abbr = ip;
  return abbr;
}
function login_type_show(cf) {
  var login_type_list = cf.login_type,
    ipv6_6rd_flag = getTop(window).ipv6_6rd_flag,
    ipv6_auto_detect = getTop(window).ipv6_auto_detect,
    ipv6_dhcp_flag = getTop(window).ipv6_dhcp_flag,
    ipv6_pppoe_flag = getTop(window).ipv6_pppoe_flag,
    have_mape =
      1 == getTop(window).have_mape && 1 == getTop(window).is_jp_version
        ? 1
        : 0;
  if (1 == getTop(window).support_orange_flag)
    if (have_mape)
      var ipv6_items = new Array(
        "disabled",
        "$pppoe2_disable",
        "autoDetect",
        "$ipv6_auto_detect",
        "autoConfig",
        "$ipv6_auto_config",
        "6to4",
        "$ipv6_6to4_tunnel",
        "6rd",
        "6rd",
        "bridge",
        "$ipv6_pass_through",
        "fixed",
        "$ipv6_fixed",
        "dhcp",
        "$router_status_dhcp",
        "pppoe",
        "$basic_intserv_pppoe",
        "orange",
        "Orange France",
        "v6plus",
        "v6plus",
        "dslite",
        "Dual-Stack Lite"
      );
    else
      ipv6_items = new Array(
        "disabled",
        "$pppoe2_disable",
        "autoDetect",
        "$ipv6_auto_detect",
        "autoConfig",
        "$ipv6_auto_config",
        "6to4",
        "$ipv6_6to4_tunnel",
        "6rd",
        "6rd",
        "bridge",
        "$ipv6_pass_through",
        "fixed",
        "$ipv6_fixed",
        "dhcp",
        "$router_status_dhcp",
        "pppoe",
        "$basic_intserv_pppoe",
        "orange",
        "Orange France"
      );
  else if (have_mape)
    ipv6_items = new Array(
      "disabled",
      "$pppoe2_disable",
      "autoDetect",
      "$ipv6_auto_detect",
      "autoConfig",
      "$ipv6_auto_config",
      "6to4",
      "$ipv6_6to4_tunnel",
      "6rd",
      "6rd",
      "bridge",
      "$ipv6_pass_through",
      "fixed",
      "$ipv6_fixed",
      "dhcp",
      "$router_status_dhcp",
      "pppoe",
      "$basic_intserv_pppoe",
      "v6plus",
      "v6plus",
      "dslite",
      "Dual-Stack Lite"
    );
  else
    ipv6_items = new Array(
      "disabled",
      "$pppoe2_disable",
      "autoDetect",
      "$ipv6_auto_detect",
      "autoConfig",
      "$ipv6_auto_config",
      "6to4",
      "$ipv6_6to4_tunnel",
      "6rd",
      "6rd",
      "bridge",
      "$ipv6_pass_through",
      "fixed",
      "$ipv6_fixed",
      "dhcp",
      "$router_status_dhcp",
      "pppoe",
      "$basic_intserv_pppoe"
    );
  var len = 0;
  for (
    login_type_list.options.length = 24, i = 0;
    i < ipv6_items.length;
    i += 2
  ) {
    if (
      !(
        (1 != ipv6_6rd_flag && "6rd" == ipv6_items[i]) ||
        (1 != ipv6_auto_detect && "autoDetect" == ipv6_items[i]) ||
        (1 != ipv6_dhcp_flag && "dhcp" == ipv6_items[i]) ||
        (1 != ipv6_pppoe_flag && "pppoe" == ipv6_items[i])
      )
    )
      if (have_mape || ("v6plus" != ipv6_items[i] && "dslite" != ipv6_items[i]))
        1 == getTop(window).support_orange_flag && "orange" == ipv6_items[i]
          ? "WW" == getTop(window).netgear_region &&
            ((login_type_list.options[len].text = ipv6_items[i + 1]),
            (login_type_list.options[len].value = ipv6_items[i]),
            len++)
          : ((login_type_list.options[len].text = ipv6_items[i + 1]),
            (login_type_list.options[len].value = ipv6_items[i]),
            len++);
  }
  login_type_list.options.length = len;
}
