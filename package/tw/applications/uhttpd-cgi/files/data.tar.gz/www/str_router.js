var invalid_ip = "$invalid_des_ip",
  routes_length_10 = "$routes_length_10",
  routes_name_dup = "$routes_name_dup",
  routes_condition_dup = "$routes_condition_dup",
  routes_name_null = "$routes_name_null",
  routes_diff_wan_gateway = "$routes_diff_wan_gateway",
  routes_metric_error = "$routes_metric_error";
function countmask(num) {
  var i = 0,
    count = 0,
    numArr = [128, 64, 32, 16, 8, 4, 2, 1];
  for (i = 0; i < numArr.length; i++) 0 != (num & numArr[i]) && count++;
  return count;
}
function check_routers_add(cf) {
  if (32 == array_num) return alert("$routes_length_10"), !1;
  location.href = "STR_routes_add.htm";
}
function check_router_add(cf, flag) {
  var name = cf.route_name.value;
  if ("add" == flag && 32 == array_num) return alert("$routes_length_10"), !1;
  if ("" == name) return alert("$routes_name_null"), !1;
  for (i = 0; i < name.length; i++)
    if (0 == isValidChar_space(name.charCodeAt(i)))
      return alert("$invalid_router_name"), !1;
  cf.SRouteDestAddr.value =
    cf.SRouteDestAddr1.value +
    "." +
    cf.SRouteDestAddr2.value +
    "." +
    cf.SRouteDestAddr3.value +
    "." +
    cf.SRouteDestAddr4.value;
  var ipaddr_array = cf.SRouteDestAddr.value.split(".");
  if (
    0 ==
    checkIP(
      ipaddr_array[0],
      ipaddr_array[1],
      ipaddr_array[2],
      ipaddr_array[3],
      254
    )
  )
    return alert("$invalid_des_ip"), !1;
  if ("127" == cf.SRouteDestAddr1.value) return alert("$invalid_des_ip"), !1;
  if (parseInt(ipaddr_array[0]) >= 224) return alert("$invalid_des_ip"), !1;
  if (
    ((cf.SRouteSubnetMask.value =
      cf.SRouteSubnetMask1.value +
      "." +
      cf.SRouteSubnetMask2.value +
      "." +
      cf.SRouteSubnetMask3.value +
      "." +
      cf.SRouteSubnetMask4.value),
    0 == checksubnet(cf.SRouteSubnetMask.value, 1))
  )
    return alert("$invalid_mask"), !1;
  if (
    ((cf.SRouteSubnetMask.value = address_parseInt(cf.SRouteSubnetMask.value)),
    1 ==
      isSameSubNet(
        cf.SRouteDestAddr.value,
        cf.SRouteSubnetMask.value,
        lan_ip,
        cf.SRouteSubnetMask.value
      ) ||
      1 == isSameSubNet(cf.SRouteDestAddr.value, lan_mask, lan_ip, lan_mask))
  )
    return alert("$invalid_des_ip"), !1;
  if (
    "0" == cf.SRouteDestAddr4.value &&
    "255.255.255.255" == cf.SRouteSubnetMask.value
  )
    return alert("$invalid_des_ip"), !1;
  if ("Russian" == gui_region || "RU" == netgear_region.toUpperCase()) {
    if (
      "0.0.0.0" != wan_ip &&
      (1 ==
        isSameSubNet(
          cf.SRouteDestAddr.value,
          cf.SRouteSubnetMask.value,
          wan_ip,
          cf.SRouteSubnetMask.value
        ) ||
        1 ==
          isSameSubNet(cf.SRouteDestAddr.value, wan_mask, wan_ip, wan_mask)) &&
      1 ==
        isSameSubNet(
          cf.SRouteDestAddr.value,
          cf.SRouteSubnetMask.value,
          wan_ip,
          wan_mask
        )
    )
      return alert("$conflicted_with_wanip"), !1;
  } else if (
    "0.0.0.0" != wan_ip &&
    (1 ==
      isSameSubNet(
        cf.SRouteDestAddr.value,
        cf.SRouteSubnetMask.value,
        wan_ip,
        cf.SRouteSubnetMask.value
      ) ||
      1 == isSameSubNet(cf.SRouteDestAddr.value, wan_mask, wan_ip, wan_mask))
  )
    return alert("$conflicted_with_wanip"), !1;
  if (
    ((cf.SRouteGatewayAddr.value =
      cf.SRouteGatewayAddr1.value +
      "." +
      cf.SRouteGatewayAddr2.value +
      "." +
      cf.SRouteGatewayAddr3.value +
      "." +
      cf.SRouteGatewayAddr4.value),
    0 == checkgateway(cf.SRouteGatewayAddr.value) ||
      0 ==
        is_sub_or_broad(
          cf.SRouteGatewayAddr.value,
          cf.SRouteGatewayAddr.value,
          cf.SRouteSubnetMask.value
        ))
  )
    return alert("$invalid_gateway"), !1;
  cf.SRouteGatewayAddr.value = address_parseInt(cf.SRouteGatewayAddr.value);
  var ipArray = cf.SRouteDestAddr.value.split("."),
    subnetArray = cf.SRouteSubnetMask.value.split("."),
    addr = new Array(),
    count = 0;
  for (i = 0; i < 4; i++)
    (addr[i] = ipArray[i] & subnetArray[i]),
      (count += countmask(subnetArray[i]));
  cf.count.value = count;
  var route_dest = addr[0] + "." + addr[1] + "." + addr[2] + "." + addr[3];
  if (
    ((document.forms[0].route_dest.value = route_dest),
    1 == isNaN(parseInt(cf.route_metric.value, 10)) ||
      parseInt(cf.route_metric.value, 10) < 2 ||
      parseInt(cf.route_metric.value, 10) > 15)
  )
    return alert("$routes_metric_error"), !1;
  for (
    cf.route_metric.value = parseInt(cf.route_metric.value, 10), i = 1;
    i <= array_num;
    i++
  ) {
    var str = eval("routerArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((each_info[0] = each_info[0].replace(/&nbsp;/g, " ")),
      (each_info[0] = each_info[0]
        .replace(/&nbsp;/g, " ")
        .replace(/&#38;/g, "&")),
      "edit" == flag)
    ) {
      if (cf.route_name.value == each_info[0] && select_editnum != i)
        return alert("$routes_name_dup"), !1;
      if (route_dest == each_info[3] && select_editnum != i)
        return alert("$routes_condition_dup"), !1;
    } else {
      if (cf.route_name.value == each_info[0])
        return alert("$routes_name_dup"), !1;
      if (route_dest == each_info[3]) return alert("$routes_condition_dup"), !1;
    }
  }
  return (
    0 == cf.SRouteActive.checked
      ? (cf.route_ac.value = 0)
      : (cf.route_ac.value = 1),
    0 == cf.SRoutePrivate.checked
      ? (cf.route_pr.value = 0)
      : (cf.route_pr.value = 1),
    (cf.route_name.value = cf.route_name.value),
    cf.submit(),
    !0
  );
}
function check_router_editnum() {
  if (0 == array_num) return alert("$port_edit"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == document.forms[0].select.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == document.forms[0].select[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_edit"), !1)
    : ((document.forms[0].select_edit.value = select_num),
      (document.forms[0].submit_flag.value = "st_router_editnum"),
      (document.forms[0].anticsrf.value = st_router_editnum_token),
      (document.forms[0].action =
        "/apply.cgi?/STR_routes_edit.htm timestamp=" + ts),
      document.forms[0].submit(),
      !0);
}
function check_router_del() {
  if (0 == array_num)
    return alert("$port_del"), (location.href = "STR_routes.htm"), !1;
  var del_num,
    count_select = 0;
  if (1 == array_num) {
    if (1 != document.forms[0].select.checked)
      return alert("$port_del"), (location.href = "STR_routes.htm"), !1;
    del_num = 1;
  } else {
    for (i = 0; i < array_num; i++)
      1 == document.forms[0].select[i].checked &&
        (count_select++, (del_num = i + 1));
    if (0 == count_select)
      return alert("$port_del"), (location.href = "STR_routes.htm"), !1;
  }
  return (
    (document.forms[0].select_del.value = del_num),
    document.forms[0].submit(),
    !0
  );
}
function check_routers_add2(cf) {
  if (32 == ipv6_array_num) return alert("$routes_length_10"), !1;
  location.href = "STR_routes_add2.htm";
}
function check_router_add2(cf, flag) {
  if ("add" == flag && 32 == ipv6_array_num)
    return alert("$routes_length_10"), !1;
  var name = cf.route_name.value,
    route_dest,
    route_gtw;
  if ("" == name) return alert("$routes_name_null"), !1;
  for (i = 0; i < name.length; i++)
    if (0 == isValidChar_space(name.charCodeAt(i)))
      return alert("$invalid_router_name"), !1;
  if (
    1 == isNaN(parseInt(cf.route_metric.value, 10)) ||
    parseInt(cf.route_metric.value, 10) < 2 ||
    parseInt(cf.route_metric.value, 10) > 15
  )
    return alert("$routes_metric_error"), !1;
  for (
    cf.route_metric.value = parseInt(cf.route_metric.value, 10),
      route_dest = "",
      route_gtw = "",
      i = 0;
    i < cf.SRouteDestAddr.length;
    i++
  ) {
    if (0 == check_ipv6_IP_address(cf.SRouteDestAddr[i].value))
      return alert("$invalid_des_ipv6_hex"), !1;
    if (
      ("" != cf.SRouteDestAddr[i].value
        ? ((cf.SRouteDestAddr[i].value = parseInt(
            cf.SRouteDestAddr[i].value,
            16
          ).toString(16)),
          (route_dest = route_dest + cf.SRouteDestAddr[i].value + ":"))
        : (route_dest = route_dest + "0" + ":"),
      0 == check_ipv6_IP_address(cf.SRouteGatewayAddr[i].value))
    )
      return alert("$invalid_gtw_ipv6_hex"), !1;
    "" != cf.SRouteGatewayAddr[i].value
      ? ((cf.SRouteGatewayAddr[i].value = parseInt(
          cf.SRouteGatewayAddr[i].value,
          16
        ).toString(16)),
        (route_gtw = route_gtw + cf.SRouteGatewayAddr[i].value + ":"))
      : (route_gtw = route_gtw + "0" + ":");
  }
  if (
    ((route_dest = route_dest.substring(0, route_dest.length - 1)),
    (route_gtw = route_gtw.substring(0, route_gtw.length - 1)),
    ":::::::" == route_dest)
  )
    route_dest = "";
  else if ("0:0:0:0:0:0:0:0" == route_dest) return alert("$invalid_des_ip"), !1;
  if (0 == check_addr_legality(route_dest)) return alert("$invalid_des_ip"), !1;
  if (0 == check_ipv6_IP_address(cf.SRouteDestAddrPrefix.value))
    return alert("$invalid_des_ipv6_pre_length"), !1;
  if (
    "" == cf.SRouteDestAddrPrefix.value ||
    parseInt(cf.SRouteDestAddrPrefix.value, 10) > 126 ||
    parseInt(cf.SRouteDestAddrPrefix.value, 10) < 4
  )
    return alert("$invalid_des_ipv6_pre_length"), !1;
  if (":::::::" == route_gtw) route_gtw = "";
  else if ("0:0:0:0:0:0:0:0" == route_gtw) return alert("$invalid_gateway"), !1;
  if (0 == check_addr_legality(route_gtw)) return alert("$invalid_gateway"), !1;
  for (i = 1; i <= ipv6_array_num; i++) {
    var str = eval("ipv6_routerArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((each_info[0] = each_info[0]
        .replace(/&nbsp;/g, " ")
        .replace(/&#38;/g, "&")),
      "edit" == flag)
    ) {
      if (cf.route_name.value == each_info[0] && select_editnum != i)
        return alert("$routes_name_dup"), !1;
      if (route_dest == each_info[2] && select_editnum != i)
        return alert("$routes_condition_dup"), !1;
    } else {
      if (cf.route_name.value == each_info[0])
        return alert("$routes_name_dup"), !1;
      if (route_dest == each_info[2]) return alert("$routes_condition_dup"), !1;
    }
  }
  return (
    (cf.route_name.value = cf.route_name.value),
    (cf.route_dest.value = route_dest),
    (cf.route_dest_pre.value = cf.SRouteDestAddrPrefix.value),
    (cf.route_gtw.value = route_gtw),
    0 == cf.SRouteActive.checked
      ? (cf.route_ac.value = 0)
      : (cf.route_ac.value = 1),
    !0
  );
}
function check_router_editnum2() {
  var select_num,
    count_select = 0;
  if (0 == ipv6_array_num) return alert("$port_edit"), !1;
  if (1 == ipv6_array_num)
    1 == document.forms[1].select.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < ipv6_array_num; i++)
      1 == document.forms[1].select[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$port_edit"), !1)
    : ((document.forms[1].select_edit.value = select_num),
      (document.forms[1].submit_flag.value = "st_router_editnum2"),
      (document.forms[1].anticsrf.value = st_router_editnum2_token),
      (document.forms[1].action =
        "/apply.cgi?/STR_routes_edit2.htm timestamp=" + ts),
      !0);
}
function check_router_del2() {
  var del_num,
    count_select = 0;
  if (0 == ipv6_array_num)
    return alert("$port_del"), (location.href = "STR_routes.htm"), !1;
  if (1 == ipv6_array_num)
    1 == document.forms[1].select.checked && ((del_num = 1), count_select++);
  else
    for (i = 0; i < ipv6_array_num; i++)
      1 == document.forms[1].select[i].checked &&
        (count_select++, (del_num = i + 1));
  return 0 == count_select
    ? (alert("$port_del"), (location.href = "STR_routes.htm"), !1)
    : ((document.forms[1].select_del.value = del_num),
      (document.forms[1].action = "/apply.cgi?/STR_routes.htm timestamp=" + ts),
      !0);
}
