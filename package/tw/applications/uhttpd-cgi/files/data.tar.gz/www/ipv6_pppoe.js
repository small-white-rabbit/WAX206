function change_ipv6_pppoe_password(obj) {
  "password" == obj.type &&
    ("Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : ((obj.outerHTML =
          '<input type="text" name="ipv6_pppoe_passwd" maxlength="64" size="18" onFocus="this.select();" onKeyPress="return getkey(\'ssid\', event)" value="">'),
        document.forms[0].ipv6_pppoe_passwd.focus(),
        document.forms[0].ipv6_pppoe_passwd.focus()));
}
function check_ipv6_pppoe(cf) {
  if (0 == ipv6_save_common(cf)) return !1;
  if (1 == getTop(window).ipv6_dns_manual) {
    if (1 == cf.ipv6_same_info.checked) {
      if ("pppoe" != wan_proto)
        return alert("IPv4 Internet type must be PPPoE."), !1;
      (cf.pppoe_username.value = pppoe_username),
        (cf.pppoe_passwd.value = pppoe_password),
        (cf.pppoe_servername.value = pppoe_servername),
        (cf.pppoe_dod.value = pppoe_dod),
        (cf.ipv6_hidden_sameinfo.value = "1");
    } else {
      if (
        ((cf.ipv6_hidden_sameinfo.value = "0"), "" == cf.pppoe_username.value)
      )
        return alert("$login_name_null"), !1;
      for (i = 0; i < cf.pppoe_username.value.length; i++)
        if (0 == isValidChar(cf.pppoe_username.value.charCodeAt(i)))
          return alert("$loginname_not_allowed"), !1;
      if ("" == cf.pppoe_passwd.value) return alert("$password_null"), !1;
      for (i = 0; i < cf.pppoe_passwd.value.length; i++)
        if (0 == isValidChar(cf.pppoe_passwd.value.charCodeAt(i)))
          return alert("$password_error"), !1;
      for (i = 0; i < cf.pppoe_servername.value.length; i++)
        if (0 == isValidChar(cf.pppoe_servername.value.charCodeAt(i)))
          return alert("$servname_not_allowed"), !1;
    }
    if (0 == checkIPv6DNS(cf)) return !1;
  }
  return !0;
}
function setSameinfo() {
  var cf = document.forms[0];
  1 == cf.ipv6_same_info.checked
    ? ((document.getElementById("login_line").style.display = "none"),
      (document.getElementById("passwd_line").style.display = "none"),
      (document.getElementById("servname_line").style.display = "none"),
      (document.getElementById("conn_mode_line").style.display = "none"),
      (document.getElementById("wan_line_1").style.display = "none"),
      (document.getElementById("wan_line_2").style.display = ""))
    : ((document.getElementById("login_line").style.display = ""),
      (document.getElementById("passwd_line").style.display = ""),
      (document.getElementById("servname_line").style.display = ""),
      (document.getElementById("conn_mode_line").style.display = ""),
      (document.getElementById("wan_line_1").style.display = ""),
      (document.getElementById("wan_line_2").style.display = "none"),
      "" == ipv6_pppoe_pwd
        ? (cf.pppoe_passwd.outerHTML =
            '<input type="text" name="pppoe_passwd" id="pppoe_passwd" maxlength="64" size="18" onFocus="this.select();" onKeyPress="return getkey(\'ssid\', event)" value="">')
        : ((cf.pppoe_passwd.outerHTML =
            '<input type="password" name="pppoe_passwd" id="pppoe_passwd" maxlength="64" size="18" style="width: 143px" onFocus="change_ipv6_pppoe_password(this);" onKeyPress="return getkey(\'ssid\', event)" value="">'),
          (cf.pppoe_passwd.value = ipv6_pppoe_pwd)));
}
function ipv6_write_pppoe_ip(ipv6_ip_addr) {
  if (
    ("" != ipv6_ip_addr && (ipv6_ip_addr = remove_space(ipv6_ip_addr)),
    "" == ipv6_ip_addr)
  )
    document.write("$ipv6_not_available");
  else {
    var i,
      each_ip = ipv6_ip_addr.split(" ");
    for (i = 0; i < each_ip.length; i++) show_ipv6_ip(each_ip[i]);
  }
}
