function refresh_log(form) {
  return (
    (form.action = "/apply.cgi?/FW_log.htm timestamp=" + ts),
    (form.submit_flag.value = "logs_refresh"),
    (form.anticsrf.value = logs_refresh_token),
    form.submit(),
    !0
  );
}
function check_logs_clear(form) {
  return (
    (form.action = "/func.cgi?/FW_log.htm timestamp=" + ts),
    (form.submit_flag.value = "logs_clear"),
    (form.anticsrf.value = logs_clear_token),
    form.submit(),
    !0
  );
}
function check_logs_send(form) {
  return "1" == email_get_notify
    ? ((form.action = "/apply.cgi?/FW_log.htm timestamp=" + ts),
      (form.submit_flag.value = "logs_send"),
      (form.anticsrf.value = logs_send_token),
      form.submit(),
      !0)
    : (alert("$change_to_email"), !1);
}
/**
 * @param {HTMLFormElement} form 
 */
function check_logs_download(form) {
  form.action = "/apply.cgi?/FW_log.htm timestamp=" + ts;
  form.submit_flag.value = "logs_download";
  form.anticsrf.value = logs_download_token;
  form.submit();
  return true;
}
function check_log_apply(form) {
  var cf = document.forms[0];
  return (
    (cf.action = "/apply.cgi?/FW_log.htm timestamp=" + ts),
    1 == cf.log_site.checked
      ? (cf.hidden_log_site.value = "1")
      : (cf.hidden_log_site.value = "0"),
    1 == cf.log_block_sites.checked
      ? (cf.hidden_log_block_sites.value = "1")
      : (cf.hidden_log_block_sites.value = "0"),
    1 == cf.log_block_services.checked
      ? (cf.hidden_log_block_services.value = "1")
      : (cf.hidden_log_block_services.value = "0"),
    1 == cf.log_conn.checked
      ? (cf.hidden_log_conn.value = "1")
      : (cf.hidden_log_conn.value = "0"),
    1 == cf.log_router.checked
      ? (cf.hidden_log_router.value = "1")
      : (cf.hidden_log_router.value = "0"),
    1 == cf.log_dosport.checked
      ? (cf.hidden_log_dosport.value = "1")
      : (cf.hidden_log_dosport.value = "0"),
    1 == cf.log_port.checked
      ? (cf.hidden_log_port.value = "1")
      : (cf.hidden_log_port.value = "0"),
    1 == cf.log_wire.checked
      ? (cf.hidden_log_wire.value = "1")
      : (cf.hidden_log_wire.value = "0"),
    1 == cf.log_conn_reset.checked
      ? (cf.hidden_log_conn_reset.value = "1")
      : (cf.hidden_log_conn_reset.value = "0"),
    1 == cf.log_wire_sched.checked
      ? (cf.hidden_log_wire_sched.value = "1")
      : (cf.hidden_log_wire_sched.value = "0"),
    1 == cf.log_readyshare.checked
      ? (cf.hidden_log_readyshare.value = "1")
      : (cf.hidden_log_readyshare.value = "0"),
    1 == cf.log_mobile_conn.checked
      ? (cf.hidden_log_mobile_conn.value = "1")
      : (cf.hidden_log_mobile_conn.value = "0"),
    1 == cf.log_vpn_head.checked
      ? (cf.hidden_log_vpn_head.value = "1")
      : (cf.hidden_log_vpn_head.value = "0"),
    1 == cf.log_plex.checked
      ? (cf.hidden_log_plex.value = "1")
      : (cf.hidden_log_plex.value = "0"),
    1 == cf.log_amazon.checked
      ? (cf.hidden_log_amazon.value = "1")
      : (cf.hidden_log_amazon.value = "0"),
    1 == cf.log_sfp.checked
      ? (cf.hidden_log_sfp.value = "1")
      : (cf.hidden_log_sfp.value = "0"),
    1 == cf.log_lacp.checked
      ? (cf.hidden_log_lacp.value = "1")
      : (cf.hidden_log_lacp.value = "0"),
    1 == cf.log_dumaos.checked
      ? (cf.hidden_log_dumaos.value = "1")
      : (cf.hidden_log_dumaos.value = "0"),
    1 == cf.log_insight.checked
      ? (cf.hidden_log_insight.value = "1")
      : (cf.hidden_log_insight.value = "0"),
    cf.submit(),
    !0
  );
}
