/**
 * @param frameWindow {Window}
 * @returns {Window}
*/
function getTop(frameWindow) {
  try {
    var parentWindow = frameWindow.parent;
    return void 0 !== frameWindow.netgear_version
      ? frameWindow
      : parentWindow === frameWindow
      ? frameWindow
      : parentWindow.origin !== frameWindow.origin
      ? frameWindow
      : getTop(parentWindow);
  } catch (e) {
    return top;
  }
}
function IsGameRouter() {
  return getTop(window).game_router_flag;
}

/**
 * @param {string} itemName 
 */
function hideHelpItem(itemName) {
  for (var item = $$("a[name='" + itemName + "']"); item.length === 1; item = item.next()) {
    item.hide();
    if (/hr/i.test(item.get(0).tagName)) {
      break;
    }
  }
}

/**
 * @param {string[]} items
 */
function hideHelpItems(items) {
  $$.each(items, function (_idx, itemName) {
    hideHelpItem(itemName);
  });
}