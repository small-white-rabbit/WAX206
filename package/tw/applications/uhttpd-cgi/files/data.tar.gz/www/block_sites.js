function show_subnet_trustedip() {
  var cf = document.forms[0],
    lan_subnet_array = new Array();
  (lan_subnet_array = lan_subnet.split(".")),
    cf.trustipenble.checked
      ? (255 != parseInt(lan_subnet_array[0]) &&
          (cf.cfTrusted_IPAddress1.disabled = !1),
        255 != parseInt(lan_subnet_array[1]) &&
          (cf.cfTrusted_IPAddress2.disabled = !1),
        255 != parseInt(lan_subnet_array[2]) &&
          (cf.cfTrusted_IPAddress3.disabled = !1),
        255 != parseInt(lan_subnet_array[3]) &&
          (cf.cfTrusted_IPAddress4.disabled = !1))
      : ((cf.cfTrusted_IPAddress1.disabled = !0),
        (cf.cfTrusted_IPAddress2.disabled = !0),
        (cf.cfTrusted_IPAddress3.disabled = !0),
        (cf.cfTrusted_IPAddress4.disabled = !0));
}
function show_trustedip() {
  var cf = document.forms[0];
  "0" == endis_Trusted_IP
    ? ((cf.trustipenble.checked = !1),
      (cf.cfTrusted_IPAddress1.value = lanip_array[0]),
      (cf.cfTrusted_IPAddress2.value = lanip_array[1]),
      (cf.cfTrusted_IPAddress3.value = lanip_array[2]),
      (cf.cfTrusted_IPAddress4.value = ""))
    : ((cf.trustipenble.checked = !0),
      (cf.cfTrusted_IPAddress1.value = trustedip_array[0]),
      (cf.cfTrusted_IPAddress2.value = trustedip_array[1]),
      (cf.cfTrusted_IPAddress3.value = trustedip_array[2]),
      (cf.cfTrusted_IPAddress4.value = trustedip_array[3])),
    show_subnet_trustedip();
}
function trim(mystr) {
  for (; 0 == mystr.indexOf(" ") && mystr.length > 1; )
    mystr = mystr.substring(1, mystr.length);
  for (; mystr.lastIndexOf(" ") == mystr.length - 1 && mystr.length > 1; )
    mystr = mystr.substring(0, mystr.length - 1);
  return " " == mystr && (mystr = ""), mystr;
}
function check_blocksites() {
  var cf = document.forms[0];
  if (((cf.cfTrusted_IPAddress.value = ""), 1 == cf.trustipenble.checked)) {
    if (
      ((cf.Trusted_IP_Enable.value = 1),
      (cf.cfTrusted_IPAddress.value =
        cf.cfTrusted_IPAddress1.value +
        "." +
        cf.cfTrusted_IPAddress2.value +
        "." +
        cf.cfTrusted_IPAddress3.value +
        "." +
        cf.cfTrusted_IPAddress4.value),
      0 == checkipaddr(cf.cfTrusted_IPAddress.value) ||
        0 ==
          is_sub_or_broad(cf.cfTrusted_IPAddress.value, lan_ip, lan_subnet) ||
        1 == isSameIp(cf.cfTrusted_IPAddress.value, lan_ip))
    )
      return alert("$invalid_ip"), !1;
    if (
      0 ==
      isSameSubNet(cf.cfTrusted_IPAddress.value, lan_subnet, lan_ip, lan_subnet)
    )
      return alert("$same_subnet_ip_trusted"), !1;
  } else cf.Trusted_IP_Enable.value = 0;
  if (((cf.Text.value = ""), cf.cfKeyWord_DomainList.length > 0)) {
    for (i = 0; i < cf.cfKeyWord_DomainList.length - 1; i++)
      if ("" != cf.cfKeyWord_DomainList.options[i].value) {
        var domainlist2 = trim(cf.cfKeyWord_DomainList.options[i].value),
          domainlist1 = encodeURI(domainlist2);
        cf.Text.value += domainlist1 + " ";
      }
    (domainlist2 = trim(cf.cfKeyWord_DomainList.options[i].value)),
      (domainlist1 = encodeURI(domainlist2));
    cf.Text.value += domainlist1;
  }
  for (i = 0; i < 3; i++)
    1 == document.forms[0].skeyword[i].checked && (cf.skeyword.value = i);
  return (
    1 == is_jp_version &&
      "mulpppoe1" == wan_type &&
      (1 == cf.session[0].checked
        ? (cf.session.value = "session1")
        : (cf.session.value = "session2")),
    cf.submit(),
    !0
  );
}
function checkKeyWord() {
  var cf = document.forms[0],
    tbox = cf.cfKeyWord_DomainList,
    tbox_length = cf.cfKeyWord_DomainList.length;
  if (255 == tbox_length)
    return alert("$keyword255"), (cf.cfKeyWord_Domain.value = ""), !1;
  if ("" == cf.cfKeyWord_Domain.value) return !1;
  for (i = 0; i < cf.cfKeyWord_Domain.value.length; i++)
    if (0 == isValidChar_space(cf.cfKeyWord_Domain.value.charCodeAt(i)))
      return alert("$error_keyword"), !1;
  var new_str = cf.cfKeyWord_Domain.value,
    check_str = new_str.toLowerCase();
  check_str.indexOf("://") > 0 &&
    check_str.length > 7 &&
    ("http://" == check_str.substring(0, 7)
      ? (new_str = new_str.substr(7))
      : "https://" == check_str.substring(0, 8) &&
        (new_str = new_str.substr(8)));
  for (var i = 0; i < tbox_length; i++)
    if (new_str == tbox.options[i].value)
      return (cf.cfKeyWord_Domain.value = ""), !1;
  if (1 == tbox_length && "" == tbox.options[0].value) var new_length = 0;
  else new_length = tbox_length;
  return (
    (tbox.options[new_length] = new Option(new_str, new_str)),
    (cf.cfKeyWord_Domain.value = ""),
    !0
  );
}
function checkKeyWordDomainList(act) {
  var cf = document.forms[0];
  if (
    ((cf.cfKeyWord_Domain.value = ""),
    null == cf.cfKeyWord_DomainList.options[0])
  )
    return !1;
  if ("delete" == act && -1 == cf.cfKeyWord_DomainList.selectedIndex)
    return alert("$select_serv_del"), !1;
  if (
    ("delete" == act &&
      -1 != cf.cfKeyWord_DomainList.selectedIndex &&
      (cf.cfKeyWord_DomainList.options[
        cf.cfKeyWord_DomainList.selectedIndex
      ] = null),
    "clear" == act)
  )
    for (
      var DomainList_length = cf.cfKeyWord_DomainList.length, i = 0;
      i < DomainList_length;
      i++
    )
      cf.cfKeyWord_DomainList.options[0] = null;
  return !0;
}
function checkTrustIP() {
  show_subnet_trustedip();
}
