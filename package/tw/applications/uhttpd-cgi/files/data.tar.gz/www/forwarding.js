var invalid_port_used = "$invalid_port_used",
  disable = !1,
  serv_array = [
    ["TCP", "20", "21", "20", "21", "FTP", "1"],
    ["TCP", "80", "80", "80", "80", "HTTP", "1"],
    //["TCP", "23566", "23566", "23566", "23566", "ICUII", "1"],
    ["TCP", "6670", "6670", "6670", "6670", "IP_Phone", "1"],
    //["TCP", "1720", "1720", "1720", "1720", "NetMeeting", "1"],
    ["TCP", "119", "119", "119", "119", "News", "1"],
    ["TCP", "1723", "1723", "1723", "1723", "PPTP", "1"],
    //["TCP/UDP", "27960", "27960", "27960", "27960", "QuakeII/III", "1"],
    //["TCP/UDP", "6970", "7170", "6970", "7170", "Real-Audio", "1"],
    ["TCP", "23", "23", "23", "23", "Telnet", "1"],
  ];
function show_servip() {
  var cf = document.forms[0],
    lanip_array = new Array();
  (lanip_array = lan_ip.split(".")),
    (cf.SV_IP1.value = lanip_array[0]),
    (cf.SV_IP2.value = lanip_array[1]),
    (cf.SV_IP3.value = lanip_array[2]);
}
function check_list_length(count) {
  if (64 == count) return alert("$forward_length_64"), !1;
}
function check_forwarding_edit(cf) {
  if (0 == forward_array_num) return (location.href = "edit_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (0 == count)
    1 == cf.RouteSelect.checked &&
      (count_select++, (select_num = parseInt(cf.RouteSelect.value)));
  else
    for (i = 0; i <= count; i++)
      1 == cf.RouteSelect[i].checked &&
        (count_select++, (select_num = parseInt(cf.RouteSelect[i].value)));
  return 0 == count_select
    ? ((location.href = "edit_fail.htm"), !1)
    : ((cf.select_edit.value = parseInt(forward_table[select_num])),
      (cf.select_edit_num.value = parseInt(item_count[select_num])),
      (cf.submit_flag.value = "forwarding_editnum_range"),
      (cf.anticsrf.value = forwarding_editnum_range_token),
      (cf.action = "/apply.cgi?/forwarding_edit_wait.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function check_forwarding_del(cf) {
  if (0 == forward_array_num) return (location.href = "del_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (0 == count)
    1 == cf.RouteSelect.checked &&
      (count_select++, (select_num = parseInt(cf.RouteSelect.value)));
  else
    for (i = 0; i <= count; i++)
      1 == cf.RouteSelect[i].checked &&
        (count_select++, (select_num = parseInt(cf.RouteSelect[i].value)));
  return 0 == count_select
    ? ((location.href = "del_fail.htm"), !1)
    : ((cf.select_del.value = parseInt(forward_table[select_num])),
      (cf.select_del_num.value = parseInt(item_count[select_num])),
      (cf.submit_flag.value = "forwarding_del_range"),
      (cf.anticsrf.value = forwarding_del_range_token),
      (document.getElementById("inbound_del").disabled = 1),
      (document.getElementById("inbound_edit").disabled = 1),
      (document.getElementById("inbound_add").disabled = 1),
      (document.getElementById("server_add").disabled = 1),
      cf.submit(),
      !0);
}
function Check_add(cf) {
  if (((cf.serflag.value = 0), 0 == check_list_length(count + 1))) return !1;
  if (
    ((cf.service_ip.value =
      cf.SV_IP1.value +
      "." +
      cf.SV_IP2.value +
      "." +
      cf.SV_IP3.value +
      "." +
      cf.SV_IP4.value),
    0 == checkipaddr(cf.service_ip.value) ||
      0 == is_sub_or_broad(cf.service_ip.value, lan_ip, lan_subnet))
  )
    return alert("$invalid_ip"), !1;
  if (
    ((cf.service_ip.value = address_parseInt(cf.service_ip.value)),
    0 == isSameSubNet(cf.service_ip.value, lan_subnet, lan_ip, lan_subnet))
  )
    return alert("$diff_lan_this_subnet"), !1;
  if (1 == isSameIp(cf.service_ip.value, lan_ip))
    return alert("$invalid_ip"), !1;
  var selectService = cf.svs_gm.options[cf.svs_gm.selectedIndex].value,
    s = cf.svs_gm.selectedIndex;
  for (i = 1; i <= forward_array_num; i++) {
    var str = eval("forwardingArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((each_info[0] = each_info[0].replace(/&harr;/g, " ")),
      each_info[0] == serv_array[s][5])
    )
      return alert("$forwarding_ser_name_dup"), !1;
  }
  var input_ip = cf.service_ip.value;
  (cf.hidden_protocol.value = serv_array[s][0]),
    (cf.hidden_external_portstart.value = serv_array[s][1]),
    (cf.hidden_external_portend.value = serv_array[s][2]),
    (cf.hidden_internal_portstart.value = serv_array[s][3]),
    (cf.hidden_internal_portend.value = serv_array[s][4]),
    (cf.hidden_service_name.value = serv_array[s][5]);
  var input_sername = serv_array[s][5],
    input_sertype = serv_array[s][0],
    input_external_start_port = serv_array[s][1],
    input_external_end_port = serv_array[s][2],
    input_internal_start_port = serv_array[s][3],
    input_internal_end_port = serv_array[s][4];
  for (i = 1; i <= forward_array_num; i++) {
    var str = eval("forwardingArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((sertype = each_info[1]),
      (ext_startport = each_info[2]),
      (ext_endport = each_info[3]),
      (int_startport = each_info[4]),
      (int_endport = each_info[5]),
      (forwardingip = each_info[6]),
      (serflag = each_info[7]),
      "UDP" == sertype && "1" == serflag)
    );
    else if (
      "TCP/UDP" == sertype ||
      sertype == input_sertype ||
      "TCP/UDP" == input_sertype
    ) {
      var ext_bigger_port =
          parseInt(ext_endport) > parseInt(ext_startport)
            ? parseInt(ext_endport)
            : parseInt(ext_startport),
        ext_smaller_port =
          parseInt(ext_endport) > parseInt(ext_startport)
            ? parseInt(ext_startport)
            : parseInt(ext_endport),
        int_bigger_port =
          parseInt(int_endport) > parseInt(int_startport)
            ? parseInt(int_endport)
            : parseInt(int_startport),
        int_smaller_port =
          parseInt(int_endport) > parseInt(int_startport)
            ? parseInt(int_startport)
            : parseInt(int_endport);
      if (
        !(
          ext_bigger_port < parseInt(input_external_start_port) ||
          parseInt(input_external_end_port) < ext_smaller_port
        )
      )
        return alert("$ports_error_conflict"), !1;
      if (
        forwardingip == input_ip &&
        !(
          int_bigger_port < parseInt(input_internal_start_port) ||
          parseInt(input_internal_end_port) < int_smaller_port
        )
      )
        return alert("$ports_error_conflict"), !1;
      if (
        !(
          ext_bigger_port < parseInt(input_external_start_port) ||
          parseInt(input_external_end_port) < ext_smaller_port
        )
      )
        return alert(invalid_port_used), !1;
    }
  }
  for (i = 1; i <= trigger_array_num; i++) {
    var str = eval("triggeringArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((constart_port = each_info[6]),
      (conend_port = each_info[7]),
      !(
        parseInt(conend_port) < parseInt(input_external_start_port) ||
        parseInt(input_external_end_port) < parseInt(constart_port)
      ) ||
        !(
          parseInt(conend_port) < parseInt(input_internal_start_port) ||
          parseInt(input_internal_end_port) < parseInt(constart_port)
        ))
    )
      return alert(invalid_port_used), !1;
  }
  for (i = 1; i <= upnp_array_num; i++) {
    var str = eval("upnpArray" + i),
      each_info = str.split(";");
    if (
      ((upnp_int = each_info[2]),
      (upnp_ext = each_info[3]),
      (upnp_ip = each_info[4]),
      //(parseInt(upnp_ext) >= parseInt(input_external_start_port) &&
       // parseInt(upnp_ext) <= parseInt(input_external_end_port) &&
        //input_ip != upnp_ip) ||
        (parseInt(upnp_int) >= parseInt(input_internal_start_port) &&
          parseInt(upnp_int) <= parseInt(input_internal_end_port) &&
          input_ip != upnp_ip))
    )
      return alert(invalid_port_used), !1;
  }
  return (1 != usb_router_flag ||
    (0 !=
      check_readyshare_port(
        input_external_start_port,
        input_external_end_port,
        "WAN"
      ) &&
      0 !=
        check_readyshare_port(
          input_internal_start_port,
          input_internal_end_port,
          "WAN"
        ))) &&
    (parseInt(remote_port) < parseInt(input_external_start_port) ||
      parseInt(input_external_end_port) < parseInt(remote_port) ||
      "" == remote_port) &&
    (parseInt(remote_port) < parseInt(input_internal_start_port) ||
      parseInt(input_internal_end_port) < parseInt(remote_port) ||
      "" == remote_port) &&
    ((input_sertype.toLowerCase() != vpn_tun_type &&
      "TCP/UDP" != input_sertype) ||
      "" == vpn_tun_port ||
      ((parseInt(vpn_tun_port) < parseInt(input_external_start_port) ||
        parseInt(input_external_end_port) < parseInt(vpn_tun_port)) &&
        (parseInt(vpn_tun_port) < parseInt(input_internal_start_port) ||
          parseInt(input_internal_end_port) < parseInt(vpn_tun_port)))) &&
    ((input_sertype.toLowerCase() != vpn_type && "TCP/UDP" != input_sertype) ||
      "" == vpn_port ||
      ((parseInt(vpn_port) < parseInt(input_external_start_port) ||
        parseInt(input_external_end_port) < parseInt(vpn_port)) &&
        (parseInt(vpn_port) < parseInt(input_internal_start_port) ||
          parseInt(input_internal_end_port) < parseInt(vpn_port))))
    ? ("NetMeeting" == cf.hidden_service_name.value
        ? (cf.serflag.value = 1)
        : (cf.serflag.value = 0),
      (cf.submit_flag.value = "forwarding_hidden_add"),
      (cf.anticsrf.value = forwarding_hidden_add_token),
      cf.submit(),
      !0)
    : (alert(invalid_port_used), !1);
}
function remove_space_commas(str) {
  var str1 = "";
  for (i = 0; i < str.length; i++)
    " " != str.charAt(i) && (str1 += str.charAt(i));
  var str_each = str1.split(","),
    str2 = "";
  for (i = 0; i < str_each.length; i++)
    "" != str_each[i] && (str2 = str2 + str_each[i] + ",");
  return (str2 = str2.substring(0, str2.length - 1));
}
function port_rerange(port) {
  var each_info = port.split(",");
  for (i = 0; i < each_info.length; i++) {
    var each_port = each_info[i].split("-");
    2 == each_port.length &&
      (parseInt(each_port[0], 10) == parseInt(each_port[1], 10) &&
        (each_info[i] = each_port[0]),
      parseInt(each_port[0], 10) > parseInt(each_port[1], 10) &&
        (each_info[i] = each_port[1] + "-" + each_port[0]));
  }
  for (i = 0; i < each_info.length - 1; i++) {
    var min_port = each_info[i],
      k = i;
    for (j = i + 1; j < each_info.length; j++) {
      var min_tmp = min_port.split("-"),
        cmp_port = each_info[j].split("-");
      1 == min_tmp.length &&
        (1 == cmp_port.length
          ? parseInt(min_tmp[0]) > parseInt(cmp_port[0])
            ? (parseInt(min_tmp[0]) - parseInt(cmp_port[0]) == 1 &&
                ((each_info[j] = cmp_port[0] + "-" + min_tmp[0]),
                (each_info[k] = "65535")),
              (min_port = each_info[j]),
              (k = j))
            : parseInt(min_tmp[0]) == parseInt(cmp_port[0])
            ? (each_info[j] = "65535")
            : parseInt(cmp_port[0]) - parseInt(min_tmp[0]) == 1 &&
              ((each_info[k] = min_tmp[0] + "-" + cmp_port[0]),
              (min_port = each_info[k]),
              (each_info[j] = "65535"))
          : 2 == cmp_port.length &&
            (parseInt(min_tmp[0]) > parseInt(cmp_port[1])
              ? (parseInt(min_tmp[0]) - parseInt(cmp_port[1]) == 1 &&
                  ((each_info[j] = cmp_port[0] + "-" + min_tmp[0]),
                  (each_info[k] = "65535")),
                (min_port = each_info[j]),
                (k = j))
              : parseInt(cmp_port[0]) - parseInt(min_tmp[0]) == 1
              ? ((each_info[k] = min_tmp[0] + "-" + cmp_port[1]),
                (min_port = each_info[k]),
                (each_info[j] = "65535"))
              : parseInt(min_tmp[0]) >= parseInt(cmp_port[0]) &&
                parseInt(min_tmp[0]) <= parseInt(cmp_port[1]) &&
                ((min_port = each_info[j]),
                (each_info[k] = "65535"),
                (k = j)))),
        2 == min_tmp.length &&
          (1 == cmp_port.length &&
            (parseInt(min_tmp[0]) > parseInt(cmp_port[0])
              ? (parseInt(min_tmp[0]) - parseInt(cmp_port[0]) == 1 &&
                  ((each_info[j] = cmp_port[0] + "-" + min_tmp[1]),
                  (each_info[k] = "65535")),
                (min_port = each_info[j]),
                (k = j))
              : parseInt(cmp_port[0]) - parseInt(min_tmp[1]) == 1
              ? ((each_info[k] = min_tmp[0] + "-" + cmp_port[0]),
                (min_port = each_info[k]),
                (each_info[j] = "65535"))
              : parseInt(min_tmp[0]) <= parseInt(cmp_port[0]) &&
                parseInt(min_tmp[1]) >= parseInt(cmp_port[0]) &&
                (each_info[j] = "65535")),
          2 == cmp_port.length &&
            (parseInt(min_tmp[0]) > parseInt(cmp_port[1])
              ? (parseInt(min_tmp[0]) - parseInt(cmp_port[1]) == 1 &&
                  ((each_info[j] = cmp_port[0] + "-" + min_tmp[1]),
                  (each_info[k] = "65535")),
                (min_port = each_info[j]),
                (k = j))
              : parseInt(cmp_port[0]) - parseInt(min_tmp[1]) == 1
              ? ((each_info[k] = min_tmp[0] + "-" + cmp_port[1]),
                (min_port = each_info[k]),
                (each_info[j] = "65535"))
              : parseInt(min_tmp[1]) >= parseInt(cmp_port[0]) &&
                parseInt(min_tmp[1]) <= parseInt(cmp_port[1])
              ? ((each_info[k] = min_tmp[0] + "-" + cmp_port[1]),
                (min_port = each_info[k]),
                (each_info[j] = "65535"))
              : parseInt(min_tmp[0]) >= parseInt(cmp_port[0]) &&
                parseInt(min_tmp[1]) <= parseInt(cmp_port[1]) &&
                ((min_port = each_info[j]),
                (each_info[k] = "65535"),
                (k = j))));
    }
    if (i != k) {
      var tmp = each_info[i];
      (each_info[i] = each_info[k]), (each_info[k] = tmp);
    }
  }
  var rerange_port = "";
  for (i = 0; i < each_info.length; i++)
    "65535" != each_info[i] &&
      (rerange_port = rerange_port + each_info[i] + ",");
  return rerange_port;
}
function forwarding_range_check(str) {
  if ("" == str) return !1;
  for (i = 0; i < str.length; i++)
    if (0 == isValidForwardPort(str.charCodeAt(i))) return !1;
  var each_info = str.split(",");
  for (i = 0; i < each_info.length; i++) {
    var each_port = each_info[i].split("-");
    if (1 == each_port.length) {
      if (parseInt(each_info[i], 10) < 1 || parseInt(each_info[i], 10) > 65534)
        return !1;
    } else {
      if (2 != each_port.length) return !1;
      if ("" == each_port[0] || "" == each_port[1]) return !1;
      if (parseInt(each_port[0], 10) < 1 || parseInt(each_port[0], 10) > 65534)
        return !1;
      if (parseInt(each_port[1], 10) < 1 || parseInt(each_port[1], 10) > 65534)
        return !1;
    }
  }
  return !0;
}
function check_forwarding_add_range(cf, flag) {
  if (((cf.serflag.value = 0), "" == cf.portname.value))
    return alert("$invalid_ser_name"), !1;
  for (i = 0; i < cf.portname.value.length; i++)
    if (0 == isValidChar_space(cf.portname.value.charCodeAt(i)))
      return alert("$invalid_ser_name"), !1;
  for (i = 1; i <= forward_array_num; i++) {
    var str = eval("forwardingArray" + i),
      each_info = str.split(" ");
    if (
      ((each_info[0] = each_info[0]
        .replace(/&harr;/g, " ")
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&")),
      "edit" == flag)
    ) {
      if (
        each_info[0] == cf.portname.value &&
        !(
          select_editnum <= i &&
          i < parseInt(select_editnum) + parseInt(edit_num)
        ) &&
        0 == each_info[7]
      )
        return alert("$forwarding_ser_name_dup"), !1;
    } else if (each_info[0] == cf.portname.value)
      return alert("$forwarding_ser_name_dup"), !1;
  }
  if (
    ((cf.service_ip.value =
      cf.server_ip1.value +
      "." +
      cf.server_ip2.value +
      "." +
      cf.server_ip3.value +
      "." +
      cf.server_ip4.value),
    0 == checkipaddr(cf.service_ip.value) ||
      0 == is_sub_or_broad(cf.service_ip.value, lan_ip, lan_subnet))
  )
    return alert("$invalid_ip"), !1;
  if (
    ((cf.service_ip.value = address_parseInt(cf.service_ip.value)),
    0 == isSameSubNet(cf.service_ip.value, lan_subnet, lan_ip, lan_subnet))
  )
    return alert("$diff_lan_this_subnet"), !1;
  if (1 == isSameIp(cf.service_ip.value, lan_ip))
    return alert("$invalid_ip"), !1;
  var str_exter_port = remove_space_commas(cf.exter_port.value);
  if (0 == forwarding_range_check(str_exter_port))
    return alert("$ports_error_external"), !1;
  var str_internal_port = "";
  if (1 == cf.same_range.checked)
    (cf.hidden_port_range.value = "1"), (str_internal_port = str_exter_port);
  else if (
    ((cf.hidden_port_range.value = "0"),
    (str_internal_port = remove_space_commas(cf.internal_port.value)),
    0 == forwarding_range_check(str_internal_port))
  )
    return alert("$ports_error_internal"), !1;
  var ext_start_port = "",
    ext_end_port = "",
    int_start_port = "",
    int_end_port = "",
    ext_each = str_exter_port.split(","),
    int_each = str_internal_port.split(",");
  if (ext_each.length != int_each.length)
    return alert("$ports_error_mismatch"), !1;
  for (i = 0; i < ext_each.length; i++) {
    var tmp_ext = ext_each[i].split("-"),
      tmp_int = int_each[i].split("-");
    if (tmp_ext.length != tmp_int.length)
      return alert("$ports_error_mismatch"), !1;
    if (1 == tmp_ext.length)
      (ext_start_port = ext_start_port + tmp_ext[0] + ","),
        (ext_end_port = ext_end_port + tmp_ext[0] + ","),
        (int_start_port = int_start_port + tmp_int[0] + ","),
        (int_end_port = int_end_port + tmp_int[0] + ",");
    else {
      if (
        parseInt(tmp_ext[1]) - parseInt(tmp_ext[0]) !=
        parseInt(tmp_int[1]) - parseInt(tmp_int[0])
      )
        return alert("$ports_error_mismatch"), !1;
      (ext_start_port = ext_start_port + tmp_ext[0] + ","),
        (ext_end_port = ext_end_port + tmp_ext[1] + ","),
        (int_start_port = int_start_port + tmp_int[0] + ","),
        (int_end_port = int_end_port + tmp_int[1] + ",");
    }
  }
  var input_sertype = cf.srvtype.value,
    input_ip = cf.service_ip.value,
    input_ext_start_port = ext_start_port.split(","),
    input_ext_end_port = ext_end_port.split(","),
    input_int_start_port = int_start_port.split(","),
    input_int_end_port = int_end_port.split(",");
  for (k = 0; k < input_ext_start_port.length - 1; k++) {
    for (i = 1; i <= forward_array_num; i++) {
      var str = eval("forwardingArray" + i)
          .replace(/&#92;/g, "\\")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&#40;/g, "(")
          .replace(/&#41;/g, ")")
          .replace(/&#34;/g, '"')
          .replace(/&#39;/g, "'")
          .replace(/&#35;/g, "#")
          .replace(/&#38;/g, "&"),
        each_info = str.split(" ");
      if (
        ((sertype = each_info[1]),
        (ext_startport = each_info[2]),
        (ext_endport = each_info[3]),
        (int_startport = each_info[4]),
        (int_endport = each_info[5]),
        (forwardingip = each_info[6]),
        (serflag = each_info[7]),
        "UDP" == sertype && "1" == serflag)
      );
      else if (
        "TCP/UDP" == sertype ||
        sertype == input_sertype ||
        "TCP/UDP" == input_sertype
      ) {
        var ext_bigger_port =
            parseInt(ext_endport) > parseInt(ext_startport)
              ? parseInt(ext_endport)
              : parseInt(ext_startport),
          ext_smaller_port =
            parseInt(ext_endport) > parseInt(ext_startport)
              ? parseInt(ext_startport)
              : parseInt(ext_endport),
          int_bigger_port =
            parseInt(int_endport) > parseInt(int_startport)
              ? parseInt(int_endport)
              : parseInt(int_startport),
          int_smaller_port =
            parseInt(int_endport) > parseInt(int_startport)
              ? parseInt(int_startport)
              : parseInt(int_endport),
          input_ext_bigger_port =
            parseInt(input_ext_end_port[k]) > parseInt(input_ext_start_port[k])
              ? parseInt(input_ext_end_port[k])
              : parseInt(input_ext_start_port[k]),
          input_ext_smaller_port =
            parseInt(input_ext_end_port[k]) > parseInt(input_ext_start_port[k])
              ? parseInt(input_ext_start_port[k])
              : parseInt(input_ext_end_port[k]),
          input_int_bigger_port =
            parseInt(input_int_end_port[k]) > parseInt(input_int_start_port[k])
              ? parseInt(input_int_end_port[k])
              : parseInt(input_int_start_port[k]),
          input_int_smaller_port =
            parseInt(input_int_end_port[k]) > parseInt(input_int_start_port[k])
              ? parseInt(input_int_start_port[k])
              : parseInt(input_int_end_port[k]);
        if ("edit" == flag) {
          if (
            !(
              (select_editnum <= i &&
                i < parseInt(select_editnum) + parseInt(edit_num)) ||
              ext_bigger_port < input_ext_smaller_port ||
              input_ext_bigger_port < ext_smaller_port
            )
          )
            return alert("$ports_error_conflict"), !1;
          if (
            !(
              (select_editnum <= i &&
                i < parseInt(select_editnum) + parseInt(edit_num)) ||
              forwardingip != input_ip ||
              int_bigger_port < input_int_smaller_port ||
              int_smaller_port > input_int_bigger_port
            )
          )
            return alert("$ports_error_conflict"), !1;
          if (
            !(
              select_editnum <= i &&
              i < parseInt(select_editnum) + parseInt(edit_num)
            ) &&
            ((input_ext_smaller_port >= ext_smaller_port &&
              input_ext_smaller_port <= ext_bigger_port) ||
              (input_ext_bigger_port >= ext_smaller_port &&
                input_ext_bigger_port <= ext_bigger_port))
          )
            return alert(invalid_port_used), !1;
        } else if ("add" == flag) {
          if (
            !(
              ext_bigger_port < input_ext_smaller_port ||
              input_ext_bigger_port < ext_smaller_port
            )
          )
            return alert("$ports_error_conflict"), !1;
          if (
            forwardingip == input_ip &&
            !(
              int_bigger_port < input_int_smaller_port ||
              int_smaller_port > input_int_bigger_port
            )
          )
            return alert("$ports_error_conflict"), !1;
          if (
            (input_ext_smaller_port >= ext_smaller_port &&
              input_ext_smaller_port <= ext_bigger_port) ||
            (input_ext_bigger_port >= ext_smaller_port &&
              input_ext_bigger_port <= ext_bigger_port)
          )
            return alert(invalid_port_used), !1;
        }
      }
    }
    for (i = 1; i <= trigger_array_num; i++) {
      var str = eval("triggeringArray" + i)
          .replace(/&#92;/g, "\\")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&#40;/g, "(")
          .replace(/&#41;/g, ")")
          .replace(/&#34;/g, '"')
          .replace(/&#39;/g, "'")
          .replace(/&#35;/g, "#")
          .replace(/&#38;/g, "&"),
        each_info = str.split(" ");
      if (
        ((triggeringip = each_info[2]),
        (consertype = each_info[5]),
        (constart_port = each_info[6]),
        (conend_port = each_info[7]),
        !(
          ((parseInt(conend_port) < parseInt(input_ext_start_port[k]) ||
            parseInt(input_ext_end_port[k]) < parseInt(constart_port)) &&
            (parseInt(conend_port) < parseInt(input_int_start_port[k]) ||
              parseInt(input_int_end_port[k]) < parseInt(constart_port))) ||
          ("TCP/UDP" != consertype &&
            "TCP/UDP" != input_sertype &&
            input_sertype != consertype) ||
          ("any" != triggeringip && input_ip == triggeringip)
        ))
      )
        return alert(invalid_port_used), !1;
    }
    for (i = 1; i <= upnp_array_num; i++) {
      var str = eval("upnpArray" + i),
        each_info = str.split(";");
      if (
        ((upnp_protocal = each_info[1]),
        (upnp_int = each_info[2]),
        (upnp_ext = each_info[3]),
        (upnp_ip = each_info[4]),
        (//(parseInt(upnp_ext) >= parseInt(input_ext_start_port) &&
          //parseInt(upnp_ext) <= parseInt(input_ext_end_port)) ||
           (parseInt(upnp_int) >= parseInt(input_int_start_port) &&
            parseInt(upnp_int) <= parseInt(input_int_end_port))) &&
          ("TCP/UDP" == upnp_protocal ||
            "TCP/UDP" == input_sertype ||
            input_sertype == upnp_protocal) &&
          input_ip != upnp_ip)
      )
        return alert(invalid_port_used), !1;
    }
    if (
      1 == usb_router_flag &&
      "UDP" != input_sertype &&
      (0 ==
        check_readyshare_port(
          input_ext_start_port[k],
          input_ext_end_port[k],
          "WAN"
        ) ||
        0 ==
          check_readyshare_port(
            input_int_start_port[k],
            input_int_end_port[k],
            "WAN"
          ))
    )
      return alert(invalid_port_used), !1;
    if (
      !(
        "1" != endis_remote ||
        "UDP" == cf.srvtype.value ||
        ((parseInt(remote_port) < parseInt(input_ext_start_port[k]) ||
          parseInt(input_ext_end_port[k]) < parseInt(remote_port) ||
          "" == remote_port) &&
          (parseInt(remote_port) < parseInt(input_int_start_port[k]) ||
            parseInt(input_int_end_port[k]) < parseInt(remote_port) ||
            "" == remote_port))
      )
    )
      return alert(invalid_port_used), !1;
    if (
      (parseInt(input_ext_start_port[k]) <= 123 &&
        parseInt(input_ext_end_port[k]) >= 123 &&
        "1" == endis_ntp &&
        "TCP" != cf.srvtype.value) ||
      (parseInt(input_int_start_port[k]) <= 123 &&
        parseInt(input_int_end_port[k]) >= 123 &&
        "1" == endis_ntp &&
        "TCP" != cf.srvtype.value)
    )
      return alert(invalid_port_used), !1;
    if (
      (parseInt(input_ext_start_port[k]) <= 1900 &&
        parseInt(input_ext_end_port[k]) >= 1900 &&
        "1" == endis_upnp &&
        "TCP" != cf.srvtype.value) ||
      (parseInt(input_int_start_port[k]) <= 1900 &&
        parseInt(input_int_end_port[k]) >= 1900 &&
        "1" == endis_upnp &&
        "TCP" != cf.srvtype.value)
    )
      return alert(invalid_port_used), !1;
    if (
      (parseInt(input_ext_start_port[k]) <= 5050 &&
        parseInt(input_ext_end_port[k]) >= 5050 &&
        "bigpond" == info_get_wanproto &&
        "TCP" != cf.srvtype.value) ||
      (parseInt(input_int_start_port[k]) <= 5050 &&
        parseInt(input_int_end_port[k]) >= 5050 &&
        "bigpond" == info_get_wanproto &&
        "TCP" != cf.srvtype.value)
    )
      return alert(invalid_port_used), !1;
    if (
      !(
        ((cf.srvtype.value.toLowerCase() != vpn_tun_type &&
          "TCP/UDP" != cf.srvtype.value) ||
          "" == vpn_tun_port ||
          ((parseInt(vpn_tun_port) < parseInt(input_ext_start_port[k]) ||
            parseInt(input_ext_end_port[k]) < parseInt(vpn_tun_port)) &&
            (parseInt(vpn_tun_port) < parseInt(input_int_start_port[k]) ||
              parseInt(input_int_end_port[k]) < parseInt(vpn_tun_port)))) &&
        ((cf.srvtype.value.toLowerCase() != vpn_type &&
          "TCP/UDP" != cf.srvtype.value) ||
          "" == vpn_port ||
          ((parseInt(vpn_port) < parseInt(input_ext_start_port[k]) ||
            parseInt(input_ext_end_port[k]) < parseInt(vpn_port)) &&
            (parseInt(vpn_port) < parseInt(input_int_start_port[k]) ||
              parseInt(input_int_end_port[k]) < parseInt(vpn_port))))
      )
    )
      return alert(invalid_port_used), !1;
    ("TCP" != cf.srvtype.value && "TCP/UDP" != cf.srvtype.value) ||
      (parseInt(input_ext_end_port[k]) >= "1720" &&
        parseInt(input_ext_start_port[k]) <= "1720" &&
        (cf.serflag.value = 1));
  }
  return (
    (cf.port_start.value = ext_start_port),
    (cf.port_end.value = ext_end_port),
    (cf.hidden_port_int_start.value = int_start_port),
    (cf.hidden_port_int_end.value = int_end_port),
    (cf.hidden_portname.value = cf.portname.value
      .replace(/&/g, "&#38;")
      .replace(/ /g, "&harr;")),
    (document.getElementById("apply").disabled = 1),
    cf.submit(),
    !0
  );
}
function int_port_value() {
  var cf = document.forms[0];
  1 == cf.same_range.checked && (cf.internal_port.value = cf.exter_port.value);
}
function click_arrange_by_ip() {
  for (
    var tbody = document.getElementById("pf_record").tBodies[0],
      tr = tbody.rows,
      trValue = new Array(),
      i = 0;
    i < tr.length;
    i++
  )
    trValue[i] = tr[i];
  trValue.sort(compareCols(5, "int"));
  var fragment = document.createDocumentFragment();
  for (i = 0; i < trValue.length; i++)
    (trValue[i].className = i % 2 == 1 ? "even_line" : "odd_line"),
      (trValue[i].cells[1].innerHTML = i + 1),
      (trValue[i].cells[1].className = "subhead"),
      fragment.appendChild(trValue[i]);
  tbody.appendChild(fragment);
}
