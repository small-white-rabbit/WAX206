function show_hidden_help_top_button(help_flag) {
  if (!isIE_or_Opera() || IE_version() >= 8) Not_IE_show_hidden_help(help_flag);
  else {
    var frame_height = getTop(window)
      .document.getElementById("formframe_div")
      .style.height.replace(/px/, "");
    help_flag % 2 == 0
      ? ((document.getElementById("main").style.height = frame_height - 285),
        (document.getElementById("help").style.display = ""),
        (document.getElementById("help_switch").className = "open_help"))
      : ((document.getElementById("help").style.display = "none"),
        (document.getElementById("help_switch").className = "close_help"),
        (document.getElementById("main").style.height = frame_height - 165));
  }
}
function goto_basic_login_page() {
  !(
    (1 == jp_multiPPPoE && "Japanese" != gui_region) ||
    (select_type > 0 && "Japanese" == gui_region)
  ) ||
  ("" != netgear_region &&
    "WW" != netgear_region.toUpperCase() &&
    "JP" != netgear_region.toUpperCase())
    ? 0 == select_type
      ? goto_formframe("BAS_pppoe.htm")
      : 1 == select_type
      ? goto_formframe("BAS_pptp.htm")
      : 4 == select_type && 1 == have_l2tp
      ? goto_formframe("BAS_l2tp.htm")
      : goto_formframe("BAS_pppoe.htm")
    : goto_formframe("BAS_mulpppoe.htm");
}
function setIP(cf) {
  var dflag = cf.WANAssign[0].checked;
  setDisabled(
    dflag,
    cf.WPethr1,
    cf.WPethr2,
    cf.WPethr3,
    cf.WPethr4,
    cf.WMask1,
    cf.WMask2,
    cf.WMask3,
    cf.WMask4,
    cf.WGateway1,
    cf.WGateway2,
    cf.WGateway3,
    cf.WGateway4
  ),
    cf.WANAssign[1].checked
      ? ((cf.DNSAssign[1].checked = !0),
        setDNS(cf),
        null != document.getElementsByTagName("span")[0] &&
          ((cf.DNSAssign[0].disabled = !0),
          (document.getElementsByTagName("span")[0].style.color = "gray")),
        1 == have_dhcp_option &&
          ((document.getElementById("option_title").className = "gray_td"),
          (document.getElementById("option60").className = "gray_td"),
          (document.getElementById("option61").className = "gray_td"),
          setDisabled(!0, cf.option_60, cf.option_61)))
      : (null != document.getElementsByTagName("span")[0] &&
        ((document.getElementsByTagName("span")[0].style.color = "black"),
        (cf.DNSAssign[0].disabled = !1)),
        1 == have_dhcp_option &&
          ((document.getElementById("option_title").className = ""),
          (document.getElementById("option60").className = ""),
          (document.getElementById("option61").className = ""),
          setDisabled(!1, cf.option_60, cf.option_61))),
    (DisableFixedIP = dflag);
}
function setDNS(cf) {
  var dflag = cf.DNSAssign[0].checked;
  cf.WANAssign[1].checked && ((cf.DNSAssign[1].checked = !0), (dflag = !1)),
    setDisabled(
      dflag,
      cf.DAddr1,
      cf.DAddr2,
      cf.DAddr3,
      cf.DAddr4,
      cf.PDAddr1,
      cf.PDAddr2,
      cf.PDAddr3,
      cf.PDAddr4
    ),
    1 == dns_third_flag &&
      setDisabled(dflag, cf.TDAddr1, cf.TDAddr2, cf.TDAddr3, cf.TDAddr4),
    (DisableFixedDNS = dflag);
}
function check_wizard_dhcp(check, page) {
  if (((cf = document.forms[0]), 0 == consolidate_device_name)) {
    if ("" == cf.system_name.value)
      return alert("$info_mark_name" + " $trigger_null"), !1;
    for (i = 0; i < cf.system_name.value.length; i++)
      if (0 == isValidChar_space(cf.system_name.value.charCodeAt(i)))
        return alert("$acname_not_allowed"), !1;
  }
  var pattern = /(?=^.{1,255}$)(^[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?)*$)/;
  return "" == cf.domain_name.value ||
    (null != cf.domain_name.value.match(pattern) &&
      cf.domain_name.value.match(pattern)[0] == cf.domain_name.value)
    ? (1 == check
        ? ((cf.run_test.value = "test"),
          "wiz" == page &&
            (cf.action = "/apply.cgi?/WIZ_update.htm timestamp=" + ts))
        : (cf.run_test.value = "no"),
      !0)
    : (alert("$doname_not_allowed"), !1);
}
function check_static_ip_mask_gtw() {
  return (
    (cf = document.forms[0]),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    0 == checksubnet(cf.ether_subnet.value, 1)
      ? (alert("$invalid_mask"), !1)
      : 0 == checkipaddr(cf.ether_ipaddr.value) ||
        0 ==
          is_sub_or_broad(
            cf.ether_ipaddr.value,
            cf.ether_ipaddr.value,
            cf.ether_subnet.value
          )
      ? (alert("$invalid_ip"), !1)
      : 0 == checkgateway(cf.ether_gateway.value) ||
        0 ==
          is_sub_or_broad(
            cf.ether_gateway.value,
            cf.ether_gateway.value,
            cf.ether_subnet.value
          )
      ? (alert("$invalid_gateway"), !1)
      : 1 != isSameIp(cf.ether_ipaddr.value, cf.ether_gateway.value) ||
        (alert("$invalid_gateway"), !1)
  );
}
function check_RU_static_ip_mask_gtw() {
  return (
    (cf = document.forms[0]),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    0 == checksubnet(cf.ether_subnet.value, 1)
      ? (alert(bh_invalid_mask), !1)
      : 0 == checkipaddr(cf.ether_ipaddr.value) ||
        0 ==
          is_sub_or_broad(
            cf.ether_ipaddr.value,
            cf.ether_ipaddr.value,
            cf.ether_subnet.value
          )
      ? (alert(bh_invalid_ip), !1)
      : 0 == checkgateway(cf.ether_gateway.value) ||
        0 ==
          is_sub_or_broad(
            cf.ether_gateway.value,
            cf.ether_gateway.value,
            cf.ether_subnet.value
          )
      ? (alert(bh_invalid_mask), !1)
      : 1 != isSameIp(cf.ether_ipaddr.value, cf.ether_gateway.value) ||
        (alert(bh_invalid_gateway), !1)
  );
}
function check_three_DNS(wan_assign) {
  var cf = document.forms[0];
  if (
    ((cf.ether_dnsaddr1.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.ether_dnsaddr2.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    (cf.ether_dnsaddr3.value =
      cf.TDAddr1.value +
      "." +
      cf.TDAddr2.value +
      "." +
      cf.TDAddr3.value +
      "." +
      cf.TDAddr4.value),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    "..." == cf.ether_dnsaddr1.value && (cf.ether_dnsaddr1.value = ""),
    "..." == cf.ether_dnsaddr2.value && (cf.ether_dnsaddr2.value = ""),
    "..." == cf.ether_dnsaddr3.value && (cf.ether_dnsaddr3.value = ""),
    "" != cf.ether_dnsaddr1.value)
  ) {
    if (0 == checkipaddr(cf.ether_dnsaddr1.value))
      return alert("$invalid_primary_dns"), !1;
    if (
      ((cf.ether_dnsaddr1.value = address_parseInt(cf.ether_dnsaddr1.value)),
      1 == wan_assign &&
        isSameIp(cf.ether_dnsaddr1.value, cf.ether_ipaddr.value))
    )
      return alert("$invalid_primary_dns"), !1;
  }
  if ("" != cf.ether_dnsaddr2.value) {
    if (0 == checkipaddr(cf.ether_dnsaddr2.value))
      return alert("$invalid_second_dns"), !1;
    if (
      ((cf.ether_dnsaddr2.value = address_parseInt(cf.ether_dnsaddr2.value)),
      1 == wan_assign &&
        isSameIp(cf.ether_dnsaddr2.value, cf.ether_ipaddr.value))
    )
      return alert("$invalid_second_dns"), !1;
  }
  if ("" != cf.ether_dnsaddr3.value) {
    if (0 == checkipaddr(cf.ether_dnsaddr3.value))
      return alert("$invalid_third_dns"), !1;
    if (
      ((cf.ether_dnsaddr3.value = address_parseInt(cf.ether_dnsaddr3.value)),
      1 == wan_assign &&
        isSameIp(cf.ether_dnsaddr3.value, cf.ether_ipaddr.value))
    )
      return alert("$invalid_third_dns"), !1;
  }
  return (
    "" != cf.ether_dnsaddr1.value ||
    "" != cf.ether_dnsaddr2.value ||
    "" != cf.ether_dnsaddr3.value ||
    (alert("$dns_must_specified"), !1)
  );
}
function check_static_dns(wan_assign) {
  var cf = document.forms[0];
  return (
    (cf.ether_dnsaddr1.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.ether_dnsaddr2.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    "..." == cf.ether_dnsaddr1.value
      ? (cf.ether_dnsaddr1.value = "")
      : (cf.ether_dnsaddr1.value = address_parseInt(cf.ether_dnsaddr1.value)),
    "..." == cf.ether_dnsaddr2.value
      ? (cf.ether_dnsaddr2.value = "")
      : (cf.ether_dnsaddr2.value = address_parseInt(cf.ether_dnsaddr2.value)),
    !!check_DNS(
      cf.ether_dnsaddr1.value,
      cf.ether_dnsaddr2.value,
      wan_assign,
      cf.ether_ipaddr.value
    )
  );
}
function check_RU_static_dns(wan_assign) {
  var cf = document.forms[0];
  return (
    (cf.ether_dnsaddr1.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.ether_dnsaddr2.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    "..." == cf.ether_dnsaddr1.value
      ? (cf.ether_dnsaddr1.value = "")
      : (cf.ether_dnsaddr1.value = address_parseInt(cf.ether_dnsaddr1.value)),
    "..." == cf.ether_dnsaddr2.value
      ? (cf.ether_dnsaddr2.value = "")
      : (cf.ether_dnsaddr2.value = address_parseInt(cf.ether_dnsaddr2.value)),
    !!check_RU_DNS(
      cf.ether_dnsaddr1.value,
      cf.ether_dnsaddr2.value,
      wan_assign,
      cf.ether_ipaddr.value
    )
  );
}
function check_ether_samesubnet() {
  var cf = document.forms[0];
  return (
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    1 ==
    isSameSubNet(
      cf.ether_ipaddr.value,
      cf.ether_subnet.value,
      lan_ip,
      lan_subnet
    )
      ? (alert("$same_lan_wan_subnet"), !1)
      : 1 == isSameSubNet(cf.ether_ipaddr.value, lan_subnet, lan_ip, lan_subnet)
      ? (alert("$same_lan_wan_subnet"), !1)
      : 1 ==
        isSameSubNet(
          cf.ether_ipaddr.value,
          cf.ether_subnet.value,
          lan_ip,
          cf.ether_subnet.value
        )
      ? (alert("$same_lan_wan_subnet"), !1)
      : 1 != isSameIp(cf.ether_ipaddr.value, lan_ip) ||
        (alert("$same_lan_wan_subnet"), !1)
  );
}
function check_wizard_static(check, page) {
  var cf = document.forms[0];
  return (
    0 != check_static_ip_mask_gtw() &&
    0 != check_static_dns(!0) &&
    (check_ether_samesubnet(),
    1 == check
      ? ((cf.run_test.value = "test"),
        "wiz" == page &&
          (cf.action = "/apply.cgi?/WIZ_update.htm timestamp=" + ts))
      : (cf.run_test.value = "no"),
    !0)
  );
}
function check_ether(cf, check) {
  if (
    (format_IP(
      "WPethr1",
      "WPethr2",
      "WPethr3",
      "WPethr4",
      "WMask1",
      "WMask2",
      "WMask3",
      "WMask4",
      "WGateway1",
      "WGateway2",
      "WGateway3",
      "WGateway4",
      "DAddr1",
      "DAddr2",
      "DAddr3",
      "DAddr4",
      "PDAddr1",
      "PDAddr2",
      "PDAddr3",
      "PDAddr4",
      "TDAddr1",
      "TDAddr2",
      "TDAddr3",
      "TDAddr4"
    ),
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    cf.DNSAssign[1].checked)
  )
    if (1 == dns_third_flag) {
      if (0 == check_three_DNS(cf.WANAssign[1].checked)) return !1;
    } else if (0 == check_static_dns(cf.WANAssign[1].checked)) return !1;
  if (0 == check_wizard_dhcp(check, "bas")) return !1;
  if (cf.MACAssign[2].checked) {
    if (
      ((the_mac = cf.Spoofmac.value),
      -1 == the_mac.indexOf(":") && "12" == the_mac.length)
    ) {
      var tmp_mac =
        the_mac.substr(0, 2) +
        ":" +
        the_mac.substr(2, 2) +
        ":" +
        the_mac.substr(4, 2) +
        ":" +
        the_mac.substr(6, 2) +
        ":" +
        the_mac.substr(8, 2) +
        ":" +
        the_mac.substr(10, 2);
      cf.Spoofmac.value = tmp_mac;
    } else if (6 == the_mac.split("-").length) {
      tmp_mac = the_mac.replace(/-/g, ":");
      cf.Spoofmac.value = tmp_mac;
    }
    if (0 == maccheck_multicast(cf.Spoofmac.value)) return !1;
  }
  if (1 == cf.WANAssign[1].checked) {
    if (0 == check_static_ip_mask_gtw()) return !1;
    1 ==
      isSameSubNet(
        cf.ether_ipaddr.value,
        cf.ether_subnet.value,
        lan_ip,
        lan_subnet
      ) && (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(cf.ether_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
        (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(
          cf.ether_ipaddr.value,
          cf.ether_subnet.value,
          lan_ip,
          cf.ether_subnet.value
        ) && (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.ether_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1);
  }
  if (
    ((cf.hid_mtu_value.value = wan_mtu_now),
    "dhcp" != old_wan_type
      ? ((cf.change_wan_type.value = 0), mtu_change(wanproto_type))
      : "1" == old_wan_assign
      ? old_wan_ip != cf.ether_ipaddr.value && cf.WANAssign[1].checked
        ? (cf.change_wan_type.value = 0)
        : cf.WANAssign[0].checked
        ? (cf.change_wan_type.value = 0)
        : (cf.change_wan_type.value = 1)
      : "0" == old_wan_assign &&
        (old_wan_ip != cf.ether_ipaddr.value && cf.WANAssign[1].checked
          ? (cf.change_wan_type.value = 0)
          : (cf.change_wan_type.value = 1)),
    (cf.hid_enable_vpn.value = vpn_enable),
    "0" == old_endis_ddns &&
      "1" == vpn_enable &&
      1 == cf.WANAssign[0].checked &&
      "1" == old_wan_assign)
  ) {
    if (1 != confirm("$no_change_static_ip"))
      return (cf.hid_enable_vpn.value = "1"), !1;
    cf.hid_enable_vpn.value = "0";
  }
  if (
    (cf.ether_ipaddr.value != old_wan_ip &&
    "1" == vpn_enable &&
    1 == cf.WANAssign[1].checked &&
    "1" != old_endis_ddns
      ? (cf.hid_vpn_detect_flag.value = "1")
      : (cf.hid_vpn_detect_flag.value = "0"),
    (cf.ether_ipaddr.value = address_parseInt(cf.ether_ipaddr.value)),
    (cf.ether_subnet.value = address_parseInt(cf.ether_subnet.value)),
    (cf.ether_gateway.value = address_parseInt(cf.ether_gateway.value)),
    (parent.ether_post_flag = 1),
    1 === getTop(window).use_orbi_style_flag &&
      1 == cf.wan_preference[4].checked)
  )
    if ("0" != qos_endis_on && "0" != aggre_option) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS and Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if ("0" != qos_endis_on) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if (
      "0" != aggre_option &&
      4 != wan_agg_port &&
      0 ==
        confirm(
          "Enabling WAN aggregation disables Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
    )
      return !1;
  if (
    ("1" == cf.sfp_module.value
      ? (cf.hid_sfp_module.value = 1)
      : (cf.hid_sfp_module.value = 0),
    1 === getTop(window).support_ds_lite_flag && is_jp_version)
  ) {
    if (1 == cf.enable_ds_lite.checked) {
      if (
        (("disabled" != ipv6_type &&
          "6to4" != ipv6_type &&
          "bridge" != ipv6_type) ||
          alert(
            'IPv6 connection type will be set to "Auto Config" automatically'
          ),
        (cf.hid_enable_ds.value = 1),
        (cf.ether_dnsaddr1.value = ""),
        (cf.ether_dnsaddr2.value = ""),
        1 == dns_third_flag && (cf.ether_dnsaddr3.value = ""),
        "1" == cf.hid_aftr_ipv6.value)
      ) {
        if ("" == cf.aftr_ipv6_addr.value)
          return alert("Empty Manual Config AFTR IPv6 Address!"), !1;
        var tmp = cf.aftr_ipv6_addr.value;
        "http://" == tmp.slice(0, 7)
          ? (tmp = tmp.slice(7))
          : "https://" == tmp.slice(0, 8) && (tmp = tmp.slice(8));
        var i = tmp.indexOf("/");
        (i = -1 == i ? tmp.length : i),
          (tmp = tmp.slice(0, i)),
          (ipv6_array = tmp.split(":"));
        var isIpv6IP = /^[0-9A-Fa-f:]+$$/g.test(tmp),
          is_fqdn_addr = /^(www\.)?[-a-zA-Z0-9]+(\.[-a-zA-Z0-9]+)+$$/g.test(
            tmp
          );
        if (isIpv6IP) {
          if (ipv6_array.length < 4 || ipv6_array.length > 8)
            return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
        } else if (!is_fqdn_addr)
          return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
      }
    } else cf.hid_enable_ds.value = 0;
    1 == cf.enable_nd_proxy.checked
      ? (cf.hid_enable_nd.value = 1)
      : (cf.hid_enable_nd.value = 0);
  }
  return cf.submit(), !0;
}
function check_welcome_dhcp() {
  var cf = document.forms[0];
  return (
    0 == consolidate_device_name &&
      (parent.account_name = cf.system_name.value),
    (parent.domain_name = cf.domain_name.value),
    (parent.welcome_wan_type = 2),
    !0
  );
}
function check_welcome_static() {
  var cf = document.forms[0];
  return (
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    (cf.ether_dnsaddr1.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.ether_dnsaddr2.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    "..." == cf.ether_dnsaddr2.value && (cf.ether_dnsaddr2.value = ""),
    0 != check_wizard_static(0, "welcome") &&
      ((parent.welcome_wan_type = 1),
      (parent.static_ip = cf.ether_ipaddr.value),
      (parent.static_subnet = cf.ether_subnet.value),
      (parent.static_gateway = cf.ether_gateway.value),
      (parent.static_dns1 = cf.ether_dnsaddr1.value),
      (parent.static_dns2 = cf.ether_dnsaddr2.value),
      !0)
  );
}
function RU_welcome_static() {
  var cf = document.forms[0];
  return (
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    (cf.ether_dnsaddr1.value =
      cf.DAddr1.value +
      "." +
      cf.DAddr2.value +
      "." +
      cf.DAddr3.value +
      "." +
      cf.DAddr4.value),
    (cf.ether_dnsaddr2.value =
      cf.PDAddr1.value +
      "." +
      cf.PDAddr2.value +
      "." +
      cf.PDAddr3.value +
      "." +
      cf.PDAddr4.value),
    0 != check_RU_static_ip_mask_gtw() &&
      ("..." == cf.ether_dnsaddr2.value && (cf.ether_dnsaddr2.value = ""),
      0 != check_wizard_static(0, "welcome") &&
        ((parent.welcome_wan_type = 1),
        (parent.static_ip = cf.ether_ipaddr.value),
        (parent.static_subnet = cf.ether_subnet.value),
        (parent.static_gateway = cf.ether_gateway.value),
        (parent.static_dns1 = cf.ether_dnsaddr1.value),
        (parent.static_dns2 = cf.ether_dnsaddr2.value),
        (parent.conflict_wanlan = cf.conflict_wanlan.value),
        void ("9" == parent.isp_type || "13" == parent.isp_type
          ? (alert(attention_static_ip), (location.href = "RU_isp_spoof.htm"))
          : "3" == parent.isp_type
          ? (location.href = "RU_isp_spoof.htm")
          : "4" == parent.isp_type
          ? ((cf.ether_ipaddr.value = cf.ether_ipaddr.value),
            (cf.ether_subnet.value = cf.ether_subnet.value),
            (cf.ether_gateway.value = cf.ether_gateway.value),
            (cf.ether_dnsaddr1.value = cf.ether_dnsaddr1.value),
            (cf.ether_dnsaddr2.value = cf.ether_dnsaddr2.value),
            (cf.DNSAssign.value = "1"),
            (cf.WANAssign.value = "static"),
            (cf.welcome_wan_type.value = 1),
            cf.submit())
          : "6" == parent.isp_type
          ? (alert(attention_static_ip),
            (cf.pppoe_dual_ipaddr.value = cf.ether_ipaddr.value),
            (cf.pppoe_dual_subnet.value = cf.ether_subnet.value),
            (cf.pppoe_dual_gateway.value = ""),
            (cf.welcome_wan_type.value = "3"),
            cf.submit())
          : "14" == parent.isp_type
          ? (alert(attention_static_ip),
            (cf.l2tp_myip.value = cf.ether_ipaddr.value),
            (cf.l2tp_mynetmask.value = cf.ether_subnet.value),
            (cf.l2tp_gateway.value = cf.ether_gateway.value),
            (cf.l2tp_dnsaddr1.value = cf.ether_dnsaddr1.value),
            (cf.l2tp_dnsaddr2.value = cf.ether_dnsaddr2.value),
            (cf.DNSAssign.value = "1"),
            (cf.WANAssign.value = "1"),
            (cf.STATIC_DNS.value = parent.STATIC_DNS),
            (cf.welcome_wan_type.value = "5"),
            cf.submit())
          : "10" == parent.isp_type &&
            (alert(attention_static_ip),
            (cf.pptp_myip.value = cf.ether_ipaddr.value),
            (cf.pptp_mynetmask.value = cf.ether_subnet.value),
            (cf.pptp_gateway.value = cf.ether_gateway.value),
            (cf.pptp_dnsaddr1.value = cf.ether_dnsaddr1.value),
            (cf.pptp_dnsaddr2.value = cf.ether_dnsaddr2.value),
            (cf.DNSAssign.value = "1"),
            (cf.WANAssign.value = "1"),
            (cf.STATIC_DNS.value = parent.STATIC_DNS),
            (cf.welcome_wan_type.value = "4"),
            cf.submit()))))
  );
}
function check_RU_dhcp_static() {
  var cf = document.forms[0];
  if (
    ((cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    (cf.ether_gateway.value =
      cf.WGateway1.value +
      "." +
      cf.WGateway2.value +
      "." +
      cf.WGateway3.value +
      "." +
      cf.WGateway4.value),
    1 == cf.WANAssign[1].checked)
  ) {
    if (0 == check_RU_static_ip_mask_gtw()) return !1;
    1 ==
      isSameSubNet(
        cf.ether_ipaddr.value,
        cf.ether_subnet.value,
        lan_ip,
        lan_subnet
      ) && (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(cf.ether_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
        (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(
          cf.ether_ipaddr.value,
          cf.ether_subnet.value,
          lan_ip,
          cf.ether_subnet.value
        ) && (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.ether_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1),
      (parent.welcome_wan_type = 1);
  } else
    (cf.ether_ipaddr.value = ""),
      (cf.ether_subnet.value = ""),
      (cf.ether_gateway.value = ""),
      (cf.conflict_wanlan.value = 0),
      (parent.welcome_wan_type = 2);
  if (cf.DNSAssign[1].checked) {
    if (0 == check_RU_static_dns(cf.WANAssign[1].checked)) return !1;
  } else (cf.ether_dnsaddr1.value = ""), (cf.ether_dnsaddr2.value = "");
  (parent.static_ip = cf.ether_ipaddr.value),
    (parent.static_subnet = cf.ether_subnet.value),
    (parent.static_gateway = cf.ether_gateway.value),
    (parent.static_dns1 = cf.ether_dnsaddr1.value),
    (parent.static_dns2 = cf.ether_dnsaddr2.value),
    (parent.conflict_wanlan = cf.conflict_wanlan.value),
    (location.href = "RU_manual_spoof.htm");
}
function RU_welcome_pppoe_static() {
  var cf = document.forms[0];
  return (
    (cf.ether_ipaddr.value =
      cf.WPethr1.value +
      "." +
      cf.WPethr2.value +
      "." +
      cf.WPethr3.value +
      "." +
      cf.WPethr4.value),
    (cf.ether_subnet.value =
      cf.WMask1.value +
      "." +
      cf.WMask2.value +
      "." +
      cf.WMask3.value +
      "." +
      cf.WMask4.value),
    0 == checkipaddr(cf.ether_ipaddr.value) ||
    0 ==
      is_sub_or_broad(
        cf.ether_ipaddr.value,
        cf.ether_ipaddr.value,
        cf.ether_subnet.value
      )
      ? (alert(bh_invalid_ip), !1)
      : 0 == checksubnet(cf.ether_subnet.value)
      ? (alert(bh_invalid_mask), !1)
      : (1 ==
          isSameSubNet(
            cf.ether_ipaddr.value,
            cf.ether_subnet.value,
            lan_ip,
            lan_subnet
          ) && (cf.conflict_wanlan.value = 1),
        1 ==
          isSameSubNet(cf.ether_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
          (cf.conflict_wanlan.value = 1),
        1 ==
          isSameSubNet(
            cf.ether_ipaddr.value,
            cf.ether_subnet.value,
            lan_ip,
            cf.ether_subnet.value
          ) && (cf.conflict_wanlan.value = 1),
        1 == isSameIp(cf.ether_ipaddr.value, lan_ip) &&
          (cf.conflict_wanlan.value = 1),
        (cf.run_test.value = "no"),
        (parent.pppoe_eth_ip = cf.ether_ipaddr.value),
        (parent.pppoe_eth_netmask = cf.ether_subnet.value),
        (parent.static_ip = cf.ether_ipaddr.value),
        (parent.static_subnet = cf.ether_subnet.value),
        (parent.conflict_wanlan = cf.conflict_wanlan.value),
        void ("6" == parent.isp_type
          ? (alert(attention_static_ip),
            (cf.pppoe_dual_ipaddr.value = cf.ether_ipaddr.value),
            (cf.pppoe_dual_subnet.value = cf.ether_subnet.value),
            (cf.pppoe_dual_gateway.value = ""),
            (cf.pppoe_dnsaddr1.value = parent.static_dns1),
            (cf.pppoe_dnsaddr2.value = parent.static_dns2),
            (cf.pppoe_servername.value = parent.pppoe_server),
            "" != cf.pppoe_dnsaddr1.value || "" != cf.pppoe_dnsaddr2.value
              ? (cf.DNSAssign.value = "1")
              : (cf.DNSAssign.value = "0"),
            (cf.welcome_wan_type.value = "3"),
            cf.submit())
          : "5" == parent.isp_type
          ? (alert(attention_static_ip), (location.href = "RU_isp_spoof.htm"))
          : "88" == parent.isp_type &&
            (alert(attention_static_ip),
            (cf.pppoe_dual_ipaddr.value = cf.ether_ipaddr.value),
            (cf.pppoe_dual_subnet.value = cf.ether_subnet.value),
            (cf.pppoe_dual_gateway.value = ""),
            (cf.pppoe_dnsaddr1.value = ""),
            (cf.pppoe_dnsaddr2.value = ""),
            (cf.welcome_wan_type.value = "3"),
            cf.submit())))
  );
}
