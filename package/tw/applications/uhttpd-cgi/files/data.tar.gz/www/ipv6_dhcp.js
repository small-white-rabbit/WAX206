function check_ipv6_dhcp(cf) {
  for (i = 0; i < cf.ipv6_system.value.length; i++)
    if (0 == isValidChar(cf.ipv6_system.value.charCodeAt(i)))
      return alert("$acname_not_allowed"), !1;
  var pattern = /(?=^.{1,255}$)(^[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?)*$)/;
  return "" == cf.domainName.value ||
    (null != cf.domainName.value.match(pattern) &&
      cf.domainName.value.match(pattern)[0] == cf.domainName.value)
    ? (1 != getTop(window).ipv6_dns_manual || 0 != checkIPv6DNS(cf)) &&
        0 != ipv6_save_common(cf) &&
        (!have_mapt || 1 != cf.cb_enable.checked || 0 != check_mapt(cf))
    : (alert("$doname_not_allowed"), !1);
}
function check_ipv6_plus(cf) {
  return (
    0 != confirm("$nh_warning_str1") &&
    (1 == cf.enable_nd_proxy.checked
      ? (cf.hid_enable_nd.value = 1)
      : (cf.hid_enable_nd.value = 0),
    !0)
  );
}
function check_ipv6_dslite(cf) {
  if (0 == confirm("$nh_warning_str1")) return !1;
  if ("1" == cf.hid_aftr_ipv6.value) {
    if ("" == cf.aftr_ipv6_addr.value)
      return alert("Empty Manual Config AFTR IPv6 Address!"), !1;
    var tmp = cf.aftr_ipv6_addr.value;
    "http://" == tmp.slice(0, 7)
      ? (tmp = tmp.slice(7))
      : "https://" == tmp.slice(0, 8) && (tmp = tmp.slice(8));
    var i = tmp.indexOf("/");
    (i = -1 == i ? tmp.length : i),
      (tmp = tmp.slice(0, i)),
      (ipv6_array = tmp.split(":"));
    var isIpv6IP = /^[0-9A-Fa-f:]+$$/g.test(tmp),
      is_fqdn_addr = /^(www\.)?[-a-zA-Z0-9]+(\.[-a-zA-Z0-9]+)+$$/g.test(tmp);
    if (isIpv6IP) {
      if (ipv6_array.length < 4 || ipv6_array.length > 8)
        return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
    } else if (!is_fqdn_addr)
      return alert("Invalid Manual Config AFTR IPv6 Address!"), !1;
  }
  return (
    1 == cf.enable_nd_proxy.checked
      ? (cf.hid_enable_nd.value = 1)
      : (cf.hid_enable_nd.value = 0),
    !0
  );
}
