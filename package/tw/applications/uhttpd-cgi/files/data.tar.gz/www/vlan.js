function check_vlan_input(cf, flag) {
  var tmp_vlan_name = cf.vlan_name.value;
  if (
    (1 == parent.support_orange_flag &&
      ((cf.vlan_name.disabled = !1),
      (cf.vlan_id.disabled = !1),
      (cf.vlan_priority.disabled = !1),
      "Orange France IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "OrangeIPTV")),
    1 == parent.support_singapore_isp_flag &&
      "SingTel Singapore IPTV" == cf.vlan_name.value &&
      (cf.vlan_name.value = "SingTelSingaporeIPTV"),
    (1 != parent.support_malaysia_isp_flag &&
      1 != parent.support_malaysia_pppoe_isp_flag) ||
      ("Unifi Malaysia IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "UnifiMalaysiaIPTV"),
      "Maxis Malaysia IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "MaxisMalaysiaIPTV")),
    1 == parent.support_spain_isp_flag &&
      ("Vodafone Spain IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "VodaSpainIPTV"),
      "Orange Spain IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "OrangeSpainIPTV"),
      "MoviStar Spain IPTV" == cf.vlan_name.value &&
        (cf.vlan_name.value = "MoviStarSpainIPTV")),
    "edit" != flag || 1 != default_internet)
  ) {
    if (cf.vlan_name.value.length > 24 || 0 == cf.vlan_name.value.length)
      return alert("$vlan_error11"), !1;
    for (i = 0; i < cf.vlan_name.value.length; i++)
      if (0 == isValidChar(cf.vlan_name.value.charCodeAt(i)))
        return alert("$vlan_error11"), !1;
    for (i = 1 == is_for_RU ? 0 : 1; i <= array_num; i++) {
      var str = eval("vlanArray" + i),
        str_info = str.split(" ");
      if (str_info[1] == cf.vlan_name.value && ("edit" != flag || sel_num != i))
        return (
          1 == parent.support_orange_flag && "OrangeIPTV" == cf.vlan_name.value
            ? (alert(
                "$vlan_error4_1 " + "Orange France IPTV" + " $vlan_error4_2"
              ),
              (cf.vlan_name.value = "Orange France IPTV"))
            : (1 != parent.support_spain_isp_flag ||
                ("VodaSpainIPTV" != cf.vlan_name.value &&
                  "OrangeSpainIPTV" != cf.vlan_name.value &&
                  "MoviStarSpainIPTV" != cf.vlan_name.value)) &&
              ((1 != parent.support_malaysia_isp_flag &&
                1 != parent.support_malaysia_pppoe_isp_flag) ||
                ("UnifiMalaysiaIPTV" != cf.vlan_name.value &&
                  "MaxisMalaysiaIPTV" != cf.vlan_name.value))
            ? 1 == parent.support_singapore_isp_flag &&
              "SingTelSingaporeIPTV" == cf.vlan_name.value
              ? (alert("$vlan_error4_1 " + tmp_vlan_name + " $vlan_error4_2"),
                (cf.vlan_name.value = tmp_vlan_name))
              : alert(
                  "$vlan_error4_1 " + cf.vlan_name.value + " $vlan_error4_2"
                )
            : (alert("$vlan_error4_1 " + tmp_vlan_name + " $vlan_error4_2"),
              (cf.vlan_name.value = tmp_vlan_name)),
          change_type(cf),
          !1
        );
    }
    if (!_isNumeric(cf.vlan_id.value)) return alert("$vlan_error3"), !1;
    var str_tmp = parseInt(cf.vlan_id.value, 10);
    if (str_tmp < 1 || str_tmp > 4094) return alert("$vlan_error3"), !1;
  }
  if (0 == cf.vlan_id.value.length) return alert("$vlan_error1"), !1;
  if (
    ("" == cf.vlan_priority.value && (cf.vlan_priority.value = "0"),
    !_isNumeric(cf.vlan_priority.value))
  )
    return alert("$vlan_error2"), !1;
  if (((str_tmp = parseInt(cf.vlan_priority.value, 10)), str_tmp > 7))
    return alert("$vlan_error2"), !1;
  var str_inter = eval("vlanArray1"),
    str_inter_info = str_inter.split(" "),
    inter_wireless = parseInt(str_inter_info[5], 10).toString(2).split(""),
    inter_wired = parseInt(str_inter_info[4], 10).toString(2).split("");
  if ("edit" != flag || 1 != default_internet) {
    var wired = 0,
      wireless = 0;
    "1" == ad_router_flag
      ? (wireless_limit = parseInt("10011", 2))
      : "1" == tri_router_flag
      ? (wireless_limit = parseInt("100011", 2))
      : "1" == three_ssid_flag
      ? (wireless_limit = parseInt("111000000",2))
      : (wireless_limit = parseInt("00011", 2));
    for (var count = 0; count < wired_ports_num; count++)
      ("1" == parent.wan_agg_flag &&
        "1" === wan_preference &&
        count == wan_agg_port - 1) ||
        ("1" == getTop(window).have_eth5g_flag &&
        "2" == wan_preference &&
        count == wired_ports_num-1) ||
        (eval("cf.iptv_ports_" + count + ".checked==true") &&
          (wired += Math.pow(2, count)));
    if (
      (1 == cf.iptv_ports_10.checked && (wireless += 1),
      1 == cf.iptv_ports_12.checked && (wireless += 4),
      1 == cf.iptv_ports_11.checked && (wireless += 2),
      1 == cf.iptv_ports_13.checked && (wireless += 8),
      1 == cf.iptv_ports_14.checked &&
        "1" == ad_router_flag &&
        (wireless += 16),
      1 == cf.iptv_ports_15.checked &&
        "1" == tri_router_flag &&
        (wireless += 32),
      1 == cf.iptv_ports_16.checked && "1" == three_ssid_flag && (wireless += 64),
      1 == cf.iptv_ports_17.checked && "1" == three_ssid_flag && (wireless += 128),
      1 == cf.iptv_ports_18.checked && "1" == three_ssid_flag && (wireless += 256),
      wired == Math.pow(2, wired_ports_num) - 1 && wireless == wireless_limit)
    )
      return alert("$vlan_error6"), !1;
    if (
      0 == wired &&
      0 == wireless &&
      (1 != parent.support_orange_flag || "orange" != cf.vlan_type.value)
    )
      return alert("$vlan_error5"), change_type(cf), !1;
    (cf.hid_wired_port.value = wired), (cf.hid_wireless_port.value = wireless);
  }
  for (var i = 1; i <= array_num; i++) {
    var str = eval("vlanArray" + i),
      str_info = str.split(" ");
    if (
      str_info[2] == cf.vlan_id.value &&
      parseInt(str_info[5], 10) > 0 &&
      cf.hid_wireless_port.value > 0 &&
      ("edit" != flag || sel_num != i)
    )
      return alert("$vlan_id:" + cf.vlan_id.value + " $vlan_error15"), !1;
    if (
      str_info[2] == cf.vlan_id.value &&
      str_info[3] == cf.vlan_priority.value &&
      cf.hid_wired_port.value > 0 &&
      ("edit" != flag || sel_num != i)
    )
      return (
        alert(
          "$vlan_id:" +
            cf.vlan_id.value +
            " / $qos_priority:" +
            cf.vlan_priority.value +
            " $vlan_error14"
        ),
        !1
      );
  }
  if ("edit" == flag)
    if (1 == default_internet) {
      if (
        ((cf.hid_vlan_name.value = each_info[1]), !_isNumeric(cf.vlan_id.value))
      )
        return alert("$vlan_error3"), !1;
      var str_tmp = parseInt(cf.vlan_id.value, 10);
      if (str_tmp < 0 || str_tmp > 4094) return alert("$vlan_error13"), !1;
      if (
        (0 == str_tmp && (cf.vlan_priority.value = "0"),
        (1 == parent.support_orange_flag ||
          1 == parent.support_spain_isp_flag ||
          1 == parent.support_malaysia_isp_flag ||
          1 == parent.support_singapore_isp_flag ||
          1 == parent.support_malaysia_pppoe_isp_flag) &&
          ("orange_dhcp" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "1")
            : "orange_pppoe" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "2")
            : "orange_spain_dhcp" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "3")
            : "movistar_spain_pppoe" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "4")
            : "vodafone_spain_pppoe" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "5")
            : "singtel_singa_dhcp" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "6")
            : "unifi_malaysia_dhcp" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "7")
            : "maxis_malaysia_dhcp" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "8")
            : "unifi_malaysia_pppoe" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "9")
            : "maxis_malaysia_pppoe" == cf.vlan_type.value
            ? (cf.hid_vlan_orange.value = "10")
            : (cf.hid_vlan_orange.value = "11"),
          "orange_dhcp" == cf.vlan_type.value ||
            "orange_pppoe" == cf.vlan_type.value ||
            "movistar_spain_pppoe" == cf.vlan_type.value ||
            "vodafone_spain_pppoe" == cf.vlan_type.value ||
            "unifi_malaysia_pppoe" == cf.vlan_type.value ||
            "maxis_malaysia_pppoe" == cf.vlan_type.value))
      ) {
        if ("" == cf.orange_username.value)
          return alert("$login_name_null"), change_type(cf), !1;
        for (i = 0; i < cf.orange_username.value.length; i++)
          if (0 == isValidChar(cf.orange_username.value.charCodeAt(i)))
            return alert("$loginname_not_allowed"), change_type(cf), !1;
      }
      (cf.hid_wired_port.value = each_info[4]),
        (cf.hid_wireless_port.value = each_info[5]);
    } else cf.hid_vlan_name.value = cf.vlan_name.value;
  return (
    ("edit" == flag && 1 == default_internet) || change_internet_port(flag, cf),
    (cf.vlan_id.value = parseInt(cf.vlan_id.value, 10)),
    !0
  );
}
function change_internet_port(type, cf) {
  for (
    var wiredOrResult = 0, wirelessOrResult = 0, i = 2;
    i <= array_num;
    i++
  ) {
    var str = eval("vlanArray" + i),
      str_info = str.split(" ");
    if (
      "add" == type ||
      ("edit" == type && i != sel_num) ||
      ("delete" == type && i != cf.select_del_num.value)
    ) {
      var wireless = parseInt(str_info[5]),
        wired = parseInt(str_info[4]);
      (wiredOrResult |= wired), (wirelessOrResult |= wireless);
    }
  }
  "delete" != type &&
    ((wiredOrResult |= cf.hid_wired_port.value),
    (wirelessOrResult |= cf.hid_wireless_port.value));
  var interWired = wiredOrResult ^ (Math.pow(2, wired_ports_num) - 1),
    interWireless = 511 ^ wirelessOrResult,
    inter_info = vlanArray1.split(" ");
  cf.hid_internet_group.value =
    inter_info[0] +
    " " +
    inter_info[1] +
    " " +
    inter_info[2] +
    " " +
    inter_info[3] +
    " " +
    interWired +
    " " +
    interWireless;
  var intra_info = vlanArray0.split(" ");
  cf.hid_intranet_group.value =
    intra_info[0] +
    " " +
    intra_info[1] +
    " " +
    intra_info[2] +
    " " +
    intra_info[3] +
    " " +
    interWired +
    " " +
    interWireless;
}
function click_add_btn(cf) {
  return array_num >= 10 || (1 == is_for_RU && array_num >= 9)
    ? (alert("$vlan_error9"), !1)
    : ((location.href = "VLAN_add.htm"), !0);
}
function check_iptv_input(cf) {
  var wired = 0,
    wireless = 0,
    wired_ports = new Array(),
    wlan_ports = new Array();
  for (i = 0; i < wired_ports_num; i++)
    "1" != parent.wan_agg_flag ||
    "1" !== wan_preference ||
    i != wan_agg_port - 1
      ? 1 == eval("cf." + "iptv_ports_" + i).checked
        ? ((wired_ports[wired_ports_len - i] = "1"),
          (eval("cf." + "hid_bri_lan" + (i + 1)).value = "1"))
        : ((wired_ports[wired_ports_len - i] = "0"),
          (eval("cf." + "hid_bri_lan" + (i + 1)).value = "0"))
      : (wired_ports[wired_ports_len - i] = "0");
  for (i = 10; i < 19; i++)
    1 == eval("cf." + "iptv_ports_" + i).checked
      ? ((wlan_ports[18 - i] = "1"),
        10 == i || 11 == i
          ? (eval("cf." + "hid_brig_ssid" + (i - 9)).value = "1")
          : 15 == i
          ? (eval("cf." + "hid_brig_ssid3").value = "1")
          : 12 == i || 13 == i
          ? (eval("cf." + "hid_brig_guest_ssid" + (i - 11)).value = "1")
          : 14 == i 
          ? (eval("cf." + "hid_brig_ssid_ad").value = "1")
          :16 != i && 17 != i && 18 !=i || (eval("cf." + "hid_brig_wireless"+(i-15)+"_ssid").value = "1"))
      : ((wlan_ports[18 - i] = "0"),
        10 == i || 11 == i
          ? (eval("cf." + "hid_brig_ssid" + (i - 9)).value = "0")
          : 15 == i
          ? (eval("cf." + "hid_brig_ssid3").value = "0")
          : 12 == i || 13 == i
          ? (eval("cf." + "hid_brig_guest_ssid" + (i - 11)).value = "0")
          : 14 == i 
          ? (eval("cf." + "hid_brig_ssid_ad").value = "0")
          : 16!=i && 17 != i && 18 != i || (eval("cf."+"hid_brig_wireless"+(i-15)+"_ssid").value = "0"));
  return (
    "1" == ad_router_flag
      ? (wireless_limit = parseInt("10011", 2))
      : "1" == tri_router_flag
      ? (wireless_limit = parseInt("100011", 2))
      : "1" == three_ssid_flag
      ? wireless_limit = parseInt("111000000",2)
      : (wireless_limit = parseInt("00011", 2)),
    (wired = parseInt(wired_ports.join(""), 2)),
    (wireless = parseInt(wlan_ports.join(""), 2)),
    wired == Math.pow(2, wired_ports_num) - 1 && wireless == wireless_limit
      ? (alert("$vlan_error6"), !1)
      : 0 == wired && 0 == wireless
      ? (alert("$vlan_error5"), !1)
      : ((cf.hid_iptv_mask.value = wired),
        (cf.hid_iptv_mask2.value = wireless),
        !0)
  );
}
function click_edit_btn(cf) {
  var select_num,
    count_select = 0;
  if (1 == array_num && 1 != is_for_RU)
    1 == cf.ruleSelect.checked &&
      (count_select++, (select_num = parseInt(cf.ruleSelect.value)));
  else
    for (i = 0; 1 == is_for_RU ? i <= array_num : i < array_num; i++)
      1 == cf.ruleSelect[i].checked &&
        (count_select++, (select_num = parseInt(cf.ruleSelect[i].value)));
  return 0 == count_select
    ? (alert("$port_edit"), !1)
    : ((cf.select_edit_num.value = select_num),
      (cf.submit_flag.value = "vlan_edit"),
      (cf.anticsrf.value = vlan_edit_token),
      (cf.action = "/apply.cgi?/VLAN_edit.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function click_delete_btn(cf) {
  var count_select = 0,
    select_num;
  if (1 == array_num && 1 != is_for_RU)
    1 == cf.ruleSelect.checked &&
      (count_select++, (select_num = parseInt(cf.ruleSelect.value)));
  else
    for (i = 0; 1 == is_for_RU ? i <= array_num : i < array_num; i++)
      1 == cf.ruleSelect[i].checked &&
        (count_select++, (select_num = parseInt(cf.ruleSelect[i].value)));
  if (0 == count_select) return alert("$port_del"), !1;
  var sel_str = eval("vlanArray" + select_num),
    sel_info = sel_str.split(" ");
  return (
    (sel_info[1] = sel_info[1]
      .replace(/&#92;/g, "\\")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&#40;/g, "(")
      .replace(/&#41;/g, ")")
      .replace(/&#34;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&#35;/g, "#")
      .replace(/&#38;/g, "&")),
    0 != confirm("$vlan_warn1" + " " + sel_info[1] + "?") &&
      ("Internet" == sel_info[1] ||
      ("Intranet" == sel_info[1] && 1 == is_for_RU)
        ? (alert(sel_info[1] + " $vlan_port_del_msg"), !1)
        : ((cf.select_del_num.value = select_num),
          (cf.submit_flag.value = "vlan_delete"),
          (cf.anticsrf.value = vlan_delete_token),
          change_internet_port("delete", cf),
          cf.submit(),
          !0))
  );
}
function click_apply(cf) {
  if (1 == cf.vlan_iptv_enable.checked) {
    if (1 == cf.vlan_iptv_select[1].checked) {
      var count_enable = 0,
        sel_list = "",
        port1 = (port2 = port3 = port4 = port5 = port6 = port10 = port11 = port12 = port13 = port14 = port15 = port16 = port17 = port18 = 0);
      for (i = 1; i <= array_num; i++) {
        var boxName = "vlan_check" + i;
        if (1 == document.getElementById(boxName).checked) {
          var sel_str = eval("vlanArray" + i),
            sel_info = sel_str.split(" "),
            wired_port = parseInt(sel_info[4], 10).toString(2),
            wlan_port = parseInt(sel_info[5], 10).toString(2),
            zero = "";
          for (u = 0; u < 6 - wired_port.length; u++) zero += "0";
          var tmp_lan = (zero + wired_port).split(""),
            zero = "";
          for (u = 0; u < 9 - wlan_port.length; u++) zero += "0";
          var tmp_wlan = (zero + wlan_port).split("");
          for (j = 0; j < 10; j++)
            "1" == tmp_lan[j] && eval("port" + (j + 1) + "++"),
              j < 8 && "1" == tmp_wlan[j] && eval("port" + (18 - j) + "++");
          (sel_list += i), (sel_list += "#"), count_enable++;
        }
      }
      if (
        array_num > 1 &&
        0 == orange_note &&
        "0" == cf.hid_inter_lan1.value &&
        "0" == cf.hid_inter_lan2.value &&
        "0" == cf.hid_inter_lan3.value &&
        "0" == cf.hid_inter_lan4.value &&
        "0" == cf.hid_inter_lan5.value &&
        "0" == cf.hid_inter_lan6.value &&
        "0" == cf.hid_inter_wireless1.value &&
        "0" == cf.hid_inter_wireless2.value &&
        "0" == cf.hid_inter_wireless5.value
      )
        return alert("$vlan_error16"), !1;
      if (
        port1 > 1 ||
        port2 > 1 ||
        port3 > 1 ||
        port4 > 1 ||
        port5 > 1 ||
        port6 > 1 ||
        port10 > 1 ||
        port11 > 1 ||
        port14 > 1 ||
        port15 > 1 ||
        port16 > 1 ||
        port17 > 1 ||
        port18 > 1
      )
        return alert("$vlan_port_dup"), !1;
      if (count_enable > 6) return alert("$vlan_error10"), !1;
      (cf.hid_enable_vlan.value = "1"),
        (cf.hid_vlan_type.value = "1"),
        (cf.hid_sel_list.value = sel_list),
        (cf.hid_enabled_num.value = count_enable),
        (cf.submit_flag.value = "apply_vlan"),
        (cf.anticsrf.value = apply_vlan_token);
    } else {
      if (0 == check_iptv_input(cf)) return !1;
      (cf.hid_enable_vlan.value = "1"),
        (cf.hid_vlan_type.value = "0"),
        (cf.submit_flag.value = "apply_iptv_edit"),
        (cf.anticsrf.value = apply_iptv_edit_token);
    }
    if (
      1 == vlan_free_flag &&
      (clearNoNum(document.getElementById("vlan_id_input")),
      document.getElementById("enable_vlan_id").checked)
    ) {
      var vlan_id_num = parseInt(
        document.getElementById("vlan_id_input").value
      );
      if (isNaN(vlan_id_num) || vlan_id_num < 1 || vlan_id_num > 4094)
        return (
          alert(
            "Invalid vlan id, it should be digital and under range of 1~4094"
          ),
          !1
        );
      cf.hid_vlan_id_input.value = "1";
    }
  } else
    (cf.hid_enable_vlan.value = "0"),
      (cf.submit_flag.value = "disable_vlan_iptv"),
      (cf.anticsrf.value = disable_vlan_iptv_token);
  return !0;
}
function clearNoNum(ele) {
  return (ele.value = ele.value.replace(/[^\d]/g, ""));
}
function uncheckWlanOption(ele) {
  ele.checked &&
    ((1 != document.getElementById("iptv_ports_10").checked &&
      1 != document.getElementById("iptv_ports_11").checked &&
      1 != document.getElementById("iptv_ports_14").checked &&
      1 != document.getElementById("iptv_ports_15").checked &&
      1 != document.getElementById("iptv_ports_16").checked &&
      1 != document.getElementById("iptv_ports_17").checked &&
      1 != document.getElementById("iptv_ports_18").checked) ||
      alert("WiFi interface does not support packets with VLAN ID"),
    (document.getElementById("iptv_ports_10").checked = !1),
    (document.getElementById("iptv_ports_11").checked = !1),
    (document.getElementById("iptv_ports_14").checked = !1),
    (document.getElementById("iptv_ports_15").checked = !1),
    (document.getElementById("iptv_ports_16").checked = !1),
    (document.getElementById("iptv_ports_17").checked = !1),
    (document.getElementById("iptv_ports_18").checked = !1));
}
function uncheckVlanIDOption(ele) {
  1 == vlan_free_flag &&
    ele.checked &&
    (1 == document.getElementById("enable_vlan_id").checked &&
      alert("WiFi interface does not support packets with VLAN ID"),
    (document.getElementById("enable_vlan_id").checked = !1));
}
function change_lan_agg_show(tag) {
  document.forms[0];
  if (
    ((document.getElementById("lan_port2").style.display = "none"),
    (document.getElementById("lan_port_label1").innerHTML =
      "Port1+Port2(Aggregated)"),
    "vlan_tag" == tag)
  ) {
    for (
      var list = document.getElementsByClassName("vlan_tag_port2"), i = 0;
      i < list.length;
      i++
    )
      list[i].style.display = "none";
    for (
      var labels = document.getElementsByClassName("vlan_tag_label1"), j = 0;
      j < labels.length;
      j++
    )
      labels[j].innerHTML = "Port1+Port2(Aggregated)";
  }
}
function syncAgg(pre) {
  var cf = document.forms[0];
  1 == pre.checked
    ? (cf.iptv_ports_1.checked = !0)
    : (cf.iptv_ports_1.checked = !1);
}
