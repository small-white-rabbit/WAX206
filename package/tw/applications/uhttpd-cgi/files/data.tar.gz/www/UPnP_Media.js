function check_media(form) {
  form.media_server.checked
    ? (form.media_server_onoff.value = "1")
    : (form.media_server_onoff.value = "0"),
    1 == form.media_server_tivo.checked
      ? (form.media_server_tivo_flag.value = "yes")
      : (form.media_server_tivo_flag.value = "no"),
    1 == form.enable_itunes.checked
      ? (form.itunes_onoff.value = "1")
      : (form.itunes_onoff.value = "0"),
    check_name(),
    form.submit();
}
function check_media_scan(form) {
  form.submit_flag.value = "upnp_media_scan";
  form.anticsrf.value = upnp_media_scan_token;
  form.submit();
}
