function convert(value, dataType) {
  switch (dataType) {
    case "int":
      var each_info = value.split(".");
      return (
        (value =
          parseInt(each_info[0]) +
          parseInt(each_info[1]) +
          parseInt(each_info[2]) +
          parseInt(each_info[3])),
        parseInt(value)
      );
    default:
      return value.toString();
  }
}
function compareCols(col, dataType) {
  return function (tr1, tr2) {
    return (
      (value1 = convert(tr1.cells[col].innerHTML, dataType)),
      (value2 = convert(tr2.cells[col].innerHTML, dataType)),
      value1 < value2 ? -1 : value1 > value2 ? 1 : 0
    );
  };
}
function sortTable(tableId, col, dataType, tag) {
  if (1 == enable_block_device || 1 == tag) {
    for (
      var tbody = document.getElementById(tableId).tBodies[0],
        tr = tbody.rows,
        trValue = new Array(),
        i = 0;
      i < tr.length;
      i++
    )
      trValue[i] = tr[i];
    tbody.sortCol == col
      ? trValue.reverse()
      : trValue.sort(compareCols(col, dataType));
    var fragment = document.createDocumentFragment();
    for (i = 0; i < trValue.length; i++)
      (trValue[i].className = i % 2 == 1 ? "even_line" : "odd_line"),
        fragment.appendChild(trValue[i]);
    tbody.appendChild(fragment), (tbody.sortCol = col);
  }
}
function load_sortTable(tableId, num, col, dataType, tag) {
  var j = 0,
    k = 0,
    m = 0;
  if (1 == enable_block_device || 1 == tag) {
    for (
      var tbody = document.getElementById(tableId).tBodies[0],
        tr = tbody.rows,
        trValue1 = new Array(),
        trValue2 = new Array(),
        i = 0;
      i < tr.length;
      i++
    )
      tr[i].cells[num].innerHTML.indexOf("Blocked") > -1 &&
        ((trValue1[j] = tr[i]), j++);
    for (i = 0; i < tr.length; i++)
      tr[i].cells[num].innerHTML.indexOf("Allowed") > -1 &&
        ((trValue2[k] = tr[i]), k++);
    trValue1.sort(compareCols(col, dataType)),
      trValue2.sort(compareCols(col, dataType));
    var fragment = document.createDocumentFragment();
    for (i = 0; i < trValue1.length; i++)
      (trValue1[i].className = i % 2 == 1 ? "even_line" : "odd_line"),
        fragment.appendChild(trValue1[i]);
    m = i;
    for (i = 0; i < trValue2.length; i++)
      (trValue2[i].className = m % 2 == 1 ? "even_line" : "odd_line"),
        fragment.appendChild(trValue2[i]),
        m++;
    tbody.appendChild(fragment), (tbody.sortCol = col);
  }
}
function access_cancel() {
  location.href = "AccessControl_show.htm";
}
function check_all_device(this_e, start, id) {
  for (
    var cf = document.forms[0], i = start, e, type = this_e.checked;
    (e = eval('document.getElementById("' + id + i + '")'));

  )
    (e.checked = type), i++;
  "checkbox_index" == id
    ? toggle_edit()
    : "checkbox_index_white" == id
    ? toggle_edit_allow()
    : "checkbox_index_black" == id && toggle_edit_block();
}
function set_allow_block(cf, flag) {
  access_control_apply(cf, "0");
  cf.submit_flag.value =
    1 == flag ? "acc_control_allow" : "acc_control_block";
  cf.anticsrf.value =
    1 == flag ? acc_control_allow_token : acc_control_block_token;
  var sel_num = 0,
    sel_list = "";
  if (!(access_control_device_num > 0)) return !1;
  for (i = 1; i <= access_control_device_num; i++) {
    var listName = "checkbox_index" + i;
    if (1 == document.getElementById(listName).checked) {
      if (
        0 == flag &&
        document.getElementById(listName).value.toLowerCase() ==
          wan_remote_mac.toLowerCase()
      )
        return alert("$not_block_device_msg"), !1;
      (sel_list += document.getElementById(listName).value),
        (sel_list += "#"),
        sel_num++;
    }
  }
  return (
    0 != sel_num &&
    (0 != flag || 0 == sel_num || 0 != confirm("$acc_block_check")) &&
    ((cf.hidden_change_list.value = sel_list),
    (cf.hidden_change_num.value = sel_num),
    void cf.submit())
  );
}
function check_edit() {
  var select_num,
    count = 0,
    cf = document.forms[0];
  if (0 == access_control_device_num) return alert("$port_edit"), !1;
  for (i = 1; i <= access_control_device_num; i++) {
    var listName = "checkbox_index" + i;
    1 == document.getElementById(listName).checked &&
      ((select_num = i + 1), count++);
  }
  return 0 == count || 1 != count
    ? (alert("$port_edit"), !1)
    : (access_control_apply(cf, "0"),
      (cf.select_edit.value = select_num - 1),
      (cf.submit_flag.value = "editnum_connect_device"),
      (cf.anticsrf.value = editnum_connect_device_token),
      (cf.action = "/apply.cgi?/edit_connect_device.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function delete_block() {
  var cf = document.forms[0];
  access_control_apply(cf, "0"), (cf.submit_flag.value = "delete_acc");
  cf.anticsrf.value = delete_acc_token;
  var sel_list = "",
    count = 0;
  if (!(blocked_no_connect_num > 0)) return !1;
  for (i = 1; i <= blocked_no_connect_num; i++) {
    var listName = "checkbox_index_black" + i;
    1 == document.getElementById(listName).checked &&
      ((sel_list += document.getElementById(listName).value),
      (sel_list += "#"),
      count++);
  }
  return (
    "" != sel_list &&
    0 != confirm("$acc_del_check") &&
    ((cf.hidden_del_list.value = sel_list),
    (cf.hidden_del_num.value = count),
    void cf.submit())
  );
}
function delete_allow() {
  var cf = document.forms[0];
  access_control_apply(cf, "0"), (cf.submit_flag.value = "delete_acc");
  cf.anticsrf.value = delete_acc_token;
  var sel_list = "",
    count = 0;
  if (!(allowed_no_connect_num > 0)) return !1;
  for (i = 1; i <= allowed_no_connect_num; i++) {
    var listName = "checkbox_index_white" + i;
    1 == document.getElementById(listName).checked &&
      ((sel_list += document.getElementById(listName).value),
      (sel_list += "#"),
      count++);
  }
  return (
    "" != sel_list &&
    0 != confirm("$acc_del_check") &&
    ((cf.hidden_del_list.value = sel_list),
    (cf.hidden_del_num.value = count),
    void cf.submit())
  );
}
function access_control_apply(cf, flag) {
  0 == cf.enable_acl.checked
    ? (cf.hid_able_block_device.value = 0)
    : (cf.hid_able_block_device.value = 1),
    0 == cf.access_all[0].checked
      ? (cf.hid_new_device_status.value = "Block")
      : (cf.hid_new_device_status.value = "Allow"),
    (cf.submit_flag.value = "apply_acc_control"),
    (cf.anticsrf.value = apply_acc_control_token),
    "1" == flag && cf.submit();
}
function check_status() {
  var flag,
    cf = document.forms[0];
  if (
    ((flag = !cf.enable_acl.checked),
    setDisabled(
      flag,
      cf.access_all[0],
      cf.access_all[1],
      cf.Allow,
      cf.Block,
      cf.checkbox_index
    ),
    setDisabled(
      flag,
      document.getElementById("delete_white"),
      document.getElementById("delete_black"),
      cf.checkbox_index_white,
      cf.checkbox_index_black,
      document.getElementById("add_black"),
      document.getElementById("add_white")
    ),
    0 == cf.enable_acl.checked)
  ) {
    for (
      setDisabled(!0, cf.edit_attached, cf.edit_white, cf.edit_black),
        enable_block_device = 0,
        cf.Allow.className = "common_gray_bt",
        cf.Block.className = "common_gray_bt",
        cf.edit_attached.className = "common_gray_bt",
        i = 1;
      i <= access_control_device_num;
      i++
    )
      document.getElementById("checkbox_index" + i).disabled = !0;
    for (
      document.getElementById("delete_white").className = "common_big_gray_bt",
        document.getElementById("add_white").className = "common_gray_bt",
        cf.edit_white.className = "common_gray_bt",
        i = 1;
      i <= allowed_no_connect_num;
      i++
    )
      document.getElementById("checkbox_index_white" + i).disabled = !0;
    for (
      document.getElementById("delete_black").className = "common_big_gray_bt",
        document.getElementById("add_black").className = "common_gray_bt",
        cf.edit_black.className = "common_gray_bt",
        i = 1;
      i <= blocked_no_connect_num;
      i++
    )
      document.getElementById("checkbox_index_black" + i).disabled = !0;
  } else {
    for (
      toggle_edit(),
        toggle_edit_allow(),
        toggle_edit_block(),
        enable_block_device = 1,
        cf.Allow.className = "common_bt",
        cf.Block.className = "common_bt",
        i = 1;
      i <= access_control_device_num;
      i++
    )
      document.getElementById("checkbox_index" + i).disabled = !1;
    for (
      document.getElementById("delete_white").className = "common_big_bt",
        document.getElementById("add_white").className = "common_bt",
        i = 1;
      i <= allowed_no_connect_num;
      i++
    )
      document.getElementById("checkbox_index_white" + i).disabled = !1;
    for (
      document.getElementById("delete_black").className = "common_big_bt",
        document.getElementById("add_black").className = "common_bt",
        i = 1;
      i <= blocked_no_connect_num;
      i++
    )
      document.getElementById("checkbox_index_black" + i).disabled = !1;
  }
}
function check_acc_add(cf, flag) {
  if (12 == cf.mac_addr.value.length && -1 == cf.mac_addr.value.indexOf(":")) {
    var mac = cf.mac_addr.value;
    cf.mac_addr.value =
      mac.substr(0, 2) +
      ":" +
      mac.substr(2, 2) +
      ":" +
      mac.substr(4, 2) +
      ":" +
      mac.substr(6, 2) +
      ":" +
      mac.substr(8, 2) +
      ":" +
      mac.substr(10, 2);
  } else if (6 == cf.mac_addr.value.split("-").length) {
    var tmp_mac = cf.mac_addr.value.replace(/-/g, ":");
    cf.mac_addr.value = tmp_mac;
  }
  if (0 == maccheck(cf.mac_addr.value)) return !1;
  if (
    "edit_allow" != flag &&
    "edit_block" != flag &&
    "edit_connect_device" != flag
  )
    for (i = 0; i < acc_mac_num; i++) {
      var str = eval("acc_mac" + i);
      if (str.toLowerCase() == cf.mac_addr.value.toLowerCase())
        return alert("$mac_dup"), !1;
    }
  if ("edit_allow" == flag) {
    for (i = 0; i < allowed_no_connect_num; i++) {
      var str = eval("allowed_no_connect" + i),
        each_info = str.split(" ");
      if (
        select_editnum != i &&
        each_info[1].toLowerCase() == cf.mac_addr.value.toLowerCase()
      )
        return alert("$mac_dup"), !1;
    }
    for (i = 0; i < blocked_no_connect_num; i++) {
      var str = eval("blocked_no_connect" + i),
        each_info = str.split(" ");
      if (each_info[1].toLowerCase() == cf.mac_addr.value.toLowerCase())
        return alert("$mac_dup"), !1;
    }
    for (i = 0; i < access_control_device_num; i++) {
      var str = eval("access_control_device" + i),
        each_info = str.split("*");
      if (each_info[2].toLowerCase() == cf.mac_addr.value.toLowerCase())
        return alert("$mac_dup"), !1;
    }
    (cf.hidden_allow_or_block.value = convert_value_to_original(
      cf,
      "allow_or_block"
    )),
      "Blocked" == cf.hidden_allow_or_block.value &&
        (cf.hidden_acc_edit_type.value = "block");
  }
  if ("edit_block" == flag) {
    for (i = 0; i < blocked_no_connect_num; i++) {
      var str = eval("blocked_no_connect" + i),
        each_info = str.split(" ");
      if (
        select_editnum != i &&
        each_info[1].toLowerCase() == cf.mac_addr.value.toLowerCase()
      )
        return alert("$mac_dup"), !1;
    }
    for (i = 0; i < allowed_no_connect_num; i++) {
      var str = eval("allowed_no_connect" + i),
        each_info = str.split(" ");
      if (each_info[1].toLowerCase() == cf.mac_addr.value.toLowerCase())
        return alert("$mac_dup"), !1;
    }
    for (i = 0; i < access_control_device_num; i++) {
      var str = eval("access_control_device" + i),
        each_info = str.split("*");
      if (each_info[2].toLowerCase() == cf.mac_addr.value.toLowerCase())
        return alert("$mac_dup"), !1;
    }
    (cf.hidden_allow_or_block.value = convert_value_to_original(
      cf,
      "allow_or_block"
    )),
      "Allowed" == cf.hidden_allow_or_block.value &&
        (cf.hidden_acc_edit_type.value = "allow");
  }
  if ("edit_connect_device" == flag) {
    if (access_mac.toLowerCase() == cf.hidden_edit_mac.value.toLowerCase()) {
      var str = document.getElementById("allow_or_block_connect_device");
      if (1 == str.options[1].selected)
        return alert("$not_block_device_msg"), !1;
    }
    cf.hidden_allow_or_block.value = convert_value_to_original(
      cf,
      "allow_or_block"
    );
  }
  return "" == cf.dev_name.value
    ? (alert("$device_name_null"), !1)
    : ((apply_flag = 1), cf.submit(), !0);
}
function check_allow_edit() {
  var cf = document.forms[0];
  if (0 == allowed_no_connect_num) return alert("$port_edit"), !1;
  var select_num,
    count = 0;
  for (i = 1; i <= allowed_no_connect_num; i++) {
    var listName = "checkbox_index_white" + i;
    1 == document.getElementById(listName).checked &&
      ((select_num = i + 1), count++);
  }
  return 0 == count || 1 != count
    ? (alert("$port_edit"), !1)
    : (access_control_apply(cf, "0"),
      (cf.select_edit.value = select_num - 1),
      (cf.submit_flag.value = "editnum_acc_allow"),
      (cf.anticsrf.value = editnum_acc_allow_token),
      (cf.action = "/apply.cgi?/edit_allowed.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function check_block_edit() {
  var cf = document.forms[0];
  if (0 == blocked_no_connect_num) return alert("$port_edit"), !1;
  var select_num,
    count = 0;
  for (i = 1; i <= blocked_no_connect_num; i++) {
    var listName = "checkbox_index_black" + i;
    1 == document.getElementById(listName).checked &&
      ((select_num = i + 1), count++);
  }
  return 0 == count || 1 != count
    ? (alert("$port_edit"), !1)
    : (access_control_apply(cf, "0"),
      (cf.select_edit.value = select_num - 1),
      (cf.submit_flag.value = "editnum_acc_block"),
      (cf.anticsrf.value = editnum_acc_block_token),
      (cf.action = "/apply.cgi?/edit_blocked.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function toggle_edit() {
  var num = 0,
    cf = document.forms[0];
  if (access_control_device_num > 0)
    for (var i = 1; i <= access_control_device_num; i++) {
      var listName = "checkbox_index" + i;
      1 == document.getElementById(listName).checked && num++;
    }
  1 == num
    ? ((cf.edit_attached.className = "common_bt"),
      (cf.edit_attached.disabled = !1))
    : ((cf.edit_attached.className = "common_gray_bt"),
      (cf.edit_attached.disabled = !0));
}
function toggle_edit_allow() {
  var num = 0,
    cf = document.forms[0];
  if (allowed_no_connect_num > 0)
    for (var i = 1; i <= allowed_no_connect_num; i++) {
      var listName = "checkbox_index_white" + i;
      1 == document.getElementById(listName).checked && num++;
    }
  1 == num
    ? ((cf.edit_white.className = "common_bt"), (cf.edit_white.disabled = !1))
    : ((cf.edit_white.className = "common_gray_bt"),
      (cf.edit_white.disabled = !0));
}
function toggle_edit_block() {
  var num = 0,
    cf = document.forms[0];
  if (blocked_no_connect_num > 0)
    for (var i = 1; i <= blocked_no_connect_num; i++) {
      var listName = "checkbox_index_black" + i;
      1 == document.getElementById(listName).checked && num++;
    }
  1 == num
    ? ((cf.edit_black.className = "common_bt"), (cf.edit_black.disabled = !1))
    : ((cf.edit_black.className = "common_gray_bt"),
      (cf.edit_black.disabled = !0));
}
