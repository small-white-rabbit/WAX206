var invalid_port_used = "$invalid_port_used";
function checkPort(name, port) {
  var msg = "",
    portNum = parseInt(port, 10);
  if (0 == port.length)
    return (msg = name + " " + "$trigger_null"), alert(msg), !1;
  for (i = 0; i < port.length; i++)
    if (((c = port.charAt(i)), "0123456789".indexOf(c, 0) < 0))
      return (msg = "$trigger_invalid" + name), alert(msg), !1;
  return (
    !(isNaN(portNum) || portNum < 1 || portNum > 65535) ||
    ((msg = "$trigger_invalid" + name + "$trigger_1_65535"), alert(msg), !1)
  );
}
function setsrc(cf) {
  1 == cf.src_ip_type.selectedIndex
    ? ((cf.src_ip1.disabled = !1),
      (cf.src_ip2.disabled = !1),
      (cf.src_ip3.disabled = !1),
      (cf.src_ip4.disabled = !1))
    : ((cf.src_ip1.disabled = !0),
      (cf.src_ip2.disabled = !0),
      (cf.src_ip3.disabled = !0),
      (cf.src_ip4.disabled = !0));
}
function check_triggering_add(cf, flag) {
  var all_port_num = 0;
  if ("add" == flag)
    for (i = 1; i <= trigger_array_num; i++) {
      var str = eval("triggeringArray" + i),
        each_info = str.split(" ");
      (constart_port = each_info[6]),
        (conend_port = each_info[7]),
        (all_port_num =
          all_port_num + parseInt(conend_port) - parseInt(constart_port) + 1);
    }
  else if ("edit" == flag)
    for (i = 1; i <= trigger_array_num; i++)
      if (select_editnum != i) {
        var str = eval("triggeringArray" + i),
          each_info = str.split(" ");
        (constart_port = each_info[6]),
          (conend_port = each_info[7]),
          (all_port_num =
            all_port_num + parseInt(conend_port) - parseInt(constart_port) + 1);
      }
  if (20 == trigger_array_num && "add" == flag)
    return alert("$trigger_length_20"), !1;
  if ("" == cf.pt_name.value) return alert("$trigger_ser_name_null"), !1;
  for (i = 0; i < cf.pt_name.value.length; i++)
    if (0 == isValidChar_space(cf.pt_name.value.charCodeAt(i)))
      return alert("$servname_not_allowed"), !1;
  for (i = 1; i <= trigger_array_num; i++) {
    var str = eval("triggeringArray" + i),
      each_info = str.split(" ");
    if (
      ((each_info[0] = each_info[0]
        .replace(/&harr;/g, " ")
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&")),
      "edit" == flag)
    ) {
      if (cf.pt_name.value == each_info[0] && select_editnum != i)
        return alert("$trigger_ser_name_dup"), !1;
    } else if (cf.pt_name.value == each_info[0])
      return alert("$trigger_ser_name_dup"), !1;
  }
  cf.pt_name.value = cf.pt_name.value
    .replace(/&/g, "&#38;")
    .replace(/ /g, "&harr;");
  var type = cf.src_ip_type.selectedIndex;
  if (0 == type) cf.service_ip.value = "any";
  else {
    if (
      ((cf.service_ip.value =
        cf.src_ip1.value +
        "." +
        cf.src_ip2.value +
        "." +
        cf.src_ip3.value +
        "." +
        cf.src_ip4.value),
      0 == checkipaddr(cf.service_ip.value) ||
        0 == is_sub_or_broad(cf.service_ip.value, lan_ip, lan_subnet))
    )
      return alert("$invalid_ip"), !1;
    if (
      ((cf.service_ip.value = address_parseInt(cf.service_ip.value)),
      0 == isSameSubNet(cf.service_ip.value, lan_subnet, lan_ip, lan_subnet))
    )
      return alert("$diff_lan_this_subnet"), !1;
    if (1 == isSameIp(cf.service_ip.value, lan_ip))
      return alert("$invalid_ip"), !1;
  }
  if (0 == checkPort("$trigger_port", cf.pt_port.value)) return !1;
  if (
    ((cf.pt_port.value = parseInt(cf.pt_port.value, 10)),
    0 == checkPort("$block_ser_start_port", cf.in_port_start.value))
  )
    return !1;
  if (
    ((cf.in_port_start.value = parseInt(cf.in_port_start.value, 10)),
    cf.in_port_end.value.length > 0)
  ) {
    if (0 == checkPort("$block_ser_end_port", cf.in_port_end.value)) return !1;
    if (
      ((cf.in_port_end.value = parseInt(cf.in_port_end.value, 10)),
      parseInt(cf.in_port_end.value) < parseInt(cf.in_port_start.value))
    )
      return alert("$trigger_invalid_port_rang"), !1;
  }
  0 == cf.in_port_end.value.length &&
    (cf.in_port_end.value = cf.in_port_start.value);
  var now_port_num = cf.in_port_end.value - cf.in_port_start.value + 1;
  all_port_num += now_port_num;
  var input_start_port = cf.in_port_start.value,
    input_end_port = cf.in_port_end.value,
    input_sertype = cf.in_port_type.value;
  for (i = 1; i <= forward_array_num; i++) {
    var str = eval("forwardingArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((sertype = each_info[1]),
      (startport = each_info[2]),
      (endport = each_info[3]),
      (serip = each_info[6]),
      (serflag = each_info[7]),
      "UDP" == sertype && "1" == serflag)
    );
    else if (
      !(
        parseInt(endport) < parseInt(input_start_port) ||
        parseInt(input_end_port) < parseInt(startport) ||
        ("TCP/UDP" != sertype &&
          "TCP/UDP" != input_sertype &&
          input_sertype != sertype) ||
        ("any" != cf.service_ip.value && cf.service_ip.value == serip)
      )
    )
      return alert(invalid_port_used), !1;
  }
  for (i = 1; i <= trigger_array_num; i++) {
    var str = eval("triggeringArray" + i)
        .replace(/&#92;/g, "\\")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#40;/g, "(")
        .replace(/&#41;/g, ")")
        .replace(/&#34;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#35;/g, "#")
        .replace(/&#38;/g, "&"),
      each_info = str.split(" ");
    if (
      ((trigip = each_info[2]),
      (consertype = each_info[5]),
      (constart_port = each_info[6]),
      (conend_port = each_info[7]),
      "edit" == flag)
    ) {
      if (
        !(
          parseInt(conend_port) < parseInt(input_start_port) ||
          parseInt(input_end_port) < parseInt(constart_port) ||
          select_editnum == i ||
          ("TCP/UDP" != consertype &&
            "TCP/UDP" != input_sertype &&
            input_sertype != consertype) ||
          select_editnum == i ||
          ("any" != cf.service_ip.value &&
          "any" != trigip &&
          cf.service_ip.value != trigip)
        )
      )
        return alert(invalid_port_used), !1;
    } else if (
      !(
        parseInt(conend_port) < parseInt(input_start_port) ||
        parseInt(input_end_port) < parseInt(constart_port) ||
        ("TCP/UDP" != consertype &&
          "TCP/UDP" != input_sertype &&
          input_sertype != consertype) ||
        ("any" != cf.service_ip.value &&
        "any" != trigip &&
        cf.service_ip.value != trigip)
      )
    )
      return alert(invalid_port_used), !1;
  }
  for (i = 1; i <= upnp_array_num; i++) {
    var str = eval("upnpArray" + i),
      each_info = str.split(";");
    if (
      ((upnp_protocal = each_info[1]),
      (upnp_int = each_info[2]),
      (upnp_ext = each_info[3]),
      (upnp_ip = each_info[4]),
      (
        parseInt(upnp_int) >= parseInt(input_start_port) &&
        parseInt(input_end_port) >= parseInt(upnp_int) &&
        ("any" == cf.service_ip.value || cf.service_ip.value == upnp_ip) &&
        ("TCP/UDP" == upnp_protocal ||
          "TCP/UDP" == input_sertype ||
          input_sertype == upnp_protocal)
      ))
    )
      return alert(invalid_port_used), !1;
  }
  return 1 == usb_router_flag &&
    "UDP" != input_sertype &&
    0 == check_readyshare_port(input_start_port, input_end_port, "WAN")
    ? (alert(invalid_port_used), !1)
    : "1" != endis_remote ||
      "UDP" == input_sertype ||
      parseInt(remote_port) < parseInt(input_start_port) ||
      parseInt(input_end_port) < parseInt(remote_port) ||
      "" == remote_port
    ? parseInt(input_start_port) <= 123 &&
      parseInt(input_end_port) >= 123 &&
      "1" == endis_ntp &&
      "TCP" != input_sertype
      ? (alert(invalid_port_used), !1)
      : parseInt(input_start_port) <= 1900 &&
        parseInt(input_end_port) >= 1900 &&
        "1" == endis_upnp &&
        "TCP" != input_sertype
      ? (alert(invalid_port_used), !1)
      : parseInt(input_start_port) <= 5050 &&
        parseInt(input_end_port) >= 5050 &&
        "bigpond" == info_get_wanproto &&
        "TCP" != input_sertype
      ? (alert(invalid_port_used), !1)
      : ((cf.pt_port.value = port_range_interception(cf.pt_port.value)),
        (cf.in_port_start.value = port_range_interception(
          cf.in_port_start.value
        )),
        (cf.in_port_end.value = port_range_interception(cf.in_port_end.value)),
        cf.submit(),
        !0)
    : (alert(invalid_port_used), !1);
}
function check_triggering_edit(cf) {
  if (0 == array_num) return (location.href = "edit_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.serviceSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.serviceSelect[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? ((location.href = "edit_fail.htm"), !1)
    : ((cf.select_edit.value = select_num),
      (cf.submit_flag.value = "triggering_editnum"),
      (cf.anticsrf.value = triggering_editnum_token),
      (cf.action = "/apply.cgi?/triggering_edit.htm timestamp=" + ts),
      cf.submit(),
      !0);
}
function check_triggering_del(cf) {
  if ("" == array_num) return (location.href = "del_fail.htm"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.serviceSelect.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.serviceSelect[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? ((location.href = "del_fail.htm"), !1)
    : ((cf.select_del.value = select_num),
      (cf.submit_flag.value = "triggering_del"),
      (cf.anticsrf.value = triggering_del_token),
      cf.submit(),
      !0);
}
function check_triggering_apply(cf) {
  if (
    (1 == cf.fwpt_enable.checked
      ? (cf.disable_trigger_on.value = 1)
      : (cf.disable_trigger_on.value = 0),
    "" == cf.fwpt_timeout.value)
  )
    return alert("$timeout_null"), !1;
  if (!_isNumeric(cf.fwpt_timeout.value))
    return alert("$invalid_trigger_timeout"), !1;
  if (
    ((cf.fwpt_timeout.value = parseInt(cf.fwpt_timeout.value, 10)),
    0 == array_num)
  );
  else if (1 == array_num)
    1 == cf.enable_triggering.checked
      ? (cf.endis_trigger_value.value = "1")
      : (cf.endis_trigger_value.value = "0");
  else
    for (i = 0; i < array_num; i++)
      1 == cf.enable_triggering[i].checked
        ? (cf.endis_trigger_value.value = cf.endis_trigger_value.value + "1,")
        : (cf.endis_trigger_value.value = cf.endis_trigger_value.value + "0,");
  return cf.submit(), !0;
}
