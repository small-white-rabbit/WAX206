function change_volumn_time() {
  var cf = document.forms[0];
  1 == cf.tm_type[0].checked
    ? ((cf.conntime_monthly_limit.disabled = !0),
      (cf.traff_dir.disabled = !1),
      check_limit())
    : ((cf.conntime_monthly_limit.disabled = !1),
      (cf.traff_dir.disabled = !0),
      (cf.volume_monthly_limit.disabled = !0),
      (cf.round_up_volume.disabled = !0));
}
function set_gray() {
  var dflag,
    cf = document.forms[0];
  (dflag = !cf.checkTraffic.checked),
    setDisabled(
      dflag,
      cf.tm_type[0],
      cf.tm_type[1],
      cf.traff_dir,
      cf.volume_monthly_limit,
      cf.round_up_volume,
      cf.conntime_monthly_limit,
      cf.hour,
      cf.minute,
      cf.day,
      cf.waterMark,
      cf.checkLed,
      cf.checkBlock,
      cf.ampm,
      cf.restartCounter,
      cf.refresh,
      cf.trafficStatus,
      cf.wan_interface
    ),
    1 == basic_type &&
      setDisabled(
        !0,
        cf.round_up_volume,
        cf.tm_type[1],
        cf.conntime_monthly_limit
      ),
    1 == cf.checkTraffic.checked
      ? ((document.getElementById("restart").className = "long_common_bt"),
        (document.getElementById("refresh").className = "common_key_bt"),
        (document.getElementById("status").className = "common_key_bt"),
        change_volumn_time(),
        check_limit())
      : ((document.getElementById("restart").className = "long_common_gray_bt"),
        (document.getElementById("refresh").className = "common_key_gray_bt"),
        (document.getElementById("status").className = "common_key_gray_bt"));
}
function check_traffic_apply(cf) {
  if (
    (1 == (cf = document.forms[0]).checkTraffic.checked
      ? (cf.endis_traffic.value = 1)
      : (cf.endis_traffic.value = 0),
    "1" == readyshare_mobile &&
      "15" != mobile_conn_status &&
      "1" == cf.wan_interface.value)
  )
    return (location.href = "traffic.htm"), !1;
  if (1 == cf.checkTraffic.checked) {
    if (cf.tm_type[0].checked) {
      if (
        ((cf.hidden_tm_type.value = "0"),
        "No limit" == cf.traff_dir.value
          ? (cf.hidden_traff_dir.value = "0")
          : "Download only" == cf.traff_dir.value
          ? (cf.hidden_traff_dir.value = "1")
          : (cf.hidden_traff_dir.value = "2"),
        "" == cf.volume_monthly_limit.value)
      )
        return alert("$monthly_limit_error"), !1;
      if (!_isNumeric(cf.volume_monthly_limit.value))
        return alert("$monthly_limit_error"), !1;
      if (parseInt(cf.volume_monthly_limit.value) > 4095e6)
        return alert("$monthly_limit_error"), !1;
      if ("" == cf.round_up_volume.value)
        return alert("$round_up_data_error"), !1;
      if (!_isNumeric(cf.round_up_volume.value))
        return alert("$round_up_data_error"), !1;
      if ("" == cf.waterMark.value) return alert("$left_volumn_error"), !1;
      if (!_isNumeric(cf.waterMark.value))
        return alert("$left_volumn_error"), !1;
      if (
        "0" != parseInt(cf.waterMark.value) &&
        "0" != parseInt(cf.volume_monthly_limit.value) &&
        parseInt(cf.waterMark.value) > parseInt(cf.volume_monthly_limit.value)
      )
        return alert("$left_volumn_small"), !1;
      if (
        (1 == basic_type &&
          "0" != cf.round_up_volume.value &&
          (cf.round_up_volume.value = "0"),
        0 == basic_type &&
          "0" != parseInt(cf.round_up_volume.value) &&
          "0" != parseInt(cf.volume_monthly_limit.value) &&
          parseInt(cf.round_up_volume.value) >=
            parseInt(cf.volume_monthly_limit.value))
      )
        return alert("$round_volumn_small"), !1;
      cf.hidden_round_up.value = cf.round_up_volume.value;
    } else {
      cf.hidden_tm_type.value = "1";
      var str1 = cf.conntime_monthly_limit.value;
      if ("" == cf.conntime_monthly_limit.value)
        return alert("$monthly_limit_error"), !1;
      for (var i = 0; i < str1.length; i++)
        if (!(str1[i] >= 0 && str1[i] <= 9))
          return alert("$month_linmit_int"), !1;
      if (!(cf.conntime_monthly_limit.value <= 744))
        return alert("$monthly_limit_744"), !1;
      if ("" == cf.waterMark.value) return alert("$left_volumn_error"), !1;
      if (!_isNumeric(cf.waterMark.value))
        return alert("$left_volumn_error"), !1;
      if (
        parseInt(cf.waterMark.value) >=
        60 * parseInt(cf.conntime_monthly_limit.value)
      )
        return alert("$left_volumn_small"), !1;
    }
    if (
      cf.hour.value < 0 ||
      cf.hour.value > 11 ||
      cf.minute.value < 0 ||
      cf.minute.value > 59
    )
      return alert("$invalid_time"), !1;
    if (!_isNumeric(cf.hour.value) || !_isNumeric(cf.minute.value))
      return alert("$invalid_time"), !1;
    if ("" == cf.hour.value || "" == cf.minute.value)
      return alert("$invalid_time"), !1;
    var hour = cf.hour.value,
      minute = cf.minute.value;
    hour.length < 2 && (hour = "0" + hour),
      minute.length < 2 && (minute = "0" + minute),
      1 == cf.ampm.selectedIndex &&
        (hour = (hour = parseInt(hour, 10) + 12).toString()),
      (cf.restart_counter_time.value = hour + ":" + minute),
      1 == cf.checkLed.checked
        ? (cf.traffic_led.value = 1)
        : (cf.traffic_led.value = 0),
      1 == cf.checkBlock.checked
        ? (cf.traffic_block_all.value = 1)
        : (cf.traffic_block_all.value = 0);
  }
  return cf.submit(), !0;
}
function click_restart() {
  var cf = document.forms[0];
  1 == cf.checkTraffic.checked &&
    sAlert(
      "$traffic_restart_counter",
      function () {
        cf.submit_flag.value = "traffic_reset";
        cf.anticsrf.value = traffic_reset_token;
        cf.submit();
      },
      function () {
        return !1;
      },
      475,
      1,
      "yes/no"
    );
}
function click_refresh_2() {
  1 == document.forms[0].checkTraffic.checked &&
    (location.href = "traffic.htm");
}
function click_status() {
  1 == document.forms[0].checkTraffic.checked &&
    window.open(
      "show_traffic.htm",
      "show_traffic",
      "width=600,height=400,top=200,left=200,status=yes,resizable=yes"
    );
}
function reset_time() {
  if (((cf = document.forms[0]), "" == cf.interval.value))
    return (cf.interval.value = "10"), !0;
  var timeset = cf.interval.value;
  for (i = 0; i < timeset.length; i++)
    if (((c = timeset.charAt(i)), "0123456789".indexOf(c, 0) < 0))
      return alert("$rang_pool"), !1;
  return (
    (cf.interval.value = parseInt(cf.interval.value, 10)),
    cf.interval.value >= 5 && cf.interval.value <= 86400
      ? (cf.submit(), !0)
      : (alert("$rang_pool"), !1)
  );
}
function click_refresh() {
  cf = document.forms[0];
  cf.submit_flag.value = "refresh_traffic";
  cf.anticsrf.value = refresh_traffic_token;
  cf.action = "/cgi-bin/no_commit.cgi?/cgi-bin/traffic.htm";
  cf.submit();
}
