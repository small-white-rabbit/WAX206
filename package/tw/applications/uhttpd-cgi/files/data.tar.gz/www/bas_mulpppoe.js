function show_hidden_help(help_flag) {
  if (!isIE_or_Opera() || IE_version() >= 9) Not_IE_show_hidden_help(help_flag);
  else {
    var frame_height = getTop(window)
      .document.getElementById("formframe_div")
      .style.height.replace(/px/, "");
    help_flag % 2 == 0
      ? ((document.getElementById("main").style.height = frame_height - 285),
        (document.getElementById("help").style.display = ""),
        (document.getElementById("help_switch").className = "open_help"))
      : ((document.getElementById("help").style.display = "none"),
        (document.getElementById("help_switch").className = "close_help"),
        (document.getElementById("main").style.height = frame_height - 165));
  }
}
function show_hidden_help_top_button(help_flag) {
  if (!isIE_or_Opera() || IE_version() >= 8) Not_IE_show_hidden_help(help_flag);
  else {
    var frame_height = getTop(window)
      .document.getElementById("formframe_div")
      .style.height.replace(/px/, "");
    help_flag % 2 == 0
      ? ((document.getElementById("main").style.height = frame_height - 285),
        (document.getElementById("help").style.display = ""),
        (document.getElementById("help_switch").className = "open_help"))
      : ((document.getElementById("help").style.display = "none"),
        (document.getElementById("help_switch").className = "close_help"),
        (document.getElementById("main").style.height = frame_height - 165));
  }
}
function loadMPhelp(fname, anchname) {
  1 == loadMPhelp.arguments.length || "" == anchname
    ? (this.helpframe.location.href = "/h" + fname + ".html")
    : (this.helpframe.location.href = "/h" + fname + ".html#" + anchname);
}
function getObj(name) {
  return document.getElementById
    ? document.getElementById(name)
    : document.all
    ? document.all[name]
    : document.layers
    ? document.layers[name]
    : void 0;
}
function setIP(cf) {
  var dflag = cf.WANAssign[0].checked;
  setDisabled(dflag, cf.WPethr1, cf.WPethr2, cf.WPethr3, cf.WPethr4),
    cf.WANAssign[1].checked && ((cf.DNSAssign[1].checked = !0), setDNS(cf)),
    (DisableFixedIP = dflag);
}
function setIP2(cf) {
  var dflag2 = cf.WANAssign2[0].checked;
  setDisabled(
    dflag2,
    cf.pppoe2_ip1,
    cf.pppoe2_ip2,
    cf.pppoe2_ip3,
    cf.pppoe2_ip4
  ),
    cf.WANAssign2[1].checked && ((cf.DNSAssign2[1].checked = !0), setDNS2(cf)),
    (DisableFixedIP = dflag2);
}
function setDNS(cf) {
  var dflag = cf.DNSAssign[0].checked;
  cf.WANAssign[1].checked && ((cf.DNSAssign[1].checked = !0), (dflag = !1)),
    setDisabled(
      dflag,
      cf.PDAddr1,
      cf.PDAddr2,
      cf.PDAddr3,
      cf.PDAddr4,
      cf.DAddr1,
      cf.DAddr2,
      cf.DAddr3,
      cf.DAddr4
    ),
    (DisableFixedDNS = dflag);
}
function setDNS2(cf) {
  var dflag2 = cf.DNSAssign2[0].checked;
  cf.WANAssign2[1].checked && ((cf.DNSAssign2[1].checked = !0), (dflag2 = !1)),
    setDisabled(
      dflag2,
      cf.pppoe2_dnsp1,
      cf.pppoe2_dnsp2,
      cf.pppoe2_dnsp3,
      cf.pppoe2_dnsp4,
      cf.pppoe2_dnss1,
      cf.pppoe2_dnss2,
      cf.pppoe2_dnss3,
      cf.pppoe2_dnss4
    ),
    (DisableFixedDNS = dflag2);
}
function change_mulpppoe_password(obj) {
  "password" == obj.type &&
    ("Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : "pppoe_passwd" == obj.name
      ? ((obj.outerHTML =
          '<input type="text" name="pppoe_passwd" maxlength="64" size="16" onFocus="this.select();" onKeyPress="return getkey(\'ssid\', event)" value="" autocomplete="off">'),
        document.forms[0].pppoe_passwd.focus(),
        document.forms[0].pppoe_passwd.focus())
      : "pppoe2_password" == obj.name &&
        ((obj.outerHTML =
          '<input type="text" name="pppoe2_password" maxlength="64" size="16" onFocus="this.select();" onKeyPress="return getkey(\'ssid\', event)" value="" autocomplete="off">'),
        document.forms[0].pppoe2_password.focus(),
        document.forms[0].pppoe2_password.focus()));
}
function setPolicy() {
  var cf = document.forms[0],
    select_index = cf.pppoe2_policy.selectedIndex;
  0 == select_index
    ? ((getObj("mul_doname").innerHTML = str3_div),
      (cf.userdefined.disabled = !1))
    : 2 == select_index
    ? ((getObj("mul_protocol").innerHTML = str1_div),
      (getObj("mul_port").innerHTML = str2_div),
      (cf.protocol.disabled = !1),
      (cf.portstart.disabled = !1),
      (cf.portend.disabled = !1))
    : 1 == select_index
    ? ((getObj("mul_protocol").innerHTML = str1_div),
      (getObj("mul_ip").innerHTML = str4_div),
      (cf.protocol.disabled = !1),
      (cf.start_ip1.disabled = !1),
      (cf.start_ip2.disabled = !1),
      (cf.start_ip3.disabled = !1),
      (cf.start_ip4.disabled = !1),
      (cf.end_ip4.disabled = !1))
    : 3 == select_index &&
      ((cf.protocol.disabled = !1),
      (cf.portstart.disabled = !1),
      (cf.portend.disabled = !1),
      (cf.userdefined.disabled = !0),
      (cf.start_ip1.disabled = !1),
      (cf.start_ip2.disabled = !1),
      (cf.start_ip3.disabled = !1),
      (cf.start_ip4.disabled = !1),
      (cf.end_ip4.disabled = !1));
}
function check_mulpppoe_add(cf, flag) {
  var txt, c;
  if (
    (format_IP("start_ip1", "start_ip2", "start_ip3", "start_ip4", "end_ip4"),
    (cf.hidden_portstart.value = "--"),
    (cf.hidden_portend.value = "--"),
    (cf.hidden_protocol_value.value = "--"),
    (cf.hidden_userdefined.value = "--"),
    (cf.hidden_ip_start.value = "--"),
    (cf.hidden_ip_end.value = "--"),
    2 == cf.pppoe2_policy.selectedIndex || 3 == cf.pppoe2_policy.selectedIndex)
  ) {
    if ("" == cf.portstart.value || "" == cf.portend.value)
      return alert("$invalid_port"), !1;
    for (txt = cf.portstart.value, i = 0; i < txt.length; i++)
      if (((c = txt.charAt(i)), "0123456789".indexOf(c, 0) < 0))
        return alert("$invalid_start_port"), !1;
    for (txt = cf.portend.value, i = 0; i < txt.length; i++)
      if (((c = txt.charAt(i)), "0123456789".indexOf(c, 0) < 0))
        return alert("$invalid_end_port"), !1;
    if (
      parseInt(cf.portstart.value) < 1 ||
      parseInt(cf.portstart.value) > 65535
    )
      return alert("$invalid_start_port"), !1;
    if (parseInt(cf.portend.value) < 1 || parseInt(cf.portend.value) > 65535)
      return alert("$invalid_end_port"), !1;
    if (parseInt(cf.portend.value) < parseInt(cf.portstart.value))
      return alert("$end_port_greater"), !1;
    for (i = 1; i <= array_num; i++) {
      var str = eval("mulpppoeArray" + i),
        each_info = str.split(" ");
      if ("--" != each_info[4] && "--" != each_info[5])
        if ("edit" == flag) {
          if (
            !(
              parseInt(each_info[4]) > parseInt(cf.portend.value) ||
              parseInt(each_info[5]) < parseInt(cf.portstart.value)
            ) &&
            i != select_edit
          )
            return alert("$port_dup"), !1;
        } else if (
          !(
            parseInt(each_info[4]) > parseInt(cf.portend.value) ||
            parseInt(each_info[5]) < parseInt(cf.portstart.value)
          )
        )
          return alert("$port_dup"), !1;
    }
    (cf.hidden_portstart.value = cf.portstart.value),
      (cf.hidden_portend.value = cf.portend.value);
  }
  if (0 == cf.pppoe2_policy.selectedIndex) {
    if (((txt = cf.userdefined.value), "" == txt))
      return alert("$invalid_user_type"), !1;
    for (i = 0; i < cf.userdefined.value.length; i++)
      if (0 == isValidDdnsHost(cf.userdefined.value.charCodeAt(i)))
        return alert("$invalid_user_type"), !1;
    for (i = 1; i <= array_num; i++) {
      var str = eval("mulpppoeArray" + i),
        each_info = str.split(" ");
      if ("edit" == flag) {
        if (each_info[1] == txt && i != select_edit)
          return alert("$doname_dup"), !1;
      } else if (each_info[1] == txt) return alert("$doname_dup"), !1;
    }
    cf.hidden_userdefined.value = cf.userdefined.value;
  } else cf.hidden_protocol_value.value = cf.protocol.value;
  if (
    1 == cf.pppoe2_policy.selectedIndex ||
    3 == cf.pppoe2_policy.selectedIndex
  ) {
    if (
      ((cf.ip_start.value =
        cf.start_ip1.value +
        "." +
        cf.start_ip2.value +
        "." +
        cf.start_ip3.value +
        "." +
        cf.start_ip4.value),
      (cf.ip_end.value =
        cf.start_ip1.value +
        "." +
        cf.start_ip2.value +
        "." +
        cf.start_ip3.value +
        "." +
        cf.end_ip4.value),
      0 == checkipaddr(cf.ip_start.value))
    )
      return alert("$invalid_ip"), !1;
    if (0 == checkipaddr(cf.ip_end.value)) return alert("$invalid_ip"), !1;
    if (0 == cp_ip2(cf.ip_start.value, cf.ip_end.value))
      return alert("$invalid_ip_rang"), !1;
    (cf.hidden_ip_start.value = cf.ip_start.value),
      (cf.hidden_ip_end.value = cf.ip_end.value);
  }
  return !0;
}
function check_mulpppoe_addnum(cf, flag) {
  return (
    (cf.submit_flag.value = "mulpppoe_addnum"),
    (cf.anticsrf.value = mulpppoe_addnum_token),
    (cf.action =
      1 == flag
        ? "/apply.cgi?/BAS_mulpppoe_add.htm timestamp=" + ts
        : "/apply.cgi?/BAS_mulpppoe_add_ww.htm timestamp=" + ts),
    !0
  );
}
function check_mulpppoe_editnum(cf, flag) {
  if ("" == array_num) return alert("$port_edit"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.select_mulpppoe.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.select_mulpppoe[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$select_serv_edit"), !1)
    : ((cf.select_edit.value = select_num),
      (cf.submit_flag.value = "mulpppoe_editnum"),
      (cf.anticsrf.value = mulpppoe_editnum_token),
      (cf.action =
        1 == flag
          ? "/apply.cgi?/BAS_mulpppoe_edit.htm timestamp=" + ts
          : "/apply.cgi?/BAS_mulpppoe_edit_ww.htm timestamp=" + ts),
      !0);
}
function check_mulpppoe_session1(cf, check) {
  if ("" == cf.pppoe_username.value) return alert("$login_name_null"), !1;
  for (i = 0; i < cf.pppoe_username.value.length; i++)
    if (0 == isValidChar(cf.pppoe_username.value.charCodeAt(i)))
      return alert("$loginname_not_allowed"), !1;
  for (i = 0; i < cf.pppoe_passwd.value.length; i++)
    if (0 == isValidChar(cf.pppoe_passwd.value.charCodeAt(i)))
      return alert("$password_not_allowed"), !1;
  for (i = 0; i < cf.pppoe_servername.value.length; i++)
    if (0 == isValidChar(cf.pppoe_servername.value.charCodeAt(i)))
      return alert("$servname_not_allowed"), !1;
  if (cf.pppoe_idletime.value.length <= 0) return alert("$idle_time_null"), !1;
  if (!_isNumeric(cf.pppoe_idletime.value))
    return alert("$invalid_idle_time"), !1;
  if (
    ((cf.pppoe_idletime_value.value = 60 * cf.pppoe_idletime.value),
    (cf.conflict_wanlan.value = 0),
    cf.WANAssign[1].checked)
  ) {
    if (
      ((cf.pppoe_ipaddr.value =
        cf.WPethr1.value +
        "." +
        cf.WPethr2.value +
        "." +
        cf.WPethr3.value +
        "." +
        cf.WPethr4.value),
      0 == checkipaddr(cf.pppoe_ipaddr.value))
    )
      return alert("$invalid_ip"), !1;
    1 == isSameSubNet(cf.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pppoe_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1);
  }
  if (cf.DNSAssign[1].checked) {
    if (
      ((cf.pppoe_dnsaddr1.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      (cf.pppoe_dnsaddr2.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      "..." == cf.pppoe_dnsaddr2.value && (cf.pppoe_dnsaddr2.value = ""),
      0 == checkipaddr(cf.pppoe_dnsaddr1.value))
    )
      return alert("$invalid_primary_dns"), !1;
    if (
      "" != cf.pppoe_dnsaddr2.value &&
      0 == checkipaddr(cf.pppoe_dnsaddr2.value)
    )
      return alert("$invalid_second_dns"), !1;
  }
  return (
    (cf.hid_mtu_value.value = wan_mtu_now),
    "mulpppoe1" != old_wan_type
      ? ((cf.change_wan_type.value = 0), mtu_change(wanproto_type))
      : "1" == old_pppoe_wan_assign
      ? old_wan_ip != cf.pppoe_ipaddr.value && cf.WANAssign[1].checked
        ? (cf.change_wan_type.value = 0)
        : cf.WANAssign[0].checked
        ? (cf.change_wan_type.value = 0)
        : (cf.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign &&
        (old_wan_ip != cf.pppoe_ipaddr.value && cf.WANAssign[1].checked
          ? (cf.change_wan_type.value = 0)
          : (cf.change_wan_type.value = 1)),
    (cf.run_test.value = 0 != check ? "test" : "no"),
    (cf.mul_testnum.value = "1"),
    !0
  );
}
function check_mulpppoe_session2(cf, check) {
  if ("" == cf.pppoe2_username.value) return alert("$login_name_null"), !1;
  for (i = 0; i < cf.pppoe2_username.value.length; i++)
    if (0 == isValidChar(cf.pppoe2_username.value.charCodeAt(i)))
      return alert("$loginname_not_allowed"), !1;
  for (i = 0; i < cf.pppoe2_password.value.length; i++)
    if (0 == isValidChar(cf.pppoe2_password.value.charCodeAt(i)))
      return alert("$password_not_allowed"), !1;
  for (i = 0; i < cf.pppoe2_servicename.value.length; i++)
    if (0 == isValidChar(cf.pppoe2_servicename.value.charCodeAt(i)))
      return alert("$servname_not_allowed"), !1;
  if (cf.WANAssign2[1].checked) {
    if (
      ((cf.pppoe2_ipaddr.value =
        cf.pppoe2_ip1.value +
        "." +
        cf.pppoe2_ip2.value +
        "." +
        cf.pppoe2_ip3.value +
        "." +
        cf.pppoe2_ip4.value),
      0 == checkipaddr(cf.pppoe2_ipaddr.value))
    )
      return alert("$invalid_ip"), !1;
    1 == isSameSubNet(cf.pppoe2_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pppoe2_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1);
  }
  if (cf.DNSAssign2[1].checked) {
    if (
      ((cf.pppoe2_dnsaddr1.value =
        cf.pppoe2_dnsp1.value +
        "." +
        cf.pppoe2_dnsp2.value +
        "." +
        cf.pppoe2_dnsp3.value +
        "." +
        cf.pppoe2_dnsp4.value),
      (cf.pppoe2_dnsaddr2.value =
        cf.pppoe2_dnss1.value +
        "." +
        cf.pppoe2_dnss2.value +
        "." +
        cf.pppoe2_dnss3.value +
        "." +
        cf.pppoe2_dnss4.value),
      "..." == cf.pppoe2_dnsaddr2.value && (cf.pppoe2_dnsaddr2.value = ""),
      0 == checkipaddr(cf.pppoe2_dnsaddr1.value))
    )
      return alert("$invalid_primary_dns"), !1;
    if (
      "" != cf.pppoe2_dnsaddr2.value &&
      0 == checkipaddr(cf.pppoe2_dnsaddr2.value)
    )
      return alert("$invalid_second_dns"), !1;
  }
  return (
    "mulpppoe1" != old_wan_type
      ? (cf.change_wan_type.value = 0)
      : "1" == old_pppoe_wan_assign2
      ? old_wan_ip2 != cf.pppoe2_ipaddr.value && cf.WANAssign2[1].checked
        ? (cf.change_wan_type.value = 0)
        : cf.WANAssign2[0].checked
        ? (cf.change_wan_type.value = 0)
        : (cf.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign2 &&
        (old_wan_ip2 != cf.pppoe2_ipaddr.value && cf.WANAssign2[1].checked
          ? (cf.change_wan_type.value = 0)
          : (cf.change_wan_type.value = 1)),
    (cf.run_test.value = 0 != check ? "test" : "no"),
    (cf.mul_testnum.value = "2"),
    !0
  );
}
function check_mulpppoe(cf, check) {
  if (
    (format_IP(
      "WPethr1",
      "WPethr2",
      "WPethr3",
      "WPethr4",
      "PDAddr1",
      "PDAddr2",
      "PDAddr3",
      "PDAddr4",
      "DAddr1",
      "DAddr2",
      "DAddr3",
      "DAddr4",
      "pppoe2_ip1",
      "pppoe2_ip2",
      "pppoe2_ip3",
      "pppoe2_ip4",
      "pppoe2_dnsp1",
      "pppoe2_dnsp2",
      "pppoe2_dnsp3",
      "pppoe2_dnsp4",
      "pppoe2_dnss1",
      "pppoe2_dnss2",
      "pppoe2_dnss3",
      "pppoe2_dnss4"
    ),
    "" == cf.pppoe_username.value)
  )
    return alert("$login_name_null"), !1;
  for (i = 0; i < cf.pppoe_username.value.length; i++)
    if (0 == isValidChar(cf.pppoe_username.value.charCodeAt(i)))
      return alert("$loginname_not_allowed"), !1;
  for (i = 0; i < cf.pppoe_passwd.value.length; i++)
    if (0 == isValidChar(cf.pppoe_passwd.value.charCodeAt(i)))
      return alert("$password_not_allowed"), !1;
  for (i = 0; i < cf.pppoe_servername.value.length; i++)
    if (0 == isValidChar(cf.pppoe_servername.value.charCodeAt(i)))
      return alert("$servname_not_allowed"), !1;
  if (cf.pppoe_idletime.value.length <= 0) return alert("$idle_time_null"), !1;
  if (!_isNumeric(cf.pppoe_idletime.value))
    return alert("$invalid_idle_time"), !1;
  if (
    ((cf.pppoe_idletime_value.value = 60 * cf.pppoe_idletime.value),
    (cf.conflict_wanlan.value = 0),
    cf.WANAssign[1].checked)
  ) {
    if (
      ((cf.pppoe_ipaddr.value =
        cf.WPethr1.value +
        "." +
        cf.WPethr2.value +
        "." +
        cf.WPethr3.value +
        "." +
        cf.WPethr4.value),
      0 == checkipaddr(cf.pppoe_ipaddr.value))
    )
      return alert("$invalid_ip"), !1;
    1 == isSameSubNet(cf.pppoe_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
      (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pppoe_ipaddr.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1);
  }
  if (cf.DNSAssign[1].checked) {
    if (
      ((cf.pppoe_dnsaddr1.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      (cf.pppoe_dnsaddr2.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      "..." == cf.pppoe_dnsaddr2.value && (cf.pppoe_dnsaddr2.value = ""),
      0 == checkipaddr(cf.pppoe_dnsaddr1.value))
    )
      return alert("$invalid_primary_dns"), !1;
    if (
      "" != cf.pppoe_dnsaddr2.value &&
      0 == checkipaddr(cf.pppoe_dnsaddr2.value)
    )
      return alert("$invalid_second_dns"), !1;
  }
  if (cf.enable_session2[1].checked) {
    if ("" == cf.pppoe2_username.value) return alert("$login_name_null"), !1;
    for (i = 0; i < cf.pppoe2_username.value.length; i++)
      if (0 == isValidChar(cf.pppoe2_username.value.charCodeAt(i)))
        return alert("$loginname_not_allowed"), !1;
    for (i = 0; i < cf.pppoe2_password.value.length; i++)
      if (0 == isValidChar(cf.pppoe2_password.value.charCodeAt(i)))
        return alert("$password_not_allowed"), !1;
    for (i = 0; i < cf.pppoe2_servicename.value.length; i++)
      if (0 == isValidChar(cf.pppoe2_servicename.value.charCodeAt(i)))
        return alert("$servname_not_allowed"), !1;
    if (cf.WANAssign2[1].checked) {
      if (
        ((cf.pppoe2_ipaddr.value =
          cf.pppoe2_ip1.value +
          "." +
          cf.pppoe2_ip2.value +
          "." +
          cf.pppoe2_ip3.value +
          "." +
          cf.pppoe2_ip4.value),
        0 == checkipaddr(cf.pppoe2_ipaddr.value))
      )
        return alert("$invalid_ip"), !1;
      1 ==
        isSameSubNet(cf.pppoe2_ipaddr.value, lan_subnet, lan_ip, lan_subnet) &&
        (cf.conflict_wanlan.value = 1),
        1 == isSameIp(cf.pppoe2_ipaddr.value, lan_ip) &&
          (cf.conflict_wanlan.value = 1);
    }
    if (cf.DNSAssign2[1].checked) {
      if (
        ((cf.pppoe2_dnsaddr1.value =
          cf.pppoe2_dnsp1.value +
          "." +
          cf.pppoe2_dnsp2.value +
          "." +
          cf.pppoe2_dnsp3.value +
          "." +
          cf.pppoe2_dnsp4.value),
        (cf.pppoe2_dnsaddr2.value =
          cf.pppoe2_dnss1.value +
          "." +
          cf.pppoe2_dnss2.value +
          "." +
          cf.pppoe2_dnss3.value +
          "." +
          cf.pppoe2_dnss4.value),
        "..." == cf.pppoe2_dnsaddr2.value && (cf.pppoe2_dnsaddr2.value = ""),
        0 == checkipaddr(cf.pppoe2_dnsaddr1.value))
      )
        return alert("$invalid_primary_dns"), !1;
      if (
        "" != cf.pppoe2_dnsaddr2.value &&
        0 == checkipaddr(cf.pppoe2_dnsaddr2.value)
      )
        return alert("$invalid_second_dns"), !1;
    }
  }
  return (
    "mulpppoe1" != old_wan_type
      ? (cf.change_wan_type.value = 0)
      : "1" == old_pppoe_wan_assign
      ? old_wan_ip != cf.pppoe_ipaddr.value && cf.WANAssign[1].checked
        ? (cf.change_wan_type.value = 0)
        : cf.WANAssign[0].checked
        ? (cf.change_wan_type.value = 0)
        : (cf.change_wan_type.value = 1)
      : "0" == old_pppoe_wan_assign &&
        (old_wan_ip != cf.pppoe_ipaddr.value && cf.WANAssign[1].checked
          ? (cf.change_wan_type.value = 0)
          : (cf.change_wan_type.value = 1)),
    0 != check
      ? ((cf.run_test.value = "test"), (cf.mul_testnum.value = "0"))
      : ((cf.run_test.value = "no"), (cf.mul_testnum.value = "0")),
    (cf.hid_mulpppoe_demand.value = convert_value_to_original(
      cf,
      "mulpppoe_demand"
    )),
    ("1" != cf.hid_mulpppoe_demand.value &&
      "2" != cf.hid_mulpppoe_demand.value) ||
      ("1" != readycloud_enable &&
        "1" != vpn_enable &&
        "1" != upnp_enableMedia &&
        "1" != parent.geniecloud_flag) ||
      0 != confirm("$ppp_dial_on_demand_query")
  );
}
function set_gray(check) {
  (cf = document.forms[0]),
    0 == check
      ? ((cf.pppoe2_username.disabled = !0),
        (cf.pppoe2_password.disabled = !0),
        (cf.pppoe2_servicename.disabled = !0))
      : ((cf.pppoe2_username.disabled = !1),
        (cf.pppoe2_password.disabled = !1),
        (cf.pppoe2_servicename.disabled = !1));
}
function change_session() {
  (cf = document.forms[0]),
    1 == cf.pppoe2_session[0].selected
      ? ((getObj("view_session").innerHTML = westHTML),
        (cf.pppoe2_username.value = west_username),
        (cf.pppoe2_password.value = west_password),
        (cf.pppoe2_servicename.value = west_servicename))
      : 1 == document.forms[0].pppoe2_session[1].selected
      ? ((getObj("view_session").innerHTML = eastHTML),
        (cf.pppoe2_username.value = east_username),
        (cf.pppoe2_password.value = east_password),
        (cf.pppoe2_servicename.value = east_servicename))
      : 1 == document.forms[0].pppoe2_session[2].selected &&
        ((getObj("view_session").innerHTML = otherHTML),
        (cf.pppoe2_username.value = other_username),
        (cf.pppoe2_password.value = other_password),
        (cf.pppoe2_servicename.value = other_servicename),
        (cf.pppoe2_policy.value = pppoe2_policy));
}
function check_mulpppoe_del(cf, flag) {
  if ("" == array_num) return alert("$port_del"), !1;
  var select_num,
    count_select = 0;
  if (1 == array_num)
    1 == cf.select_mulpppoe.checked && (count_select++, (select_num = 1));
  else
    for (i = 0; i < array_num; i++)
      1 == cf.select_mulpppoe[i].checked &&
        (count_select++, (select_num = i + 1));
  return 0 == count_select
    ? (alert("$select_serv_del"), !1)
    : ((cf.select_del.value = select_num),
      (cf.submit_flag.value = "mulpppoe_del"),
      (cf.anticsrf.value = mulpppoe_del_token),
      (cf.action =
        1 == flag
          ? "/apply.cgi?/BAS_mulpppoe.htm timestamp=" + ts
          : "/apply.cgi?/BAS_mulpppoe_ww.htm timestamp=" + ts),
      !0);
}
