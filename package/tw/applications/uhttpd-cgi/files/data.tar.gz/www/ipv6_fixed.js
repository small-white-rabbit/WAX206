function check_ipv6_fixed(cf) {
  var i,
    ip_trans_array = new Array("", "", "", "", "");
  (cf.ipv6_wan_ip_fixed.value = ""),
    (cf.ipv6_wan_gw_fixed.value = ""),
    (cf.ipv6_primary_dns_fixed.value = ""),
    (cf.ipv6_second_dns_fixed.value = ""),
    (cf.ipv6_lan_ip_fixed.value = "");
  var check_pri_dns = 1,
    check_sec_dns = 1,
    check_gate_way = 1,
    pri_dns = "",
    sec_dns = "",
    gate_way = "";
  for (i = 1; i <= 8; i++)
    (pri_dns += eval('document.getElementsByName("PDAddr' + i + '")[0]').value),
      (sec_dns += eval('document.getElementsByName("SDAddr' + i + '")[0]')
        .value),
      (gate_way += eval('document.getElementsByName("IPv6Gateway' + i + '")[0]')
        .value);
  for (
    "" == pri_dns && (check_pri_dns = 0),
      "" == sec_dns && (check_sec_dns = 0),
      "" == gate_way && (check_gate_way = 0),
      i = 1;
    i <= 8;
    i++
  ) {
    var ipv6_wan_value = eval(
      'document.getElementsByName("IPv6WanAddr' + i + '")[0]'
    ).value;
    if (0 == check_ipv6_IP_address(ipv6_wan_value))
      return alert("$invalid_wan_ipv6_hex"), !1;
    if (
      ("" != ipv6_wan_value &&
        (ipv6_wan_value = parseInt(ipv6_wan_value, 16).toString(16)),
      "" == ipv6_wan_value
        ? ((ip_trans_array[0] = ip_trans_array[0] + "0" + ":"),
          (cf.ipv6_wan_ip_fixed.value = cf.ipv6_wan_ip_fixed.value + "0" + ":"))
        : ((ip_trans_array[0] = ip_trans_array[0] + ipv6_wan_value + ":"),
          (cf.ipv6_wan_ip_fixed.value =
            cf.ipv6_wan_ip_fixed.value + ipv6_wan_value + ":")),
      check_gate_way)
    ) {
      var ipv6_gateway_value = eval(
        'document.getElementsByName("IPv6Gateway' + i + '")[0]'
      ).value;
      if (0 == check_ipv6_IP_address(ipv6_gateway_value))
        return alert("$invalid_wan_ipv6_gateway"), !1;
      "" != ipv6_gateway_value &&
        (ipv6_gateway_value = parseInt(ipv6_gateway_value, 16).toString(16)),
        "" == ipv6_gateway_value
          ? ((ip_trans_array[1] = ip_trans_array[1] + "0" + ":"),
            (cf.ipv6_wan_gw_fixed.value =
              cf.ipv6_wan_gw_fixed.value + "0" + ":"))
          : ((ip_trans_array[1] = ip_trans_array[1] + ipv6_gateway_value + ":"),
            (cf.ipv6_wan_gw_fixed.value =
              cf.ipv6_wan_gw_fixed.value + ipv6_gateway_value + ":"));
    }
    if (check_pri_dns) {
      var ipv6_pdaddr_value = eval(
        'document.getElementsByName("PDAddr' + i + '")[0]'
      ).value;
      if (0 == check_ipv6_DNS_address(ipv6_pdaddr_value))
        return alert("$invalid_ipv6_primary_dns_hex"), !1;
      "" != ipv6_pdaddr_value &&
        (ipv6_pdaddr_value = parseInt(ipv6_pdaddr_value, 16).toString(16)),
        "" == ipv6_pdaddr_value
          ? ((ip_trans_array[2] = ip_trans_array[2] + "0" + ":"),
            (cf.ipv6_primary_dns_fixed.value =
              cf.ipv6_primary_dns_fixed.value + "0" + ":"))
          : ((ip_trans_array[2] = ip_trans_array[2] + ipv6_pdaddr_value + ":"),
            (cf.ipv6_primary_dns_fixed.value =
              cf.ipv6_primary_dns_fixed.value + ipv6_pdaddr_value + ":"));
    }
    if (check_sec_dns) {
      var ipv6_sdaddr_value = eval(
        'document.getElementsByName("SDAddr' + i + '")[0]'
      ).value;
      if (0 == check_ipv6_DNS_address(ipv6_sdaddr_value))
        return alert("$invalid_ipv6_second_dns_hex"), !1;
      "" != ipv6_sdaddr_value &&
        (ipv6_sdaddr_value = parseInt(ipv6_sdaddr_value, 16).toString(16)),
        "" == ipv6_sdaddr_value
          ? ((ip_trans_array[3] = ip_trans_array[3] + "0" + ":"),
            (cf.ipv6_second_dns_fixed.value =
              cf.ipv6_second_dns_fixed.value + "0" + ":"))
          : ((ip_trans_array[3] = ip_trans_array[3] + ipv6_sdaddr_value + ":"),
            (cf.ipv6_second_dns_fixed.value =
              cf.ipv6_second_dns_fixed.value + ipv6_sdaddr_value + ":"));
    }
    if (0 == check_ipv6_IP_address(cf.IPv6_lan[i - 1].value))
      return alert("$invalid_lan_ipv6_hex"), !1;
    "" != cf.IPv6_lan[i - 1].value &&
      (cf.IPv6_lan[i - 1].value = parseInt(
        cf.IPv6_lan[i - 1].value,
        16
      ).toString(16)),
      "" == cf.IPv6_lan[i - 1].value
        ? ((ip_trans_array[4] = ip_trans_array[4] + "0" + ":"),
          (cf.ipv6_lan_ip_fixed.value = cf.ipv6_lan_ip_fixed.value + "0" + ":"))
        : ((ip_trans_array[4] =
            ip_trans_array[4] + cf.IPv6_lan[i - 1].value + ":"),
          (cf.ipv6_lan_ip_fixed.value =
            cf.ipv6_lan_ip_fixed.value + cf.IPv6_lan[i - 1].value + ":"));
  }
  if (0 == check_ipv6_IP_address(cf.ProfixWanLength.value))
    return alert("$invalid_wan_ipv6_addr_pre_length"), !1;
  if (0 == check_ipv6_IP_address(cf.IPv6_lan_prefix.value))
    return alert("$invalid_lan_ipv6_addr_pre_length"), !1;
  var str = cf.ipv6_wan_ip_fixed.value;
  if (
    ((cf.ipv6_wan_ip_fixed.value = str.substring(0, str.length - 1)),
    ":::::::" == cf.ipv6_wan_ip_fixed.value)
  )
    cf.ipv6_wan_ip_fixed.value = "";
  else {
    if ("0:0:0:0:0:0:0:0" == cf.ipv6_wan_ip_fixed.value)
      return alert("$invalid_wan_ipv6_addr"), !1;
    if ("0:0:0:0:0:0:0:0:" == ip_trans_array[0])
      return alert("$invalid_wan_ipv6_addr"), !1;
  }
  if (
    ((cf.ipv6_wan_fixed_prefix.value = cf.ProfixWanLength.value),
    "" == cf.ipv6_wan_ip_fixed.value)
  )
    return alert("$wan_lack_ipv6_pre_length"), !1;
  if (
    "" == cf.ipv6_wan_fixed_prefix.value ||
    parseInt(cf.ipv6_wan_fixed_prefix.value, 10) > 126 ||
    parseInt(cf.ipv6_wan_fixed_prefix.value, 10) < 4
  )
    return alert("$invalid_wan_ipv6_addr_pre_length"), !1;
  if (0 == check_addr_legality(cf.ipv6_wan_ip_fixed.value))
    return alert("$invalid_wan_ipv6_addr"), !1;
  if (
    ((str = cf.ipv6_wan_gw_fixed.value),
    (cf.ipv6_wan_gw_fixed.value = str.substring(0, str.length - 1)),
    ":::::::" == cf.ipv6_wan_gw_fixed.value)
  )
    cf.ipv6_wan_gw_fixed.value = "";
  else {
    if ("0:0:0:0:0:0:0:0" == cf.ipv6_wan_gw_fixed.value)
      return alert("$invalid_ipv6_gateway"), !1;
    if ("0:0:0:0:0:0:0:0:" == ip_trans_array[1])
      return alert("$invalid_ipv6_gateway"), !1;
  }
  if (
    "" != cf.ipv6_wan_gw_fixed.value &&
    0 == check_addr_legality(cf.ipv6_wan_gw_fixed.value)
  )
    return alert("$invalid_ipv6_gateway"), !1;
  if (
    ((str = cf.ipv6_primary_dns_fixed.value),
    (cf.ipv6_primary_dns_fixed.value = str.substring(0, str.length - 1)),
    ":::::::" == cf.ipv6_primary_dns_fixed.value)
  )
    cf.ipv6_primary_dns_fixed.value = "";
  else {
    if ("0:0:0:0:0:0:0:0" == cf.ipv6_primary_dns_fixed.value)
      return alert("$invalid_ipv6_primary_dns"), !1;
    if ("0:0:0:0:0:0:0:0:" == ip_trans_array[2])
      return alert("$invalid_ipv6_primary_dns"), !1;
  }
  if ("" != cf.ipv6_primary_dns_fixed.value) {
    if (0 == check_addr_legality(cf.ipv6_primary_dns_fixed.value))
      return alert("$invalid_ipv6_primary_dns"), !1;
    if (cf.ipv6_primary_dns_fixed.value == cf.ipv6_wan_ip_fixed.value)
      return alert("$invalid_wan_primary_second_dns"), !1;
  }
  if (
    ((str = cf.ipv6_second_dns_fixed.value),
    (cf.ipv6_second_dns_fixed.value = str.substring(0, str.length - 1)),
    ":::::::" == cf.ipv6_second_dns_fixed.value)
  )
    cf.ipv6_second_dns_fixed.value = "";
  else {
    if ("0:0:0:0:0:0:0:0" == cf.ipv6_second_dns_fixed.value)
      return alert("$invalid_ipv6_second_dns"), !1;
    if ("0:0:0:0:0:0:0:0:" == ip_trans_array[3])
      return alert("$invalid_ipv6_second_dns"), !1;
  }
  if ("" != cf.ipv6_second_dns_fixed.value) {
    if (0 == check_addr_legality(cf.ipv6_second_dns_fixed.value))
      return alert("$invalid_ipv6_second_dns"), !1;
    if (cf.ipv6_second_dns_fixed.value == cf.ipv6_wan_ip_fixed.value)
      return alert("$invalid_wan_primary_second_dns"), !1;
    if (cf.ipv6_primary_dns_fixed.value == cf.ipv6_second_dns_fixed.value)
      return alert("$invalid_primary_second_dns"), !1;
  }
  if (
    (1 == cf.IpAssign[0].checked
      ? (cf.ipv6_hidden_ip_assign.value = "1")
      : (cf.ipv6_hidden_ip_assign.value = "0"),
    (str = cf.ipv6_lan_ip_fixed.value),
    (cf.ipv6_lan_ip_fixed.value = str.substring(0, str.length - 1)),
    ":::::::" == cf.ipv6_lan_ip_fixed.value)
  )
    cf.ipv6_lan_ip_fixed.value = "";
  else {
    if ("0:0:0:0:0:0:0:0" == cf.ipv6_lan_ip_fixed.value)
      return alert("$invalid_lan_ipv6_addr"), !1;
    if ("0:0:0:0:0:0:0:0:" == ip_trans_array[4])
      return alert("$invalid_lan_ipv6_addr"), !1;
  }
  if (
    ((cf.ipv6_lan_fixed_prefix.value = cf.IPv6_lan_prefix.value),
    "" == cf.ipv6_lan_ip_fixed.value)
  )
    return alert("$lan_lack_ipv6_pre_length"), !1;
  if (
    "" == cf.IPv6_lan_prefix.value ||
    parseInt(cf.IPv6_lan_prefix.value, 10) > 126 ||
    parseInt(cf.IPv6_lan_prefix.value, 10) < 4
  )
    return alert("$invalid_lan_ipv6_addr_pre_length"), !1;
  if (0 == check_addr_legality(cf.ipv6_lan_ip_fixed.value))
    return alert("$invalid_lan_ipv6_addr"), !1;
  var wan_ip = ip_trans_array[0],
    gate_way = ip_trans_array[1],
    primary_dns = ip_trans_array[2],
    second_dns = ip_trans_array[3],
    lan_ip = ip_trans_array[4];
  return "" != wan_ip && wan_ip.toUpperCase() == lan_ip.toUpperCase()
    ? (alert("$same_ipv6_lan_wan_ip"), !1)
    : "" == wan_ip || (wan_ip != primary_dns && wan_ip != second_dns)
    ? "" == lan_ip || (lan_ip != primary_dns && lan_ip != second_dns)
      ? (1 == cf.IPv6Filtering[0].checked
          ? (cf.ipv6_hidden_filtering.value = "0")
          : 1 == cf.IPv6Filtering[1].checked &&
            (cf.ipv6_hidden_filtering.value = "1"),
        !have_mapt || 1 != cf.cb_enable.checked || 0 != check_mapt(cf))
      : (alert("$invalid_lan_ipv6"), !1)
    : (alert("$invalid_wan_ipv6"), !1);
}
function check_addr_legality(value) {
  return (
    ("f" != value.charAt(0).toLowerCase() ||
      "f" != value.charAt(1).toLowerCase()) &&
    ":::::::1" != value &&
    "0:0:0:0:0:0:0:1" != value
  );
}
