function check_ipv6_dhcp(cf) {
  for (i = 0; i < cf.ipv6_system.value.length; i++)
    if (0 == isValidChar(cf.ipv6_system.value.charCodeAt(i)))
      return alert("$acname_not_allowed"), !1;
  var pattern = /(?=^.{1,255}$)(^[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?)*$)/;
  return "" == cf.domainName.value ||
    (null != cf.domainName.value.match(pattern) &&
      cf.domainName.value.match(pattern)[0] == cf.domainName.value)
    ? (1 != getTop(window).ipv6_dns_manual || 0 != checkIPv6DNS(cf)) &&
        0 != ipv6_save_common(cf)
    : (alert("$doname_not_allowed"), !1);
}
function check_ipv6_orange(cf) {
  for (
    cf.login_type.value = "autoConfig", i = 0;
    i < cf.ipv6_login.value.length;
    i++
  )
    if (0 == isValidChar(cf.ipv6_login.value.charCodeAt(i)))
      return alert("Login not allowed!"), !1;
  return 0 != ipv6_save_common(cf);
}
