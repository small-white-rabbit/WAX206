function show_hidden_help_top_button(help_flag) {
  if (!isIE_or_Opera() || IE_version() >= 8) Not_IE_show_hidden_help(help_flag);
  else {
    var frame_height = getTop(window)
      .document.getElementById("formframe_div")
      .style.height.replace(/px/, "");
    help_flag % 2 == 0
      ? ((document.getElementById("main").style.height = frame_height - 285),
        (document.getElementById("help").style.display = ""),
        (document.getElementById("help_switch").className = "open_help"))
      : ((document.getElementById("help").style.display = "none"),
        (document.getElementById("help_switch").className = "close_help"),
        (document.getElementById("main").style.height = frame_height - 165));
  }
}
function myip_update(page) {
  var cf = document.forms[0];
  cf.myip_1.value.length > 0 &&
  cf.myip_2.value.length > 0 &&
  cf.myip_3.value.length > 0 &&
  cf.myip_4.value.length > 0
    ? (setDisabled(!1, cf.mygw_1, cf.mygw_2, cf.mygw_3, cf.mygw_4),
      1 == russian_ppp_flag &&
        "bas" == page &&
        (setDisabled(!1, cf.mymask_1, cf.mymask_2, cf.mymask_3, cf.mymask_4),
        pptp_servip_update()))
    : (setDisabled(!0, cf.mygw_1, cf.mygw_2, cf.mygw_3, cf.mygw_4),
      1 == russian_ppp_flag &&
        "bas" == page &&
        (setDisabled(!0, cf.mymask_1, cf.mymask_2, cf.mymask_3, cf.mymask_4),
        pptp_servip_update()));
}
function change_pptp_password(obj) {
  "password" == obj.type &&
    ("Firefox" == get_browser()
      ? ((obj.value = ""), (obj.type = "text"))
      : ((obj.outerHTML =
          '<input type="text" name="pptp_passwd" maxlength="50" size="16" onFocus="this.select();change_pptp_password(this);" onKeyPress="return getkey(\'ssid\', event)" value="" autocomplete="off">'),
        document.forms[0].pptp_passwd.select())),
    (document.forms[0].hidden_pwd_change.value = "1");
}
function pptp_servip_update() {
  var disable = !1,
    cf = document.forms[0],
    serv_array = cf.pptp_serv_ip.value.split(".");
  if (4 == serv_array.length) {
    var flag = 0;
    for (iptab = 0; iptab < 4; iptab++)
      isNumeric(serv_array[iptab], 255) && flag++;
    4 == flag
      ? 0 == checkipaddr(cf.pptp_serv_ip.value) && (disable = !0)
      : (disable = !0);
  } else cf.pptp_serv_ip.value.length > 0 && (disable = !0);
  1 == russian_ppp_flag &&
    (1 == disable && "" == cf.myip_1.value && (disable = !1),
    setDisabled(disable, cf.DNSAssign[0]),
    1 == disable &&
      0 == cf.DNSAssign[1].checked &&
      ((cf.DNSAssign[1].checked = !0), setDNS(cf)));
}
function setDNS(cf) {
  var dflag = cf.DNSAssign[0].checked;
  setDisabled(
    dflag,
    cf.DAddr1,
    cf.DAddr2,
    cf.DAddr3,
    cf.DAddr4,
    cf.PDAddr1,
    cf.PDAddr2,
    cf.PDAddr3,
    cf.PDAddr4
  ),
    (DisableFixedDNS = dflag);
}
function is_IP_addr(serv_array) {
  var i, j, charct;
  for (i = 0; i < serv_array.length; i++)
    for (j = 0; j < serv_array[i].length; j++)
      if (
        ((charct = serv_array[i].charAt(j)),
        "0123456789".indexOf(charct, 0) < 0)
      )
        return !1;
  return !0;
}
var pptpserv_isNdomain = 0;
function check_wizard_pptp(check, page) {
  var cf = document.forms[0];
  if ("" == cf.pptp_username.value) return alert("$login_name_null"), !1;
  for (i = 0; i < cf.pptp_username.value.length; i++)
    if (0 == isValidChar(cf.pptp_username.value.charCodeAt(i)))
      return alert("$loginname_not_allowed"), !1;
  for (i = 0; i < cf.pptp_passwd.value.length; i++)
    if (0 == isValidChar(cf.pptp_passwd.value.charCodeAt(i)))
      return alert("$password_error"), !1;
  if ("1" == convert_value_to_original(cf, "pptp_dod")) {
    if (cf.pptp_idletime.value.length <= 0) return alert("$idle_time_null"), !1;
    if (!_isNumeric(cf.pptp_idletime.value))
      return alert("$invalid_idle_time"), !1;
  }
  if (
    ((cf.pptp_myip.value =
      cf.myip_1.value +
      "." +
      cf.myip_2.value +
      "." +
      cf.myip_3.value +
      "." +
      cf.myip_4.value),
    (cf.pptp_gateway.value =
      cf.mygw_1.value +
      "." +
      cf.mygw_2.value +
      "." +
      cf.mygw_3.value +
      "." +
      cf.mygw_4.value),
    1 == russian_ppp_flag && "bas" == page
      ? (cf.pptp_subnet.value =
          cf.mymask_1.value +
          "." +
          cf.mymask_2.value +
          "." +
          cf.mymask_3.value +
          "." +
          cf.mymask_4.value)
      : (cf.pptp_subnet.value = ""),
    "" == cf.pptp_subnet.value || "..." == cf.pptp_subnet.value)
  ) {
    var pptp_mask = "255.255.255.0";
    (pptp_mask =
      parseInt(cf.myip_1.value) < 128
        ? "255.0.0.0"
        : parseInt(cf.myip_1.value) < 192
        ? "255.255.0.0"
        : "255.255.255.0"),
      (cf.pptp_subnet.value = pptp_mask);
  }
  if ("..." != cf.pptp_myip.value) {
    if (((cf.WANAssign.value = 1), 0 == checkipaddr(cf.pptp_myip.value)))
      return alert("$invalid_myip"), !1;
    if (
      (1 == isSameSubNet(cf.pptp_myip.value, lan_subnet, lan_ip, lan_subnet) &&
        (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pptp_myip.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1),
      1 == russian_ppp_flag && "bas" == page)
    ) {
      if (0 == checksubnet(cf.pptp_subnet.value, 1))
        return alert("$invalid_mask"), !1;
      1 ==
        isSameSubNet(
          cf.pptp_myip.value,
          cf.pptp_subnet.value,
          lan_ip,
          cf.pptp_subnet.value
        ) && (cf.conflict_wanlan.value = 1),
        1 ==
          isSameSubNet(
            cf.pptp_myip.value,
            cf.pptp_subnet.value,
            lan_ip,
            lan_subnet
          ) && (cf.conflict_wanlan.value = 1);
    }
    if (
      "..." != cf.pptp_gateway.value &&
      (0 == checkgateway(cf.pptp_gateway.value) ||
        0 ==
          is_sub_or_broad(
            cf.pptp_gateway.value,
            cf.pptp_gateway.value,
            cf.pptp_subnet.value
          ))
    )
      return alert("$invalid_gateway"), !1;
    if ("..." != cf.pptp_gateway.value) {
      if (1 == isSameIp(cf.pptp_myip.value, cf.pptp_gateway.value) || 
          0 ==
            isSameSubNet(
              cf.pptp_myip.value,
              cf.pptp_subnet.value,
              cf.pptp_gateway.value,
              cf.pptp_subnet.value
            ))
        return alert("$invalid_gateway"), !1;
      cf.pptp_gateway.value = address_parseInt(cf.pptp_gateway.value);
    }
    (cf.pptp_myip.value = address_parseInt(cf.pptp_myip.value)),
      (cf.pptp_subnet.value = address_parseInt(cf.pptp_subnet.value));
  } else
    (cf.pptp_myip.value = ""),
      (cf.pptp_gateway.value = ""),
      (cf.pptp_subnet.value = ""),
      (cf.WANAssign.value = 0);
  if ("" == cf.pptp_serv_ip.value) return alert("$invalid_servip"), !1;
  for (i = 0; i < cf.pptp_serv_ip.value.length; i++)
    if (0 == isValidDdnsHost(cf.pptp_serv_ip.value.charCodeAt(i)))
      return alert("$invalid_servip"), !1;
  if (cf.pptp_serv_ip.value == cf.pptp_myip.value)
    return alert("$same_server_wan_ip"), !1;
  var i,
    serv_array = cf.pptp_serv_ip.value.split(".");
  for (i = 0; i < serv_array.length; i++)
    if (serv_array[i].length > 63) return alert("$invalid_servip_length"), !1;
  if (4 == serv_array.length) {
    var flag = 0;
    for (iptab = 0; iptab < 4; iptab++)
      isNumeric(serv_array[iptab], 255) && flag++;
    if (
      4 != flag ||
      1 != is_IP_addr(serv_array) ||
      1 != checkipaddr(cf.pptp_serv_ip.value)
    )
      return alert("$invalid_servip"), !1;
    if (
      "" != cf.pptp_myip.value &&
      ("..." == cf.pptp_gateway.value || "" == cf.pptp_gateway.value)
    )
      return alert("$invalid_gateway"), !1;
    pptpserv_isNdomain = 1;
  }
  var pattern = /(?=^.{1,255}$)(^[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([-a-zA-Z0-9]{0,61}[a-zA-Z0-9])?)*$)/;
  return 0 != pptpserv_isNdomain ||
    (null != cf.pptp_serv_ip.value.match(pattern) &&
      cf.pptp_serv_ip.value.match(pattern)[0] == cf.pptp_serv_ip.value)
    ? (1 == check
        ? ((cf.run_test.value = "test"),
          "wiz" == page &&
            (cf.action = "/apply.cgi?/WIZ_update.htm timestamp=" + ts))
        : (cf.run_test.value = "no"),
      !0)
    : (alert("$invalid_servip"), !1);
}
function check_pptp(cf, check) {
  format_IP(
    "myip_1",
    "myip_2",
    "myip_3",
    "myip_4",
    "mymask_1",
    "mymask_2",
    "mymask_3",
    "mymask_4",
    "mygw_1",
    "mygw_2",
    "mygw_3",
    "mygw_4",
    "DAddr1",
    "DAddr2",
    "DAddr3",
    "DAddr4",
    "PDAddr1",
    "PDAddr2",
    "PDAddr3",
    "PDAddr4"
  ),
    1 == cf.auto_conn_24hr.checked
      ? (cf.hidden_auto_conn_flag.value = 1)
      : (cf.hidden_auto_conn_flag.value = 0),
    (cf.hidden_conn_time_num.value = cf.auto_conn_time.selectedIndex);
  var wan_assgin = !1;
  if (0 == check_wizard_pptp(check, "bas")) return !1;
  if (
    ((cf.hidden_pptp_idle_time.value = parseInt(cf.pptp_idletime.value, 10)),
    (cf.hid_pptp_dod.value = convert_value_to_original(cf, "pptp_dod")),
    1 == cf.WANAssign.value && (wan_assgin = !0),
    1 == cf.DNSAssign[1].checked)
  ) {
    if (
      ((cf.pptp_dnsaddr1.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      (cf.pptp_dnsaddr2.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      "..." == cf.pptp_dnsaddr1.value
        ? (cf.pptp_dnsaddr1.value = "")
        : (cf.pptp_dnsaddr1.value = address_parseInt(cf.pptp_dnsaddr1.value)),
      "..." == cf.pptp_dnsaddr2.value
        ? (cf.pptp_dnsaddr2.value = "")
        : (cf.pptp_dnsaddr2.value = address_parseInt(cf.pptp_dnsaddr2.value)),
      !check_DNS(
        cf.pptp_dnsaddr1.value,
        cf.pptp_dnsaddr2.value,
        wan_assgin,
        cf.pptp_myip.value
      ))
    )
      return !1;
    if (
      1 == cf.WANAssign.value &&
      (("" != cf.pptp_dnsaddr1.value &&
        !isSameSubNet(
          cf.pptp_dnsaddr1.value,
          cf.pptp_subnet.value,
          cf.pptp_myip.value,
          cf.pptp_subnet.value
        )) ||
        ("" != cf.pptp_dnsaddr2.value &&
          !isSameSubNet(
            cf.pptp_dnsaddr2.value,
            cf.pptp_subnet.value,
            cf.pptp_myip.value,
            cf.pptp_subnet.value
          ))) &&
      ("" == cf.pptp_gateway.value || "..." == cf.pptp_gateway.value)
    )
      return alert("$invalid_gateway"), !1;
  }
  if (cf.MACAssign[2].checked) {
    if (
      ((the_mac = cf.Spoofmac.value),
      -1 == the_mac.indexOf(":") && "12" == the_mac.length)
    ) {
      var tmp_mac =
        the_mac.substr(0, 2) +
        ":" +
        the_mac.substr(2, 2) +
        ":" +
        the_mac.substr(4, 2) +
        ":" +
        the_mac.substr(6, 2) +
        ":" +
        the_mac.substr(8, 2) +
        ":" +
        the_mac.substr(10, 2);
      cf.Spoofmac.value = tmp_mac;
    } else if (6 == the_mac.split("-").length) {
      tmp_mac = the_mac.replace(/-/g, ":");
      cf.Spoofmac.value = tmp_mac;
    }
    if (0 == maccheck_multicast(cf.Spoofmac.value)) return !1;
  }
  if (
    ((cf.hid_mtu_value.value = wan_mtu_now),
    "pptp" != old_wan_type
      ? ((cf.change_wan_type.value = 0), mtu_change(wanproto_type))
      : (cf.change_wan_type.value = 1),
    (cf.hid_enable_vpn.value = vpn_enable),
    "1" != old_endis_ddns && "1" == vpn_enable)
  ) {
    if (1 != confirm("$no_change_static_ip"))
      return (cf.hid_enable_vpn.value = "1"), !1;
    cf.hid_enable_vpn.value = "0";
  }
  if (
    !(
      ("1" != cf.hid_pptp_dod.value && "2" != cf.hid_pptp_dod.value) ||
      ("1" != readycloud_enable &&
        "1" != vpn_enable &&
        "1" != upnp_enableMedia &&
        1 != parent.geniecloud_flag) ||
      0 != confirm("$ppp_dial_on_demand_query")
    )
  )
    return !1;
  if (
    1 === getTop(window).use_orbi_style_flag &&
    1 == cf.wan_preference[4].checked
  )
    if ("0" != qos_endis_on && "0" != aggre_option) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS and Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if ("0" != qos_endis_on) {
      if (
        0 ==
        confirm(
          "Enabling WAN aggregation disables QoS. Do you want to enable WAN aggregation?"
        )
      )
        return !1;
    } else if (
      "0" != aggre_option &&
      0 ==
        confirm(
          "Enabling WAN aggregation disables Ethernet Port Aggregation. Do you want to enable WAN aggregation?"
        )
    )
      return !1;
  return (
    "1" == cf.sfp_module.value
      ? (cf.hid_sfp_module.value = 1)
      : (cf.hid_sfp_module.value = 0),
    cf.submit(),
    !0
  );
}
function setIP_welcome_pptp() {
  var cf = document.forms[0],
    dflag = cf.WANAssign[0].checked;
  setDisabled(dflag, cf.myip_1, cf.myip_2, cf.myip_3, cf.myip_4),
    (DisableFixedIP = dflag);
}
function check_welcome_pptp() {
  var cf = document.forms[0];
  return (
    0 != check_wizard_pptp(0, "welcome") &&
    ((parent.pptp_username = cf.pptp_username.value),
    (parent.pptp_password = cf.pptp_passwd.value),
    (parent.pptp_idle_time = cf.pptp_idletime.value),
    (cf.pptp_myip.value =
      cf.myip_1.value +
      "." +
      cf.myip_2.value +
      "." +
      cf.myip_3.value +
      "." +
      cf.myip_4.value),
    "..." == cf.pptp_myip.value
      ? ((cf.pptp_myip.value = ""),
        (cf.WANAssign.value = 0),
        (parent.pptp_wan_assign = 0))
      : ((cf.WANAssign.value = 1), (parent.pptp_wan_assign = 1)),
    (parent.pptp_local_ipaddr = cf.pptp_myip.value),
    (parent.pptp_local_gateway = cf.pptp_gateway.value),
    (parent.pptp_server_ipaddr = cf.pptp_serv_ip.value),
    (parent.pptp_connect_id = cf.pptp_conn_id.value),
    (parent.welcome_wan_type = 4),
    !0)
  );
}
function RU_pptp_user_info() {
  var cf = document.forms[0];
  if ("" == cf.pptp_username.value) return alert(login_name_null), !1;
  for (i = 0; i < cf.pptp_username.value.length; i++)
    if (0 == isValidChar(cf.pptp_username.value.charCodeAt(i)))
      return alert(loginname_not_allowed), !1;
  for (i = 0; i < cf.pptp_passwd.value.length; i++)
    if (0 == isValidChar(cf.pptp_passwd.value.charCodeAt(i)))
      return alert(password_not_allowed), !1;
  if ("" == cf.pptp_serv_ip.value) return alert(invalid_servip), !1;
  for (i = 0; i < cf.pptp_serv_ip.value.length; i++)
    if (0 == isValidChar(cf.pptp_serv_ip.value.charCodeAt(i)))
      return alert(invalid_servip), !1;
  var i,
    server_addr_array = cf.pptp_serv_ip.value.split(".");
  for (i = 0; i < server_addr_array.length; i++)
    if (server_addr_array[i].length > 63) return alert(invalid_servip), !1;
  (parent.pptp_username = cf.pptp_username.value),
    (parent.pptp_password = cf.pptp_passwd.value),
    (parent.pptp_server_ipaddr = cf.pptp_serv_ip.value),
    (parent.welcome_wan_type = 4),
    "12" == parent.isp_type
      ? ((cf.basic_type.value = "0"),
        (cf.ppp_login_type.value = "1"),
        (cf.welcome_wan_type.value = "4"),
        (cf.pptp_dnsaddr1.value = parent.static_dns1),
        (cf.pptp_dnsaddr2.value = parent.static_dns2),
        "" != cf.pptp_dnsaddr1.value || "" != cf.pptp_dnsaddr2.value
          ? (cf.DNSAssign.value = "1")
          : (cf.DNSAssign.value = "0"),
        (cf.WANAssign.value = "0"),
        (cf.STATIC_DNS.value = "0"),
        cf.submit())
      : "11" == parent.isp_type
      ? (location.href = "RU_isp_spoof.htm")
      : "9" == parent.isp_type || "10" == parent.isp_type
      ? (location.href = "RU_isp_pptp_static.htm")
      : (location.href = "RU_manu_local_resources.htm");
}
function setIP(cf) {
  var dflag = cf.DualAssign[0].checked;
  if (
    (setDisabled(
      dflag,
      cf.myip_1,
      cf.myip_2,
      cf.myip_3,
      cf.myip_4,
      cf.mymask_1,
      cf.mymask_2,
      cf.mymask_3,
      cf.mymask_4,
      cf.mygw_1,
      cf.mygw_2,
      cf.mygw_3,
      cf.mygw_4
    ),
    (DisableFixedIP = dflag),
    !document.getElementsByTagName("span")[0])
  )
    return !1;
  cf.DualAssign[1].checked
    ? ((cf.DNSAssign[1].checked = !0),
      setDNS(cf),
      (cf.DNSAssign[0].disabled = !0),
      (document.getElementsByTagName("span")[0].style.color = "gray"))
    : ((document.getElementsByTagName("span")[0].style.color = "black"),
      (cf.DNSAssign[0].disabled = !1));
}
function RU_pptp_servip_FQDN(I) {
  var cf = document.forms[0];
  (servName = cf.pptp_serv_ip.value),
    -1 != servName.search(/[A-Za-z]/i)
      ? (parent.pptp_server_FQDN = 1)
      : (parent.pptp_server_FQDN = 0);
}
function RU_pptp_servip_update(I) {
  var cf = document.forms[0];
  1 == parent.pptp_server_FQDN &&
  (cf.myip_1.value.length > 0 ||
    cf.myip_2.value.length > 0 ||
    cf.myip_3.value.length > 0 ||
    cf.myip_4.value.length > 0)
    ? (1 == cf.DNSAssign[0].checked &&
        ((cf.DAddr1.disabled = !1),
        (cf.DAddr2.disabled = !1),
        (cf.DAddr3.disabled = !1),
        (cf.DAddr4.disabled = !1),
        (cf.PDAddr1.disabled = !1),
        (cf.PDAddr2.disabled = !1),
        (cf.PDAddr3.disabled = !1),
        (cf.PDAddr4.disabled = !1)),
      (cf.DNSAssign[0].checked = !1),
      (cf.DNSAssign[1].checked = !0),
      (cf.DNSAssign[0].disabled = !0),
      (cf.STATIC_DNS.value = 1))
    : ((cf.DNSAssign[0].disabled = !1), (cf.STATIC_DNS.value = 0));
}
function RU_check_pptp_dual() {
  var cf = document.forms[0],
    wan_assgin = !1;
  if (
    ((cf.pptp_myip.value =
      cf.myip_1.value +
      "." +
      cf.myip_2.value +
      "." +
      cf.myip_3.value +
      "." +
      cf.myip_4.value),
    (cf.pptp_mynetmask.value =
      cf.mymask_1.value +
      "." +
      cf.mymask_2.value +
      "." +
      cf.mymask_3.value +
      "." +
      cf.mymask_4.value),
    (cf.pptp_gateway.value =
      cf.mygw_1.value +
      "." +
      cf.mygw_2.value +
      "." +
      cf.mygw_3.value +
      "." +
      cf.mygw_4.value),
    1 == cf.DualAssign[1].checked)
  ) {
    if (
      ((wan_assgin = !0),
      (parent.pptp_wan_assign = 1),
      0 == checkipaddr(cf.pptp_myip.value))
    )
      return alert(invalid_myip), !1;
    if (
      (1 == isSameSubNet(cf.pptp_myip.value, lan_subnet, lan_ip, lan_subnet) &&
        (cf.conflict_wanlan.value = 1),
      1 == isSameIp(cf.pptp_myip.value, lan_ip) &&
        (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(
          cf.pptp_myip.value,
          cf.pptp_mynetmask.value,
          lan_ip,
          cf.pptp_mynetmask.value
        ) && (cf.conflict_wanlan.value = 1),
      1 ==
        isSameSubNet(
          cf.pptp_myip.value,
          cf.pptp_mynetmask.value,
          lan_ip,
          lan_subnet
        ) && (cf.conflict_wanlan.value = 1),
      0 == checksubnet(cf.pptp_mynetmask.value))
    )
      return alert(invalid_mask), !1;
    if (
      "..." != cf.pptp_gateway.value &&
      (0 == checkgateway(cf.pptp_gateway.value) ||
        0 ==
          is_sub_or_broad(
            cf.pptp_gateway.value,
            cf.pptp_gateway.value,
            cf.pptp_mynetmask.value
          ))
    )
      return alert(invalid_gateway), !1;
    if ("..." != cf.pptp_gateway.value) {
      if (1 == isSameIp(cf.pptp_myip.value, cf.pptp_gateway.value))
        return alert(invalid_gateway), !1;
    } else cf.pptp_gateway.value = "";
  } else
    (cf.pptp_myip.value = ""),
      (cf.pptp_mynetmask.value = ""),
      (cf.pptp_gateway.value = ""),
      (parent.pptp_wan_assign = 0);
  if (1 == cf.DNSAssign[1].checked) {
    if (
      ((cf.pptp_dnsaddr1.value =
        cf.DAddr1.value +
        "." +
        cf.DAddr2.value +
        "." +
        cf.DAddr3.value +
        "." +
        cf.DAddr4.value),
      (cf.pptp_dnsaddr2.value =
        cf.PDAddr1.value +
        "." +
        cf.PDAddr2.value +
        "." +
        cf.PDAddr3.value +
        "." +
        cf.PDAddr4.value),
      "..." == cf.pptp_dnsaddr1.value && (cf.pptp_dnsaddr1.value = ""),
      "..." == cf.pptp_dnsaddr2.value && (cf.pptp_dnsaddr2.value = ""),
      !check_RU_DNS(
        cf.pptp_dnsaddr1.value,
        cf.pptp_dnsaddr2.value,
        wan_assgin,
        cf.pptp_myip.value
      ))
    )
      return !1;
  } else (cf.pptp_dnsaddr1.value = ""), (cf.pptp_dnsaddr2.value = "");
  1 == cf.DualAssign[1].checked && alert(attention_static_ip),
    (parent.pptp_local_ipaddr = cf.pptp_myip.value),
    (parent.pptp_local_netmask = cf.pptp_mynetmask.value),
    (parent.pptp_local_gateway = cf.pptp_gateway.value),
    (parent.pptp_dns1 = cf.pptp_dnsaddr1.value),
    (parent.pptp_dns2 = cf.pptp_dnsaddr2.value),
    (parent.STATIC_DNS = cf.STATIC_DNS.value),
    (parent.conflict_wanlan = cf.conflict_wanlan.value),
    (location.href = "RU_manual_spoof.htm");
}
