function check_ipv6_6rd(cf) {
  var i;
  for (
    cf.ipv6_hidden_6rd_pre.value = "", i = 0;
    i < cf.ipv6_6rd_pre.length;
    i++
  )
    "" == cf.ipv6_6rd_pre[i].value && (cf.ipv6_6rd_pre[i].value = "0"),
      i < cf.ipv6_6rd_pre.length - 1
        ? (cf.ipv6_hidden_6rd_pre.value =
            cf.ipv6_hidden_6rd_pre.value + cf.ipv6_6rd_pre[i].value + ":")
        : i == cf.ipv6_6rd_pre.length - 1 &&
          (cf.ipv6_hidden_6rd_pre.value =
            cf.ipv6_hidden_6rd_pre.value + cf.ipv6_6rd_pre[i].value);
  if ("0:0:0:0" == cf.ipv6_hidden_6rd_pre.value)
    return alert("Invalid IPv6 Address!"), !1;
  if ("" == cf.ipv6_pre_len.value || "" == cf.ipv6_mask_len.value)
    return alert("Please enter a valid Prefix Length!"), !1;
  for (
    cf.ipv6_hidden_6rd_relay.value = "", i = 0;
    i < cf.relay_addr.length;
    i++
  )
    i < cf.relay_addr.length - 1
      ? (cf.ipv6_hidden_6rd_relay.value =
          cf.ipv6_hidden_6rd_relay.value + cf.relay_addr[i].value + ".")
      : i == cf.relay_addr.length - 1 &&
        (cf.ipv6_hidden_6rd_relay.value =
          cf.ipv6_hidden_6rd_relay.value + cf.relay_addr[i].value);
  return 0 == checkipaddr(cf.ipv6_hidden_6rd_relay.value)
    ? (alert("$invalid_ip"), !1)
    : (1 != getTop(window).ipv6_dns_manual || 0 != checkIPv6DNS(cf)) &&
        0 != ipv6_save_common(cf);
}
